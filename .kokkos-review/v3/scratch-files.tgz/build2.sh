#!/bin/bash
while pgrep -f build_all.sh >/dev/null; do sleep 30; done
cmake --build /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/build -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_opt.log 2>&1; echo "opt rc=$?"
cmake --build /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/bmpi_fixed -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_mpi.log 2>&1; echo "mpi rc=$?"
echo ALLDONE2
