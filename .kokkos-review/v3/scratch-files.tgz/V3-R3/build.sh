#!/bin/bash
set -x
cmake -S /home/user/sparta/cmake -B /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/bopt -G Ninja -C /home/user/sparta/cmake/presets/kokkos_omp.cmake -DBUILD_MPI=off -DPKG_MPI_STUBS=on -DPKG_FFT=on -DCMAKE_CXX_FLAGS="-g -O3" > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/c_opt.log 2>&1
ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/bopt -j3 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/b_opt.log 2>&1; echo "opt rc=$?"
for t in B A; do
 if [ $t = B ]; then src=/home/user/sparta/cmake; else src=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/base/cmake; fi
 cmake -S $src -B /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/bexact_$t -G Ninja -C /home/user/sparta/cmake/presets/kokkos_mpi_only.cmake -DBUILD_MPI=off -DPKG_MPI_STUBS=on -DSPARTA_KOKKOS_EXACT=ON -DKokkos_ENABLE_SERIAL=ON -DKokkos_ENABLE_OPENMP=OFF -DPKG_FFT=ON -DCMAKE_BUILD_TYPE=Release > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/c_exact_$t.log 2>&1
 ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/bexact_$t -j3 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/b_exact_$t.log 2>&1; echo "exact_$t rc=$?"
done
echo ALLDONE
