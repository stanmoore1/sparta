#!/bin/bash
cd /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/c
for inp in chem/in.chem chem/in.chem.gastally ambi/in.ambi.group.react ambi/in.ambi $(ls ambi_3body/in.* | head -3); do
 ex=$(dirname $inp); n=$(basename $inp)
 for m in def retry; do pk=""; [ $m = retry ] && pk="-pk kokkos react/retry yes"
  for v in A B; do bin=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/build_base/src/spa_kokkos_omp; [ $v = B ] && bin=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/bopt/src/spa_kokkos_omp
   (cd $ex && timeout 900 $bin -k on t 1 -sf kk $pk -in $n -echo none -screen none -log log.$n.$m.$v >/dev/null 2>&1)
   echo "$inp $m $v rc=$? $(grep -c ERROR $ex/log.$n.$m.$v) $(grep -B1 '^Loop' $ex/log.$n.$m.$v | head -1)"
  done; done; done
