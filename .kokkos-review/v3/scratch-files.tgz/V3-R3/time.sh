#!/bin/bash
# usage: time.sh <reps> <threads> <ex/in> ...
A=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/build_base/src/spa_kokkos_omp; B=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/bopt/src/spa_kokkos_omp
reps=$1; t=$2; shift 2
for inp in "$@"; do
  ex=$(dirname $inp); name=$(basename $inp)
  w=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/t/$ex; mkdir -p $w; cp -rn /home/user/sparta/examples/$ex/. $w/ 2>/dev/null
  for r in $(seq $reps); do for v in A B; do
    bin=$A; [ $v = B ] && bin=$B
    (cd $w && timeout 900 $bin -k on t $t -sf kk -in $name -echo none -screen none -log log.$name.$v.t$t.$r >/dev/null 2>&1)
    lt=$(grep '^Loop time' $w/log.$name.$v.t$t.$r | awk '{print $4}')
    echo "$inp t$t $v rep$r $lt"
  done; done
done
