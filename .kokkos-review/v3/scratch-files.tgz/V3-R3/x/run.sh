#!/bin/bash
# usage: run.sh <bin> <tag>
BIN=$1; T=$2; D=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R3/x
cd $D
for inp in chem/in.chem chem/in.chem.gastally ambi/in.ambi.group.react ambi_3body/in.ambi_3body co2r/in.co2r collide/in.collide collide/in.collide_2D_nn collide/in.collide.group; do
 ex=$(dirname $inp); n=$(basename $inp)
 for m in cpu kk kkretry; do
  case $m in cpu) a="";; kk) a="-k on -sf kk";; kkretry) a="-k on -sf kk -pk kokkos react/retry yes";; esac
  (cd $ex && timeout 900 $BIN $a -in $n -echo none -screen none -log log.$n.$m.$T >/dev/null 2>&1)
  # stats lines without the cpu column: keep all numeric rows
  awk '/^Step/{s=1;next} /^Loop/{s=0} s&&$1~/^[0-9]+$/' $ex/log.$n.$m.$T > $ex/st.$n.$m.$T
 done
 cpu=$ex/st.$n.cpu.$T
 for m in kk kkretry; do
  if cmp -s <(awk '{$2="";print}' $cpu) <(awk '{$2="";print}' $ex/st.$n.$m.$T); then r=IDENT; else r=DIFF; fi
  # some decks have no cpu column; also compare whole rows
  cmp -s $cpu $ex/st.$n.$m.$T && r="IDENT(all)"
  echo "$inp $m vs cpu: $r ($(wc -l < $ex/st.$n.$m.$T) rows; err=$(grep -c ERROR $ex/log.$n.$m.$T))"
 done
done
