seed	    	    12345
dimension   	    2
global              gridcut 0.0 comm/sort yes
boundary	    	o r p
create_box  	    0 10 0 10 -0.5 0.5
create_grid 	    20 20 1 
balance_grid        rcb cell
global		    	nrho 1.0 fnum 0.001 surfs explicit/distributed
species		    	air.species O CO CO2 C
mixture		    	air O vstream 100.0 0 0 
mixture             air O   frac 1.0 
mixture             air CO  frac 0.0
mixture             air CO2 frac 0.0 
mixture             air C   frac 0.0 
read_surf           data.circle
surf_collide        1 cll 300.0 0.5 0.5 0.5 0.5 
surf_react          adsorb_test_ps2 adsorb ps sample-PS_2.surf nsync 1 surf 1000 6.022e9 O CO
surf_modify         all collide 1 react adsorb_test_ps2
fix		    		in emit/face air xlo nevery 100 n 10000 perspecies no twopass # subsonic 0.1 NULL
timestep 	    	0.0001
stats		    	10
stats_style	    	step cpu np nattempt ncoll nscoll nscheck
run 100
