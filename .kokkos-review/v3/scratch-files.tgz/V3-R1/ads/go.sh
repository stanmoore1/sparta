S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
D=$S/final/V3-R1/ads; cd $D
for b in A:$S/bmpi_base/src/spa_kokkos_omp C:$S/final/V3-R1/bcpu_B/src/spa_; do for f in nd d; do
timeout 600 mpirun --allow-run-as-root --oversubscribe -np 4 ${b#*:} -in in.$f > log.${b%%:*}.$f 2>&1; echo "${b%%:*} $f $?"; done; done; echo ADSDONE
