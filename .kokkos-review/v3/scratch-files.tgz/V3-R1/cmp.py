import sys, collections
def parse(fn):
    snaps={}; f=open(fn).read().split('ITEM: TIMESTEP\n')[1:]
    for blk in f:
        lines=blk.strip().split('\n'); step=int(lines[0])
        i=lines.index([l for l in lines if l.startswith('ITEM: CELLS')][0])
        d=collections.defaultdict(list)
        for l in lines[i+1:]:
            p=l.split(); d[p[0]].append(tuple(float(x) for x in p[1:]))
        snaps[step]={k:sorted(v) for k,v in d.items()}
    return snaps
a=parse(sys.argv[1]); b=parse(sys.argv[2]); tol=float(sys.argv[3]) if len(sys.argv)>3 else 1e-9
nbad=0; nsteps=0; firstbad=None; nz=0
for s in sorted(a):
    if s not in b: print("missing step",s); nbad+=1; continue
    nsteps+=1
    for k in a[s]:
        va=a[s][k]; vb=b[s].get(k)
        if vb is None or len(va)!=len(vb): nbad+=1; continue
        for ra,rb in zip(va,vb):
            if any(x!=0 for x in ra): nz+=1
            for x,y in zip(ra,rb):
                if abs(x-y)>tol*max(1,abs(x),abs(y)):
                    nbad+=1
                    if firstbad is None: firstbad=(s,k,ra,rb)
                    break
tot=[sum(r[0] for v in a[s].values() for r in v) for s in sorted(a)]
print("steps",nsteps,"nonzero-rows",nz,"mismatched-rows",nbad,"first",firstbad, "sumcol1", sum(tot))
