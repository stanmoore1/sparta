import struct, random
random.seed(7)
def field(dims):
    import itertools
    vals=[]
    rng=[range(d) for d in dims]
    out=[]
    if len(dims)==2:
        for j in range(dims[1]):
            for i in range(dims[0]):
                b = i in (0,dims[0]-1) or j in (0,dims[1]-1)
                out.append(0 if b else (255 if random.random()<0.55 else 0))
    else:
        for k in range(dims[2]):
          for j in range(dims[1]):
            for i in range(dims[0]):
                b = i in (0,dims[0]-1) or j in (0,dims[1]-1) or k in (0,dims[2]-1)
                out.append(0 if b else (255 if random.random()<0.5 else 0))
    return out
v=field((11,11)); open('b2d','wb').write(struct.pack('ii',11,11)+bytes(v))
v=field((7,7,7)); open('b3d','wb').write(struct.pack('iii',7,7,7)+bytes(v))
