import sys, math
dim=int(sys.argv[1]); mode=sys.argv[2]; bal=int(sys.argv[3]); out=sys.argv[4]; bst=sys.argv[5] if len(sys.argv)>5 else "rcb part"; nrun=int(sys.argv[6]) if len(sys.argv)>6 else 200
L=[]
L.append("seed 12345\ndimension %d\nglobal gridcut 0.0 comm/sort yes"%dim)
if dim==2:
    L.append("boundary r r p\ncreate_box 0 20 0 20 -0.5 0.5\ncreate_grid 20 20 1")
    L.append("region inner block 5.5 14.5 5.5 14.5 INF INF")
else:
    L.append("boundary r r r\ncreate_box 0 12 0 12 0 12\ncreate_grid 12 12 12")
    L.append("region inner block 3.5 8.5 3.5 8.5 3.5 8.5")
L.append("balance_grid rcb cell\nglobal nrho 1.0 fnum 1.0\nspecies air.species N O\nmixture air N O")
L.append("group inner grid region inner one")
L.append("fix ablate ablate inner 0 0.0 uniform 0")
L.append("global surfs implicit")
if dim==2: L.append("read_isurf inner 10 10 1 b2d 127.5 ablate")
else: L.append("read_isurf inner 6 6 6 b3d 127.5 ablate")
L.append("surf_collide 1 specular\nsurf_modify all collide 1")
if mode=='react':
    L.append("surf_react 1 global 1.0 0.0\nsurf_modify all react 1")
    L.append("compute COMP react/isurf/grid all 1")
else:
    L.append("compute COMP isurf/grid all all n nwt mflux press")
L.append("fix AVE ave/grid all 1 5 5 c_COMP[*]")
# deterministic particles
n=0
hi = 20 if dim==2 else 12
lo_in, hi_in = (5,15) if dim==2 else (3,9)
for k in range(300):
    a=(k*0.6180339887)%1.0; b=(k*0.4142135623)%1.0; c=(k*0.7320508)%1.0
    side=k%2
    x = (0.3+a*(lo_in-0.6)) if side==0 else (hi_in+0.3+a*(hi-hi_in-0.6))
    y = 0.3+b*(hi-0.6)
    z = 0.0 if dim==2 else 0.3+c*(hi-0.6)
    th=2*math.pi*((k*0.7548776662)%1.0); ph=math.pi*((k*0.5698402910)%1.0)
    sp=2000+500*((k*0.3)%1.0)
    vx=sp*math.cos(th)*(math.sin(ph) if dim==3 else 1); vy=sp*math.sin(th)*(math.sin(ph) if dim==3 else 1)
    vz=0.0 if dim==2 else sp*math.cos(ph)
    L.append("create_particles air single %s %.6f %.6f %.6f %.4f %.4f %.4f"%('N' if k%3 else 'O',x,y,z,vx,vy,vz))
L.append("timestep 0.0001")
if bal>0 and bst=="alt":
    L.append("fix bal balance %d 1.0 rcb part axes x"%bal)
    L.append("fix bal2 balance %d 1.0 rcb part axes y"%(2*bal))
elif bal>0: L.append("fix bal balance %d 1.0 %s"%(bal,bst))
L.append("dump 1 grid all 1 dump.grid id c_COMP[*]\ndump_modify 1 format float %.12g\ndump 2 grid all 5 dump.ave id f_AVE[*]\ndump_modify 2 format float %.12g")
L.append("stats 1\nstats_style step np nscoll nscheck" + (" f_bal f_bal[1] f_bal[2] f_bal[3]" if bal>0 else "") + "")
L.append("run %d"%nrun)
open(out,'w').write("\n".join(L)+"\n")
