#!/bin/bash
D=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R1
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
BS=$S/final/bsync/src/spa_; A=$S/bmpi_base/src/spa_kokkos_omp; C=$D/bcpu_B/src/spa_
cd $D
for np in 1 2 3 4; do ./run.sh $C C_f2a_$np $np in.f2a; ./run.sh $C C_r2a_$np $np in.r2a; done
./run.sh $C C_f3a_2 2 in.f3a; ./run.sh $C C_f3a_3 3 in.f3a; ./run.sh $C C_r3a_2 2 in.r3a; ./run.sh $C C_r3a_4 4 in.r3a
./run.sh $A A_r2a_3 3 in.r2a; ./run.sh $A A_f3a_3 3 in.f3a; ./run.sh $A A_r3a_3 3 in.r3a
./run.sh $BS K_r2a_1 1 in.r2a -k on -sf kk
./run.sh $BS K_f3a_1 1 in.f3a -k on -sf kk
./run.sh $BS K_r2a_2 2 in.r2a -k on -sf kk
./run.sh $BS K_f3a_2 2 in.f3a -k on -sf kk
./run.sh $BS K_r3a_3 3 in.r3a -k on -sf kk
./run.sh $BS K_f2a_4 4 in.f2a -k on -sf kk
echo MATRIXDONE
