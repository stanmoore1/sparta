#!/bin/bash
# run.sh BIN TAG NP INFILE [extra args]
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
D=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R1
BIN=$1; TAG=$2; NP=$3; IN=$4; shift 4
mkdir -p $D/runs/$TAG && cd $D/runs/$TAG && cp $D/air.species $D/b2d $D/b3d . && \
timeout 1500 mpirun --allow-run-as-root --oversubscribe -np $NP $BIN -in $D/$IN "$@" > out.log 2>&1; echo "$TAG exit $?"
