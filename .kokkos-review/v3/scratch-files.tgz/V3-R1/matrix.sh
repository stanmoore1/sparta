#!/bin/bash
D=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R1
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
BS=$S/final/bsync/src/spa_; A=$S/bmpi_base/src/spa_kokkos_omp
cd $D
for cfg in f2a r2a f3a r3a; do
  for np in 1 2 3 4; do
    ./run.sh $BS S_${cfg}_$np $np in.$cfg
    ./run.sh $BS K_${cfg}_$np $np in.$cfg -k on -sf kk
    [ $np -gt 1 ] && ./run.sh $A A_${cfg}_$np $np in.$cfg
    [ $np -gt 1 ] && ./run.sh $A AK_${cfg}_$np $np in.$cfg -k on t 1 -sf kk
  done
done
echo MATRIXDONE
