| example (#decks) | Bw1 | Bw2 | Ba1 | Ba2 | Bp1 | Bp2 |
|---|---|---|---|---|---|---|
| ablation (3) | 1c 2r(P1,P2) | 0c 3r(P1,P2,P3) | 3c | 3c | 3c | 3c |
| adapt (3) | 3c | 0c 3r(P3) | 3c | 3c | 3c | 3c |
| adjust_temp (4) | 0c 4r(P1,P2) | 0c 4r(P1,P2,P3) | 4c | 4c | 4c | 4c |
| ambi (3) | 2c 1r(P1) | 1c 2r(P1,P3) | 3c | 3c | 3c | 3c |
| ambi_3body (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| axi (1) | 1c | 1c | 1c | 1c | 1c | 1c |
| bfield (2) | 2c | 0c 1r(P3) 1TO | 2c | 2c | 2c | 2c |
| chem (2) | 1c 1r(P1) | 0c 2r(P1,P3) | 2c | 2c | 2c | 2c |
| chem_rates (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| circle (3) | 2c 1r(P1,P2) | 0c 3r(P1,P2,P3) | 3c | 3c | 3c | 3c |
| collide (9) | 9c | 0c 9r(P3) | 9c | 9c | 9c | 9c |
| custom (26) | 18c 8r(P2) | 1c 25r(P2,P3) | 26c | 26c | 26c | 26c |
| cylinder (1) | 0c 1TO | 0c 1TO | 1c | 1c | 1c | 1c |
| emit (10) | 9c 1r(P1,P2) | 4c 6r(P1,P3) | 10c | 10c | 10c | 10c |
| explicit2implicit (7) | 6c 1r(P1,P2) | 0c 7r(P1,P2,P3) | 7c | 7c | 7c | 7c |
| fft (2) | 2c | 0c 2r(P3) | 2c | 2c | 2c | 2c |
| flowfile (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| free (2) | 1c 1r(P1,P2) | 0c 2r(P1,P2,P3) | 2c | 2c | 2c | 2c |
| implicit (4) | 1c 2r(P2) | 0c 3r(P2,P3) | 4c | 2c 2E | 4c | 4c |
| jagged (4) | 2c 2E | 2c 2E | 2c 2E | 2c 2E | 2c 2E | 2c 2E |
| mfp_mct (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| optmove (4) | 4c | 1c 3r(P3) | 4c | 4c | 4c | 4c |
| qk (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| regions (1) | 1c | 1c | 1c | 1c | 1c | 1c |
| relax_const (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| relax_variable (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| shock_tube (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| sphere (2) | 2c | 0c 2r(P3) | 2c | 2c | 2c | 2c |
| spiky (1) | 1c | 1c | 1c | 1c | 1c | 1c |
| step (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| surf (5) | 5c | 2c 3r(P3) | 5c | 5c | 5c | 5c |
| surf_collide (13) | 13c | 3c 10r(P3) | 13c | 13c | 13c | 13c |
| surf_react_adsorb (9) | 0c 9r(P1,P2) | 0c 9r(P1,P2,P3) | 9c | 9c | 9c | 9c |
| surf_react_heatflux (1) | 0c 1r(P1,P2) | 0c 1r(P1,P2) | 1c | 1c | 1c | 1c |
| tally_computes (4) | 0c 4r(P1,P2) | 0c 4r(P1,P2,P3) | 4c | 4c | 4c | 4c |
| thermostat (2) | 2c | 0c 2r(P3) | 2c | 2c | 2c | 2c |
| torque (1) | 0c 1r(P1) | 0c 1r(P1) | 1c | 1c | 1c | 1c |
| variable_timestep (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| vibrate (1) | 1c | 0c 1r(P3) | 1c | 1c | 1c | 1c |
| TOTAL | 139 runs: 99c 37r 1TO 2E | 139 runs: 17c 118r 2TO 2E | 140 runs: 138c 0r 0TO 2E | 140 runs: 136c 0r 0TO 4E | 140 runs: 138c 0r 0TO 2E | 140 runs: 138c 0r 0TO 2E |
