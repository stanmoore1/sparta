#!/bin/bash
# run.sh <dir> <input> <label> <bin> <mode: cpu|kk1|kk4|mpiN> [-var ...]
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
d=$1; inp=$2; lab=$3; bin=$4; mode=$5; shift 5
case $bin in A) B=$S/build_base/src/spa_kokkos_omp;; B) B=$S/build/src/spa_kokkos_omp;; Am) B=$S/bmpi_base/src/spa_kokkos_omp;; Bm) B=$S/bmpi_fixed/src/spa_kokkos_omp;; *) B=$bin;; esac
mkdir -p $d/$lab; cp $d/*.* $d/$lab/ 2>/dev/null; cd $d/$lab
pre=""; k=""
case $mode in cpu) k="";; kk1) k="-k on t 1 -sf kk";; kk4) k="-k on t 4 -sf kk";;
  mpi*) n=${mode#mpi}; pre="mpirun --allow-run-as-root --oversubscribe -np $n"; k="-k on t 1 -sf kk";;
  cmpi*) n=${mode#cmpi}; pre="mpirun --allow-run-as-root --oversubscribe -np $n"; k="";; esac
timeout 300 $pre $B $k -in $inp -echo none -screen none -log log.txt "$@" > out.txt 2>&1
echo "$lab rc=$?" ; grep -h "ERROR" log.txt out.txt | head -3
