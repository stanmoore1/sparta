seed	    	    54345
dimension   	    3
timestep 	    5e-9
global              nrho 1.E22
global              fnum 1000 comm/sort yes
boundary	    r r r
create_box  	    0 1e-5 0 1e-5 0 1e-5
create_grid 	    3 3 3
species		    co2.species N2 CO2 vibfile co2.species.vib
mixture             mix CO2 frac 0.7
mixture             mix N2 frac 0.3
mixture             mix group all
mixture		    mix vstream 0.0 0.0 0.0 temp 20000 trot 20000.00 tvib 20000.0


collide		    vss all tiny.vss
collide_modify      vibrate discrete rotate smooth
fix vm vibmode
create_particles    mix n 0 twopass
compute             a tvib/grid all mix mode
compute             b tvib/grid all species mode
compute             Sa reduce ave c_a[1]

fix                 ag ave/grid all 1 5 5 c_a[*] c_b[*]

stats_style	    step np nattempt ncoll c_Sa
stats_modify        format float %.15g
stats		    5
dump                1 grid all 5 dump.grid id c_a[*] c_b[*] f_ag[*]
dump_modify         1 format float %.15g
run 		    20
