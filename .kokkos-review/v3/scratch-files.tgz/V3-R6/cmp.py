import sys,re
def stats(f):
    out=[];on=False
    for l in open(f,errors='replace'):
        if l.split()[:1]==['Step']: on=True; continue
        if l.startswith('Loop time'): on=False; continue
        if on and re.match(r'^\s*-?\d',l): out.append([float(x) for x in l.split()])
    return out
def dump(f):
    d={};ts=None;lines=open(f).read().split('ITEM: TIMESTEP\n')[1:]
    for blk in lines:
        ls=blk.split('\n'); ts=int(ls[0]); i=ls.index([x for x in ls if x.startswith('ITEM: CELLS')][0])
        for l in ls[i+1:]:
            if l.strip(): v=l.split(); d[(ts,v[0])]=[float(x) for x in v[1:]]
    return d
def rel(a,b): return abs(a-b)/max(abs(a),abs(b),1e-300)
a,b=sys.argv[1],sys.argv[2]
sa,sb=stats(a+'/log.txt'),stats(b+'/log.txt')
m=0; 
for ra,rb in zip(sa,sb):
    for x,y in zip(ra,rb): m=max(m,rel(x,y))
print('stats rows',len(sa),len(sb),'maxrel',m, 'ncols',len(sa[0]) if sa else 0)
import os
if os.path.exists(a+'/dump.grid') or os.path.exists(a+'/dump.grid.0'):
  import glob
  da={};db={}
  for f in glob.glob(a+'/dump.grid*'): da.update(dump(f))
  for f in glob.glob(b+'/dump.grid*'): db.update(dump(f))
  m=0;mk=None;nz=0
  for k in da:
    if k not in db: print('missing',k); break
    for i,(x,y) in enumerate(zip(da[k],db[k])):
      if x!=0: nz+=1
      r=rel(x,y)
      if r>m: m=r;mk=(k,i,x,y)
  print('dump entries',len(da),len(db),'nonzero',nz,'maxrel',m,mk)
