#!/bin/bash
cd /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R5/ex2
for i in emit.surf.subsonic emit.face emit.surf.mflow emit.surf.flow.region adapt.static; do
  SPARTA_KOKKOS_STALE= SPARTA_KOKKOS_STALE_STRICT=1 timeout 1200 /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bsync/src/spa_ -k on -sf kk -in in.$i -echo none -screen none -log log.Bs.$i > out.Bs.$i 2>&1; echo "$i Bs rc=$?"
  OMP_NUM_THREADS=1 timeout 900 /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/../build/src/spa_kokkos_omp -k on t 1 -sf kk -in in.$i -echo none -screen none -log log.Bo.$i > out.Bo.$i 2>&1; echo "$i Bo rc=$?"
done
echo DONE
