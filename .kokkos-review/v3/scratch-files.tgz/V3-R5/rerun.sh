#!/bin/bash
BO=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/../build/src/spa_kokkos_omp; BA=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/../build_base/src/spa_kokkos_omp
for t in t1 t2 t3; do cd /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R5/$t
  OMP_NUM_THREADS=1 timeout 600 $BO -k on t 1 -sf kk -in in.$t -echo none -screen none -log log.B2 > out.B2 2>&1; echo "$t B2 rc=$?"
  OMP_NUM_THREADS=1 timeout 600 $BA -k on t 1 -sf kk -in in.$t -echo none -screen none -log log.A2 > out.A2 2>&1; echo "$t A2 rc=$?"
done
cd /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R5/ex
for i in step.set step.read.restart step.set.restart circle.set.fix circle.file.fix cube.set cube.set.restart collide.create step.temp.remove; do
  OMP_NUM_THREADS=1 timeout 900 $BO -k on t 1 -sf kk -in in.custom.$i -echo none -screen none -log log.Bo2.$i > /dev/null 2>&1; echo "$i Bo2 rc=$?"
  OMP_NUM_THREADS=1 timeout 900 $BA -k on t 1 -sf kk -in in.custom.$i -echo none -screen none -log log.Ao2.$i > /dev/null 2>&1; echo "$i Ao2 rc=$?"
done
cd /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R5/ex2
for i in emit.surf.subsonic emit.face emit.surf.mflow emit.surf.flow.region adapt.static; do
  OMP_NUM_THREADS=1 timeout 900 $BO -k on t 1 -sf kk -in in.$i -echo none -screen none -log log.Bo2.$i > /dev/null 2>&1; echo "$i Bo2 rc=$?"
  OMP_NUM_THREADS=1 timeout 900 $BA -k on t 1 -sf kk -in in.$i -echo none -screen none -log log.Ao2.$i > /dev/null 2>&1; echo "$i Ao2 rc=$?"
done
rm -f /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R5/ex*/*.ppm
echo DONE
