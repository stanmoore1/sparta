// V3-R2 driver: Kokkos side
#include <mpi.h>
#include "sparta.h"
#include "kokkos.h"
#include "remap3d_kokkos.h"
#include "remap2d_kokkos.h"
#include "fft3d_kokkos.h"
#include "fft2d_kokkos.h"

using namespace SPARTA_NS;
typedef FFTArrayTypes<SPADeviceType> FAT;

static FAT::t_FFT_SCALAR_1d to_dev(const double *h, int n)
{
  FAT::t_FFT_SCALAR_1d d("drv",n > 0 ? n : 0);
  auto hm = Kokkos::create_mirror_view(d);
  for (int i = 0; i < n; i++) hm(i) = h[i];
  Kokkos::deep_copy(d,hm);
  return d;
}
static void from_dev(FAT::t_FFT_SCALAR_1d d, double *h, int n)
{
  auto hm = Kokkos::create_mirror_view(d);
  Kokkos::deep_copy(hm,d);
  for (int i = 0; i < n; i++) h[i] = hm(i);
}

void kk_remap3d(SPARTA *spa, MPI_Comm comm, int *in, int *out, int nqty, int permute,
                int memory, int coll, const double *indata, int nin, double *outdata, int nout,
                int nrepeat)
{
  RemapKokkos3d<SPADeviceType> *r = new RemapKokkos3d<SPADeviceType>(spa);
  auto plan = r->remap_3d_create_plan_kokkos(comm,in[0],in[1],in[2],in[3],in[4],in[5],
                                             out[0],out[1],out[2],out[3],out[4],out[5],
                                             nqty,permute,memory,2,coll,0);
  if (!plan) { printf("plan null\n"); MPI_Abort(comm,1); }
  auto d_in = to_dev(indata,nin);
  auto d_out = to_dev(outdata,nout);
  FAT::t_FFT_SCALAR_1d d_buf("buf",nout > 0 ? nout : 1);
  for (int k = 0; k < nrepeat; k++)
    r->remap_3d_kokkos(d_in,d_out,d_buf,plan);
  from_dev(d_out,outdata,nout);
  r->remap_3d_destroy_plan_kokkos(plan);
  delete r;
}

void kk_fft3d(SPARTA *spa, MPI_Comm comm, int nx, int ny, int nz, int *in, int *out,
              int scaled, int permute, int coll, int flag, const double *indata, int nin,
              double *outdata, int nout, int roundtrip)
{
  int nbuf;
  FFT3dKokkos<SPADeviceType> *f =
    new FFT3dKokkos<SPADeviceType>(spa,comm,nx,ny,nz,in[0],in[1],in[2],in[3],in[4],in[5],
                                   out[0],out[1],out[2],out[3],out[4],out[5],
                                   scaled,permute,&nbuf,coll,0);
  int n = nin > nout ? nin : nout;
  double *tmp = new double[n > 0 ? n : 1]();
  for (int i = 0; i < nin; i++) tmp[i] = indata[i];
  auto d = to_dev(tmp,n);
  f->compute(d,d,flag);
  if (roundtrip) {
    delete f;
    // backward from out layout back to in layout, permute 0
    f = new FFT3dKokkos<SPADeviceType>(spa,comm,nx,ny,nz,in[0],in[1],in[2],in[3],in[4],in[5],
                                       in[0],in[1],in[2],in[3],in[4],in[5],
                                       scaled,0,&nbuf,coll,0);
    // re-run forward with in==out, then backward
    auto d2 = to_dev(tmp,n);
    f->compute(d2,d2,1);
    f->compute(d2,d2,-1);
    d = d2;
  }
  from_dev(d,outdata,nout);
  delete [] tmp;
  delete f;
}

void kk_fft2d(SPARTA *spa, MPI_Comm comm, int nx, int ny, int *in, int *out,
              int scaled, int permute, int coll, int flag, const double *indata, int nin,
              double *outdata, int nout, int roundtrip)
{
  int nbuf;
  FFT2dKokkos<SPADeviceType> *f =
    new FFT2dKokkos<SPADeviceType>(spa,comm,nx,ny,in[0],in[1],in[2],in[3],
                                   out[0],out[1],out[2],out[3],
                                   scaled,permute,&nbuf,coll,0);
  int n = nin > nout ? nin : nout;
  double *tmp = new double[n > 0 ? n : 1]();
  for (int i = 0; i < nin; i++) tmp[i] = indata[i];
  auto d = to_dev(tmp,n);
  f->compute(d,d,flag);
  if (roundtrip) {
    delete f;
    f = new FFT2dKokkos<SPADeviceType>(spa,comm,nx,ny,in[0],in[1],in[2],in[3],
                                       in[0],in[1],in[2],in[3],
                                       scaled,0,&nbuf,coll,0);
    auto d2 = to_dev(tmp,n);
    f->compute(d2,d2,1);
    f->compute(d2,d2,-1);
    d = d2;
  }
  from_dev(d,outdata,nout);
  delete [] tmp;
  delete f;
}

void kk_remap2d(SPARTA *spa, MPI_Comm comm, int *in, int *out, int nqty, int permute,
                int memory, const double *indata, int nin, double *outdata, int nout)
{
  RemapKokkos2d<SPADeviceType> *r = new RemapKokkos2d<SPADeviceType>(spa);
  auto plan = r->remap_2d_create_plan_kokkos(comm,in[0],in[1],in[2],in[3],out[0],out[1],out[2],out[3],
                                             nqty,permute,memory,FFT_PRECISION,0,0);
  if (!plan) { printf("kk remap2d plan null\n"); MPI_Abort(comm,1); }
  auto d_in = to_dev(indata,nin);
  auto d_out = to_dev(outdata,nout);
  FAT::t_FFT_SCALAR_1d d_buf("buf",nout > 0 ? nout : 1);
  r->remap_2d_kokkos(d_in,d_out,d_buf,plan);
  from_dev(d_out,outdata,nout);
  r->remap_2d_destroy_plan_kokkos(plan);
  delete r;
}
