// V3-R2 standalone driver for remap3d/fft3d/fft2d Kokkos vs CPU
#include <mpi.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <vector>
#include <string>
#include "sparta.h"

using namespace SPARTA_NS;

void kk_remap3d(SPARTA *, MPI_Comm, int *, int *, int, int, int, int, const double *, int, double *, int, int);
void cpu_remap3d(MPI_Comm, int *, int *, int, int, int, int, const double *, int, double *, int);
void kk_fft3d(SPARTA *, MPI_Comm, int, int, int, int *, int *, int, int, int, int, const double *, int, double *, int, int);
void cpu_fft3d(SPARTA *, MPI_Comm, int, int, int, int *, int *, int, int, int, int, const double *, int, double *, int);
void kk_fft2d(SPARTA *, MPI_Comm, int, int, int *, int *, int, int, int, int, const double *, int, double *, int, int);
void kk_remap2d(SPARTA *, MPI_Comm, int *, int *, int, int, int, const double *, int, double *, int);
void cpu_remap2d(MPI_Comm, int *, int *, int, int, int, const double *, int, double *, int);
void cpu_fft2d(SPARTA *, MPI_Comm, int, int, int *, int *, int, int, int, int, const double *, int, double *, int);

static int me, np;

// mode 0 even, 1 last rank idle + skew, 2 first rank idle + skew, 3 skew no idle
static void split(int N, int P, int r, int mode, int &lo, int &hi)
{
  std::vector<double> w(P);
  for (int s = 0; s < P; s++) {
    if (mode == 0) w[s] = 1;
    else if (mode == 1) w[s] = (s == P-1 && P > 1) ? 0 : s+1;
    else if (mode == 2) w[s] = (P == 1) ? 1 : ((s == 0) ? 0 : s);
    else w[s] = s+1;
  }
  double W = 0; for (double x : w) W += x;
  double c = 0; for (int s = 0; s < r; s++) c += w[s];
  lo = (int) floor(N*c/W + 1e-9);
  hi = (int) floor(N*(c+w[r])/W + 1e-9) - 1;
}

static double val(int i, int j, int k, int q) { return 1 + q + 3.0*(i + 31.0*(j + 37.0*k)); }
static double cval(int i, int j, int k, int q) {  // complex test data
  return sin(0.3*i + 0.7*j*j + 1.1*k + 0.5*q) + 0.1*q;
}

// box = ilo,ihi,jlo,jhi,klo,khi
static int bsize(int *b) {
  int a = b[1]-b[0]+1, c = b[3]-b[2]+1, d = b[5]-b[4]+1;
  if (a <= 0 || c <= 0 || d <= 0) return 0;
  return a*c*d;
}

// layout index of global (i,j,k) in box b with permute p
static int lidx(int *b, int p, int i, int j, int k) {
  int ni = b[1]-b[0]+1, nj = b[3]-b[2]+1, nk = b[5]-b[4]+1;
  int ii = i-b[0], jj = j-b[2], kk = k-b[4];
  if (p == 0) return (kk*nj + jj)*ni + ii;
  if (p == 1) return (ii*nk + kk)*nj + jj;
  return (jj*ni + ii)*nk + kk;
}

// dist: which axis is split for in/out and the mode
static void makebox(int *n, int axis, int mode, int *b, int axis2 = -1, int mode2 = 0)
{
  b[0] = 0; b[1] = n[0]-1; b[2] = 0; b[3] = n[1]-1; b[4] = 0; b[5] = n[2]-1;
  if (axis2 < 0) {
    split(n[axis],np,me,mode,b[2*axis],b[2*axis+1]);
  } else {
    // 2d proc grid px*py, px = 2 if np%2==0
    int px = (np % 2 == 0) ? 2 : 1, py = np/px;
    int mx = me % px, my = me / px;
    int lo,hi;
    std::vector<int> d;
    // split axis over px with mode, axis2 over py with mode2
    { std::vector<double> w; }
    int sv = np; (void) sv;
    // reuse split with P=px
    int savenp = np;
    np = px; split(n[axis],px,mx,mode,lo,hi); b[2*axis] = lo; b[2*axis+1] = hi;
    np = py; split(n[axis2],py,my,mode2,lo,hi); b[2*axis2] = lo; b[2*axis2+1] = hi;
    np = savenp;
  }
}

static int nfail = 0;
static unsigned long long H = 1469598103934665603ULL;
static void hashv(const std::vector<double> &v, int n) {
  for (int i = 0; i < n; i++) { unsigned long long b; memcpy(&b,&v[i],8);
    for (int k = 0; k < 8; k++) { H ^= (b >> (8*k)) & 0xff; H *= 1099511628211ULL; } }
}
static void report(const char *name, double err, double tol)
{
  double gerr;
  MPI_Allreduce(&err,&gerr,1,MPI_DOUBLE,MPI_MAX,MPI_COMM_WORLD);
  if (getenv("DRV_TOL")) tol = fmax(tol, atof(getenv("DRV_TOL")));
  int bad = !(gerr <= tol);
  if (bad) nfail++;
  if (me == 0) printf("%s %s maxerr=%g\n", bad ? "FAIL" : "ok  ", name, gerr);
  fflush(stdout);
}

int main(int argc, char **argv)
{
  MPI_Init(&argc,&argv);
  MPI_Comm_rank(MPI_COMM_WORLD,&me);
  MPI_Comm_size(MPI_COMM_WORLD,&np);
  const char *nt = getenv("DRV_THREADS") ? getenv("DRV_THREADS") : "2";
  const char *sel = getenv("DRV_SEL") ? getenv("DRV_SEL") : "";
  const char *sargv[] = {"spa","-k","on","t",nt,"-sf","kk","-echo","none","-log","none","-screen","none"};
  int sargc = 13;
  SPARTA *spa = new SPARTA(sargc,(char **)sargv,MPI_COMM_WORLD);

  // ---------------- remap3d
  if (!strstr(sel,"noremap")) {
  int n[3] = {5,4,6};
  struct Dist { int ax, mode, ax2, mode2; };
  std::vector<std::pair<Dist,Dist>> dists = {
    {{2,0,-1,0},{0,0,-1,0}},   // even z-slab -> even x-slab
    {{2,1,-1,0},{0,1,-1,0}},   // last rank idle in and out (not in comm ring)
    {{2,1,-1,0},{0,2,-1,0}},   // last idle on input, first idle on output
    {{2,3,-1,0},{1,3,-1,0}},   // skew
    {{0,0,1,1},{2,1,-1,0}},    // brick in, idle out
    {{2,1,-1,0},{2,1,-1,0}},   // identical in/out with idle rank (self only)
  };
  for (size_t di = 0; di < dists.size(); di++)
  for (int nqty = 1; nqty <= (getenv("DRV_MAXQ") ? atoi(getenv("DRV_MAXQ")) : 3); nqty++)
  for (int permute = 0; permute <= 2; permute++)
  for (int memory = 0; memory <= 1; memory++)
  for (int coll = 0; coll <= 1; coll++) {
    int in[6], out[6];
    Dist a = dists[di].first, b = dists[di].second;
    makebox(n,a.ax,a.mode,in,a.ax2,a.mode2);
    makebox(n,b.ax,b.mode,out,b.ax2,b.mode2);
    int nin = bsize(in)*nqty, nout = bsize(out)*nqty;
    std::vector<double> din(nin+1), exp(nout+1), got(nout+1,-7), gcpu(nout+1,-7);
    for (int k = in[4]; k <= in[5]; k++) for (int j = in[2]; j <= in[3]; j++)
      for (int i = in[0]; i <= in[1]; i++) for (int q = 0; q < nqty; q++)
        din[lidx(in,0,i,j,k)*nqty+q] = val(i,j,k,q);
    for (int k = out[4]; k <= out[5]; k++) for (int j = out[2]; j <= out[3]; j++)
      for (int i = out[0]; i <= out[1]; i++) for (int q = 0; q < nqty; q++)
        exp[lidx(out,permute,i,j,k)*nqty+q] = val(i,j,k,q);
    char name[256];
    snprintf(name,256,"remap3d dist=%zu nqty=%d permute=%d memory=%d coll=%d",di,nqty,permute,memory,coll);
    if (!strstr(sel,"nokk")) {
      kk_remap3d(spa,MPI_COMM_WORLD,in,out,nqty,permute,memory,coll,din.data(),nin,got.data(),nout,2);
      hashv(got,nout); double err = 0; for (int i = 0; i < nout; i++) err = fmax(err,fabs(got[i]-exp[i]));
      std::string s = std::string("KK  ") + name; report(s.c_str(),err,0);
    }
    if (!strstr(sel,"nocpu")) {
      cpu_remap3d(MPI_COMM_WORLD,in,out,nqty,permute,memory,coll,din.data(),nin,gcpu.data(),nout);
      hashv(gcpu,nout); double err = 0; for (int i = 0; i < nout; i++) err = fmax(err,fabs(gcpu[i]-exp[i]));
      std::string s = std::string("CPU ") + name; report(s.c_str(),err,0);
    }
  }
  }

  // ---------------- fft3d
  if (!strstr(sel,"nofft3")) {
  int n[3] = {7,11,6};
  int modes[3] = {0,1,2};
  for (int mi : modes)
  for (int variant = 0; variant < 2; variant++)
  for (int coll = 0; coll <= 1; coll++)
  for (int flag = 1; flag >= -1; flag -= 2) {
    int in[6], out[6], permute;
    makebox(n,2,mi,in);
    if (variant == 0) { for (int t = 0; t < 6; t++) out[t] = in[t]; permute = 0; }
    else { makebox(n,1,mi,out); permute = 2; }   // out has full k -> no post_plan
    int nin = 2*bsize(in), nout = 2*bsize(out);
    std::vector<double> din(nin+1), gk(nout+1), gc(nout+1);
    for (int k = in[4]; k <= in[5]; k++) for (int j = in[2]; j <= in[3]; j++)
      for (int i = in[0]; i <= in[1]; i++) for (int q = 0; q < 2; q++)
        din[lidx(in,0,i,j,k)*2+q] = cval(i,j,k,q);
    kk_fft3d(spa,MPI_COMM_WORLD,n[0],n[1],n[2],in,out,0,permute,coll,flag,din.data(),nin,gk.data(),nout,0);
    cpu_fft3d(spa,MPI_COMM_WORLD,n[0],n[1],n[2],in,out,0,permute,coll,flag,din.data(),nin,gc.data(),nout);
    double err = 0, mx = 0;
    for (int i = 0; i < nout; i++) { err = fmax(err,fabs(gk[i]-gc[i])); mx = fmax(mx,fabs(gc[i])); }
    char name[256];
    hashv(gk,nout); hashv(gc,nout);
    snprintf(name,256,"fft3d KK-vs-CPU mode=%d variant=%d(permute=%d) coll=%d flag=%d (|max|=%.3g)",mi,variant,permute,coll,flag,mx);
    report(name,err,1e-10);
    // round trip scaled
    std::vector<double> rt(nin+1);
    kk_fft3d(spa,MPI_COMM_WORLD,n[0],n[1],n[2],in,in,1,0,coll,1,din.data(),nin,rt.data(),nin,1);
    hashv(rt,nin); err = 0; for (int i = 0; i < nin; i++) err = fmax(err,fabs(rt[i]-din[i]));
    snprintf(name,256,"fft3d KK scaled roundtrip mode=%d coll=%d",mi,coll);
    if (variant == 0 && flag == 1) report(name,err,1e-12);
  }
  }

  // ---------------- remap2d
  if (!strstr(sel,"noremap2")) {
  int n[3] = {6,5,1};
  int dl[6][4] = {{1,0,0,0},{1,1,0,1},{1,1,0,2},{1,3,1,3},{0,0,1,1},{1,1,1,1}};  // in axis,mode, out axis,mode
  for (int di = 0; di < 6; di++)
  for (int nqty = 1; nqty <= 3; nqty++)
  for (int permute = 0; permute <= 1; permute++)
  for (int memory = 0; memory <= 1; memory++) {
    int in[6], out[6];
    makebox(n,dl[di][0],dl[di][1],in); makebox(n,dl[di][2],dl[di][3],out);
    int nin = bsize(in)*nqty, nout = bsize(out)*nqty;
    std::vector<double> din(nin+1), exp(nout+1), got(nout+1,-7), gcpu(nout+1,-7);
    for (int j = in[2]; j <= in[3]; j++) for (int i = in[0]; i <= in[1]; i++) for (int q = 0; q < nqty; q++)
      din[lidx(in,0,i,j,0)*nqty+q] = val(i,j,0,q);
    for (int j = out[2]; j <= out[3]; j++) for (int i = out[0]; i <= out[1]; i++) for (int q = 0; q < nqty; q++)
      exp[lidx(out,permute,i,j,0)*nqty+q] = val(i,j,0,q);
    int in4[4] = {in[0],in[1],in[2],in[3]}, out4[4] = {out[0],out[1],out[2],out[3]};
    char name[256];
    snprintf(name,256,"remap2d dist=%d nqty=%d permute=%d memory=%d",di,nqty,permute,memory);
    if (!strstr(sel,"nokk")) {
      kk_remap2d(spa,MPI_COMM_WORLD,in4,out4,nqty,permute,memory,din.data(),nin,got.data(),nout);
      hashv(got,nout); double err = 0; for (int i = 0; i < nout; i++) err = fmax(err,fabs(got[i]-exp[i]));
      std::string s = std::string("KK  ") + name; report(s.c_str(),err,0);
    }
    if (!strstr(sel,"nocpu")) {
      cpu_remap2d(MPI_COMM_WORLD,in4,out4,nqty,permute,memory,din.data(),nin,gcpu.data(),nout);
      hashv(gcpu,nout); double err = 0; for (int i = 0; i < nout; i++) err = fmax(err,fabs(gcpu[i]-exp[i]));
      std::string s = std::string("CPU ") + name; report(s.c_str(),err,0);
    }
  }
  }

  // ---------------- fft2d
  if (!strstr(sel,"nofft2")) {
  int n[3] = {7,10,1};
  int modes[3] = {0,1,2};
  for (int mi : modes)
  for (int variant = 0; variant < 2; variant++)
  for (int coll = 0; coll <= (strstr(sel,"coll2") ? 1 : 0); coll++)
  for (int flag = 1; flag >= -1; flag -= 2) {
    int in[6], out[6], permute;
    makebox(n,1,mi,in);
    if (variant == 0) { for (int t = 0; t < 6; t++) out[t] = in[t]; permute = 0; }
    else { makebox(n,0,mi,out); permute = 1; }   // out has full j -> no post_plan
    int nin = 2*bsize(in), nout = 2*bsize(out);
    std::vector<double> din(nin+1), gk(nout+1), gc(nout+1);
    for (int j = in[2]; j <= in[3]; j++) for (int i = in[0]; i <= in[1]; i++)
      for (int q = 0; q < 2; q++) din[lidx(in,0,i,j,0)*2+q] = cval(i,j,0,q);
    int in4[4] = {in[0],in[1],in[2],in[3]}, out4[4] = {out[0],out[1],out[2],out[3]};
    if (!strstr(sel,"nokk2")) kk_fft2d(spa,MPI_COMM_WORLD,n[0],n[1],in4,out4,0,permute,coll,flag,din.data(),nin,gk.data(),nout,0);
    if (!strstr(sel,"nocpu2")) cpu_fft2d(spa,MPI_COMM_WORLD,n[0],n[1],in4,out4,0,permute,coll,flag,din.data(),nin,gc.data(),nout);
    {
      // naive DFT reference
      std::vector<double> ref(nout+1);
      for (int j = out[2]; j <= out[3]; j++) for (int i = out[0]; i <= out[1]; i++) {
        double re = 0, im = 0;
        for (int y = 0; y < n[1]; y++) for (int x = 0; x < n[0]; x++) {
          double ph = -flag*2*M_PI*((double)i*x/n[0] + (double)j*y/n[1]);
          double a = cval(x,y,0,0), b = cval(x,y,0,1);
          re += a*cos(ph) - b*sin(ph); im += a*sin(ph) + b*cos(ph);
        }
        int id = lidx(out,permute,i,j,0)*2; ref[id] = re; ref[id+1] = im;
      }
      hashv(gk,nout); hashv(gc,nout); double ek = 0, ec = 0;
      for (int t = 0; t < nout; t++) { ek = fmax(ek,fabs(gk[t]-ref[t])); ec = fmax(ec,fabs(gc[t]-ref[t])); }
      char nm[256];
      if (!strstr(sel,"nokk2")) { snprintf(nm,256,"fft2d KK-vs-DFT mode=%d variant=%d coll=%d flag=%d",mi,variant,coll,flag); report(nm,ek,1e-9); }
      if (!strstr(sel,"nocpu2")) { snprintf(nm,256,"fft2d CPU-vs-DFT mode=%d variant=%d coll=%d flag=%d",mi,variant,coll,flag); report(nm,ec,1e-9); }
    }
    double err = 0, mx = 0;
    for (int i = 0; i < nout; i++) { err = fmax(err,fabs(gk[i]-gc[i])); mx = fmax(mx,fabs(gc[i])); }
    char name[256];
    snprintf(name,256,"fft2d KK-vs-CPU mode=%d variant=%d(permute=%d) coll=%d flag=%d (|max|=%.3g)",mi,variant,permute,coll,flag,mx);
    report(name,err,1e-10);
    if (variant == 0 && flag == 1) {
      std::vector<double> rt(nin+1);
      kk_fft2d(spa,MPI_COMM_WORLD,n[0],n[1],in4,in4,1,0,coll,1,din.data(),nin,rt.data(),nin,1);
      hashv(rt,nin); err = 0; for (int i = 0; i < nin; i++) err = fmax(err,fabs(rt[i]-din[i]));
      snprintf(name,256,"fft2d KK scaled roundtrip mode=%d coll=%d",mi,coll);
      report(name,err,1e-12);
    }
  }
  }

  { std::vector<unsigned long long> all(np); MPI_Gather(&H,8,MPI_BYTE,all.data(),8,MPI_BYTE,0,MPI_COMM_WORLD);
    if (me == 0) { printf("HASH"); for (auto h : all) printf(" %016llx",h); printf("\n"); } }
  if (me == 0) printf("TOTAL FAIL %d\n",nfail);
  delete spa;
  MPI_Finalize();
  return 0;
}
