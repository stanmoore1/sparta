// V3-R2 driver: CPU side
#include <mpi.h>
#include "sparta.h"
#include "remap3d.h"
#include "fft3d_wrap.h"
#include "fft2d_wrap.h"
#include <cstring>
using namespace SPARTA_NS;

void cpu_remap3d(MPI_Comm comm, int *in, int *out, int nqty, int permute, int memory, int coll,
                 const double *indata, int nin, double *outdata, int nout)
{
  auto plan = remap_3d_create_plan(comm,in[0],in[1],in[2],in[3],in[4],in[5],
                                   out[0],out[1],out[2],out[3],out[4],out[5],
                                   nqty,permute,memory,2,coll);
  FFT_SCALAR *a = new FFT_SCALAR[nin+1], *o = new FFT_SCALAR[nout+1], *buf = new FFT_SCALAR[nout+1];
  for (int i = 0; i < nin; i++) a[i] = indata[i];
  remap_3d(a,o,buf,plan);
  for (int i = 0; i < nout; i++) outdata[i] = o[i];
  remap_3d_destroy_plan(plan);
  delete [] a; delete [] buf; delete [] o;
}

void cpu_fft3d(SPARTA *spa, MPI_Comm comm, int nx, int ny, int nz, int *in, int *out,
               int scaled, int permute, int coll, int flag, const double *indata, int nin,
               double *outdata, int nout)
{
  int nbuf;
  FFT3d *f = new FFT3d(spa,comm,nx,ny,nz,in[0],in[1],in[2],in[3],in[4],in[5],
                       out[0],out[1],out[2],out[3],out[4],out[5],scaled,permute,&nbuf,coll);
  int n = nin > nout ? nin : nout;
  FFT_SCALAR *tmp = new FFT_SCALAR[n+1]();
  for (int i = 0; i < nin; i++) tmp[i] = indata[i];
  f->compute(tmp,tmp,flag);
  for (int i = 0; i < nout; i++) outdata[i] = tmp[i];
  delete [] tmp; delete f;
}

void cpu_fft2d(SPARTA *spa, MPI_Comm comm, int nx, int ny, int *in, int *out,
               int scaled, int permute, int coll, int flag, const double *indata, int nin,
               double *outdata, int nout)
{
  int nbuf;
  FFT2d *f = new FFT2d(spa,comm,nx,ny,in[0],in[1],in[2],in[3],
                       out[0],out[1],out[2],out[3],scaled,permute,&nbuf,coll);
  int n = nin > nout ? nin : nout;
  FFT_SCALAR *tmp = new FFT_SCALAR[n+1]();
  for (int i = 0; i < nin; i++) tmp[i] = indata[i];
  f->compute(tmp,tmp,flag);
  for (int i = 0; i < nout; i++) outdata[i] = tmp[i];
  delete [] tmp; delete f;
}

#include "remap2d.h"
void cpu_remap2d(MPI_Comm comm, int *in, int *out, int nqty, int permute, int memory,
                 const double *indata, int nin, double *outdata, int nout)
{
  auto plan = remap_2d_create_plan(comm,in[0],in[1],in[2],in[3],out[0],out[1],out[2],out[3],
                                   nqty,permute,memory,FFT_PRECISION);
  if (!plan) { printf("cpu remap2d plan null\n"); MPI_Abort(comm,1); }
  FFT_SCALAR *a = new FFT_SCALAR[nin+1], *o = new FFT_SCALAR[nout+1], *buf = new FFT_SCALAR[nout+1];
  for (int i = 0; i < nin; i++) a[i] = indata[i];
  remap_2d(a,o,buf,plan);
  for (int i = 0; i < nout; i++) outdata[i] = o[i];
  remap_2d_destroy_plan(plan);
  delete [] a; delete [] buf; delete [] o;
}
