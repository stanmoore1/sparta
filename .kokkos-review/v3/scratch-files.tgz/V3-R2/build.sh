#!/bin/bash
# usage: build.sh A|B
set -e
D=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-R2
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
T=$1
if [ $T = B ]; then BD=$S/bmpi_fixed; SRC=/home/user/sparta/src; else BD=$S/bmpi_base; SRC=$S/base/src; fi
FL=$BD/src/CMakeFiles/sparta_kokkos_omp.dir/flags.make
INC=$(grep CXX_INCLUDES $FL | sed 's/CXX_INCLUDES = //')
DEF=$(grep CXX_DEFINES $FL | sed 's/CXX_DEFINES = //' | sed 's/-DSPARTA_GIT[^ ]*//g')
CF=$(grep CXX_FLAGS $FL | sed 's/CXX_FLAGS = //' | sed 's/-O3/-O2/g')
O=$D/obj$T$2; mkdir -p $O
EXTRA=$3
for f in $D/drv/main.cpp $D/drv/kk.cpp $D/drv/cpu.cpp $SRC/KOKKOS/remap3d_kokkos.cpp $SRC/KOKKOS/remap2d_kokkos.cpp $SRC/KOKKOS/fft3d_kokkos.cpp $SRC/KOKKOS/fft2d_kokkos.cpp $SRC/FFT/remap3d.cpp ${R2SRC:-$SRC/FFT/remap2d.cpp} $SRC/FFT/fft3d.cpp $SRC/FFT/fft2d.cpp $EXTRAF; do
  b=$(basename $f .cpp)
  mpicxx $DEF $INC $CF $EXTRA -c $f -o $O/$b.o &
done
wait
L=$D/lib$T
mpicxx -fopenmp $LDX -o $O/drv $O/*.o -Wl,--start-group $L/libsparta_kokkos_omp.a $L/FFT/libpkg_fft.a $L/KOKKOS/libpkg_kokkos.a $L/KOKKOS/lib/kokkos/containers/src/libkokkoscontainers.a $L/KOKKOS/lib/kokkos/algorithms/src/libkokkosalgorithms.a $L/KOKKOS/lib/kokkos/simd/src/libkokkossimd.a $L/KOKKOS/lib/kokkos/core/src/libkokkoscore.a -Wl,--end-group -ldl
echo built $O/drv
