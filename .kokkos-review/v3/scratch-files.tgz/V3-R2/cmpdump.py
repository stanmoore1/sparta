import sys
def rd(f):
    snaps=[];cur=None;mode=None
    for l in open(f):
        if l.startswith('ITEM: TIMESTEP'): mode='ts'; continue
        if mode=='ts': cur={};snaps.append((int(l),cur)); mode=None; continue
        if l.startswith('ITEM: CELLS'): mode='c'; continue
        if l.startswith('ITEM'): mode=None; continue
        if mode=='c':
            v=l.split(); cur[int(v[0])]=[float(x) for x in v[1:]]
    return snaps
a,b=rd(sys.argv[1]),rd(sys.argv[2])
worst=0
assert len(a)==len(b),(len(a),len(b))
for (ta,ca),(tb,cb) in zip(a,b):
    assert ta==tb and set(ca)==set(cb), (ta,tb,len(ca),len(cb))
    nc=len(next(iter(ca.values())))
    for c in range(nc):
        mx=max(abs(r[c]) for r in ca.values()) or 1
        e=max(abs(ca[k][c]-cb[k][c]) for k in ca)/mx
        worst=max(worst,e)
        if e>1e-9: print('step',ta,'col',c+1,'relerr',e)
print('ncells',len(a[0][1]),'snaps',len(a),'worst rel err',worst)
