#!/bin/bash
# Sequential builds for the final verification round. Log: /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/build.log
set -x
SRC=/home/user/sparta/cmake
SY=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/src_sync/cmake
ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/build -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_opt.log 2>&1; echo "opt rc=$?"
ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/bmpi_fixed -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_mpi.log 2>&1; echo "mpi rc=$?"
cmake -S $SY -B /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bsync -G Ninja -DCMAKE_BUILD_TYPE=Release -DBUILD_MPI=on -DBUILD_KOKKOS=on -DPKG_KOKKOS=on -DPKG_FFT=on -DKokkos_ENABLE_SERIAL=on -DKokkos_ENABLE_OPENMP=off -DKokkos_ENABLE_ATOMICS_BYPASS=ON -DSPARTA_KOKKOS_DEBUG_SYNC=on > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/c_sync.log 2>&1
ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bsync -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_sync.log 2>&1; echo "sync rc=$?"
cmake -S $SY -B /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bpoison -G Ninja -DCMAKE_BUILD_TYPE=RelWithDebInfo -DBUILD_MPI=on -DBUILD_KOKKOS=on -DPKG_KOKKOS=on -DPKG_FFT=on -DKokkos_ENABLE_SERIAL=on -DKokkos_ENABLE_OPENMP=off -DKokkos_ENABLE_ATOMICS_BYPASS=ON -DSPARTA_KOKKOS_DEBUG_SYNC=on -DSPARTA_KOKKOS_DEBUG_SYNC_ASAN=on > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/c_poison.log 2>&1
ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bpoison -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_poison.log 2>&1; echo "poison rc=$?"
for t in B A; do
  if [ $t = B ]; then src=$SRC; else src=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/base/cmake; fi
  cmake -S $src -B /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bcpu_$t -G Ninja -DCMAKE_BUILD_TYPE=Release -DBUILD_MPI=on -DPKG_FFT=on -DCMAKE_CXX_FLAGS="-g -Wall -Wextra" > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/c_cpu_$t.log 2>&1
  ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bcpu_$t -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_cpu_$t.log 2>&1; echo "cpu_$t rc=$?"
  cmake -S $src -B /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bstub_$t -G Ninja -DCMAKE_BUILD_TYPE=Release -DBUILD_MPI=off -DPKG_MPI_STUBS=on -DPKG_FFT=on > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/c_stub_$t.log 2>&1
  ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/bstub_$t -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_stub_$t.log 2>&1; echo "stub_$t rc=$?"
done
cmake -S $SRC -B /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/basan -G Ninja -DCMAKE_BUILD_TYPE=Debug -DBUILD_MPI=off -DPKG_MPI_STUBS=on -DPKG_FFT=on -DPKG_KOKKOS=on -DBUILD_KOKKOS=on -DKokkos_ENABLE_OPENMP=on -DKokkos_ENABLE_DEBUG_BOUNDS_CHECK=on -DCMAKE_CXX_FLAGS="-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer" -DCMAKE_EXE_LINKER_FLAGS="-fsanitize=address,undefined" > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/c_asan.log 2>&1
ninja -C /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/basan -j4 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/b_asan.log 2>&1; echo "asan rc=$?"
echo ALLDONE
