#!/bin/bash
# pair.sh cfgA "cmdA" cfgB "cmdB" : run both configs concurrently, 1 sim each
R=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T1/scripts/run_cfg.sh
NPAR=1 $R "$1" "$2" & 
NPAR=1 $R "$3" "$4" &
wait
