#!/bin/bash
# MPI kk: A_mpi vs B_mpi, np 2 then np 4, plus A repeat
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
R=$S/final/V3-T1/scripts/run_cfg.sh
AM=$S/bmpi_base/src/spa_kokkos_omp; BM=$S/bmpi_fixed/src/spa_kokkos_omp
export OMP_WAIT_POLICY=passive OMP_NUM_THREADS=1
MR="mpirun --allow-run-as-root --oversubscribe --bind-to none"
for np in 2 4; do
NPAR=1 $R mpi${np}_A "$MR -np $np $AM -k on t 1 -sf kk" &
NPAR=1 $R mpi${np}_B "$MR -np $np $BM -k on t 1 -sf kk" &
NPAR=1 $R mpi${np}_A2 "$MR -np $np $AM -k on t 1 -sf kk" &
wait
done
