#!/bin/bash
# perm.sh prefix : flagged-deck count for every 3+3 split of A,A2,A3,B,B2,B3 (real split first)
p=$1; R=(${p}_A ${p}_A2 ${p}_A3 ${p}_B ${p}_B2 ${p}_B3)
python3 - "${R[@]}" <<'PY'
import sys,itertools,subprocess
R=sys.argv[1:]
seen=set()
for g in itertools.combinations(range(6),3):
    h=tuple(i for i in range(6) if i not in g)
    if h in seen: continue
    seen.add(g)
    a=','.join(R[i] for i in g); b=','.join(R[i] for i in h)
    out=subprocess.run(['python3','stat2.py',a,b],capture_output=True,text=True).stdout
    fl=[l.split()[0] for l in out.splitlines() if ' CHECK ' in l]
    print(('REAL ' if g==(0,1,2) else 'perm ')+f"{a} | {b}: {len(fl)} flagged: {' '.join(fl)}")
PY
