#!/bin/bash
# worker.sh : pop jobs "cfg|cmd|dirfile" from $T/queue.txt and run them (NPAR=1)
T=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T1
export OMP_WAIT_POLICY=passive
while true; do
  job=$(flock $T/queue.lock bash -c "head -n1 $T/queue.txt; sed -i 1d $T/queue.txt")
  [ -z "$job" ] && break
  IFS='|' read cfg cmd df <<< "$job"
  echo "$(date +%T) start $cfg" >> $T/worker.log
  OMP_NUM_THREADS=${OMPN:-} DIRFILE=$df NPAR=1 $T/scripts/run_cfg.sh "$cfg" "$cmd"
  echo "$(date +%T) end $cfg" >> $T/worker.log
done
