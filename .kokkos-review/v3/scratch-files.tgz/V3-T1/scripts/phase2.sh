#!/bin/bash
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
R=$S/final/V3-T1/scripts/run_cfg.sh
AO=$S/build_base/src/spa_kokkos_omp; BO=$S/build/src/spa_kokkos_omp
export OMP_WAIT_POLICY=passive
NPAR=1 $R kk4_A "$AO -k on t 4 -sf kk" &
NPAR=1 $R kk4_B "$BO -k on t 4 -sf kk" &
NPAR=1 $R kk4_A2 "$AO -k on t 4 -sf kk" &
wait
