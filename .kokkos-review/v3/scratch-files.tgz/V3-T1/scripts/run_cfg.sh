#!/bin/bash
# run_cfg.sh <cfg> <launcher+bin+args (quoted)>  ; runs all examples, 2 example dirs at a time
T=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T1
CFG=$1; CMD=$2; OUT=$T/runs/$CFG; mkdir -p $OUT/work
echo "$CMD" > $OUT/CMD
export OUT CMD T
one() {
  e=$1; w=$OUT/work/$e
  grep -q "^DIRDONE $e$" $OUT/summary.txt 2>/dev/null && return
  [ -f $OUT/summary.txt ] && flock $OUT/summary.txt sed -i "/^$e\./d" $OUT/summary.txt
  rm -rf $w; cp -r $T/ex/$e $w
  for inp in $(cd $T/ex/$e && ls in.* | sort); do
    key=$e.$inp
    grep -q "^$key " $OUT/summary.txt 2>/dev/null && continue
    t0=$(date +%s)
    LK=""; [ $inp = in.implicit.3d.big ] && LK="flock $T/bigmem.lock"
    (cd $w && $LK timeout -k 30 ${TMO:-1800} $CMD -in $inp -echo none -screen $OUT/$key.screen -log $OUT/$key.log >/dev/null 2>$OUT/$key.err </dev/null); rc=$?
    t1=$(date +%s)
    st=OK
    grep -qE "ERROR" $OUT/$key.screen $OUT/$key.log $OUT/$key.err 2>/dev/null && st=ERROR
    grep -qiE "(^|[ \t])-?nan([ \t]|$)|[ \t]-?inf([ \t]|$)" $OUT/$key.log 2>/dev/null && st="$st,NAN"
    [ $rc -ne 0 ] && st="$st,rc=$rc"
    flock $OUT/summary.txt bash -c "echo '$key $st $((t1-t0))s' >> $OUT/summary.txt"
  done
  echo "DIRDONE $e" >> $OUT/summary.txt
  rm -rf $w; ln -sfn $T/ex/$e $w
}
export -f one
for e in $(ls $T/ex); do [ -e $OUT/work/$e ] || ln -sfn $T/ex/$e $OUT/work/$e; done
{ if [ -n "$DIRFILE" ]; then cat $DIRFILE; else ls $T/ex; fi; } | xargs -P ${NPAR:-2} -I{} bash -c 'one {}'
echo DONE >> $OUT/summary.txt
