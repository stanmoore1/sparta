#!/usr/bin/env python3
# cmp.py runA runB [runA2] : compare stats of two config run dirs
import sys,os,re,glob
T='/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T1/runs/'
def summ(d):
    s={}
    p=T+d+'/summary.txt'
    if os.path.exists(p):
        for l in open(p):
            f=l.split()
            if len(f)>=2: s[f[0]]=f[1]
    return s
num=re.compile(r'^\s*-?\d')
def thermo(f):
    rows=[];hdr=None
    if not os.path.exists(f): return rows
    for l in open(f,errors='replace'):
        if l.startswith('Step '):
            hdr=l.split(); rows.append(('H',tuple(hdr))); continue
        if l.startswith('Loop time'): hdr=None; continue
        if hdr and num.match(l):
            v=l.split()
            if len(v)!=len(hdr): continue
            rows.append(tuple(x for x,h in zip(v,hdr) if h!='CPU'))
    return rows
def warns(f):
    w=[]
    for fn in (f+'.log',f+'.screen'):
        if os.path.exists(fn):
            for l in open(fn,errors='replace'):
                if 'WARNING' in l:
                    w.append(re.sub(r':\d+\)',')',re.sub(r'\(/\S+/src/','(src/',l.strip())))
            break
    return w
def rel(a,b):
    try: x,y=float(a),float(b)
    except: return 0 if a==b else 1e9
    if x==y: return 0
    return abs(x-y)/max(abs(x),abs(y),1e-300)
def cmp(da,db,key):
    ta,tb=thermo(T+da+'/'+key+'.log'),thermo(T+db+'/'+key+'.log')
    if ta==tb: return 'IDENT',len(ta),0
    n=min(len(ta),len(tb)); first=next((i for i in range(n) if ta[i]!=tb[i]),n)
    mx=0
    for i in range(n):
        if ta[i][0]=='H' or tb[i][0]=='H': continue
        for a,b in zip(ta[i],tb[i]): mx=max(mx,rel(a,b))
    return 'DIFF',(first,len(ta),len(tb)),mx
if __name__=='__main__':
    da,db=sys.argv[1],sys.argv[2]
    sa,sb=summ(da),summ(db)
    for k in sorted(set(sa)|set(sb)):
        if k=='DONE': continue
        st,info,mx=cmp(da,db,k)
        wa,wb=warns(T+da+'/'+k),warns(T+db+'/'+k)
        nw=sorted(set(wb)-set(wa)); gw=sorted(set(wa)-set(wb))
        nanA=any(re.search(r'(?i)nan|inf',' '.join(r)) for r in thermo(T+da+'/'+k+'.log') if r[0]!='H')
        nanB=any(re.search(r'(?i)nan|inf',' '.join(r)) for r in thermo(T+db+'/'+k+'.log') if r[0]!='H')
        print(f"{k:55s} A={sa.get(k,'-'):12s} B={sb.get(k,'-'):12s} {st} {info} maxrel={mx:.3g}" + (" STATSNAN_A" if nanA else "") + (" STATSNAN_B" if nanB else "") + (f" NEWWARN={nw}" if nw else "") + (f" GONEWARN={gw}" if gw else ""))
