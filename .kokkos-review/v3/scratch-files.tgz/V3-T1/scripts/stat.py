#!/usr/bin/env python3
# stat.py cfgA cfgA2 cfgB [more A reps comma-sep] : time-averaged stats comparison for DIFF decks
import sys,os
sys.path.insert(0,os.path.dirname(__file__))
from cmp import thermo,T,summ,cmp
def means(d,k):
    rows=thermo(T+d+'/'+k+'.log'); hdr=None; cols={}
    seg=0
    for r in rows:
        if r[0]=='H': hdr=[h for h in r[1] if h!='CPU']; seg+=1; first=True; continue
        if first: first=False; continue   # skip initial row of each run
        for h,v in zip(hdr,r):
            if h=='Step': continue
            try: cols.setdefault((seg,h),[]).append(float(v))
            except: pass
    return {c:sum(v)/len(v) for c,v in cols.items() if v}
def rd(a,b,scale):
    return abs(a-b)/scale if scale>0 else (0 if a==b else 1e9)
A,A2,B=sys.argv[1:4]
for k in sorted(summ(A)):
    if k in ('DONE','DIRDONE') or k not in summ(B) or k not in summ(A2): continue
    if cmp(A,B,k)[0]=='IDENT' and cmp(A,A2,k)[0]=='IDENT': continue
    ma,ma2,mb=means(A,k),means(A2,k),means(B,k)
    worst=None
    for c in ma:
        if c not in mb or c not in ma2: continue
        s=max(abs(ma[c]),abs(mb[c]),abs(ma2[c]))
        if s==0: continue
        dab=rd(ma[c],mb[c],s); daa=rd(ma[c],ma2[c],s)
        score=dab/max(daa,1e-4)
        if worst is None or score>worst[0]: worst=(score,c,dab,daa)
    if worst is None: print(f"{k:50s} nocols"); continue
    sc,c,dab,daa=worst
    flag='CHECK' if (dab>3*daa and dab>2e-3) else 'ok'
    print(f"{k:50s} {flag:5s} worstcol={c[1]}(run{c[0]}) relAB={dab:.2e} relAA={daa:.2e} ratio={sc:.1f}")
