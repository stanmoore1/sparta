#!/bin/bash
# setup.sh: (re)create capped example tree $T/ex (idempotent: skips if $T/ex/.ok exists)
T=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T1
[ -e $T/ex/.ok ] && exit 0
rm -rf $T/ex; mkdir -p $T/ex
for d in /home/user/sparta/examples/*/; do e=$(basename $d); case $e in python|paraview|vtk) continue;; esac; cp -r $d $T/ex/$e; done
cd $T/ex && patch -p1 < $T/scripts/caps.diff || exit 1
cd $T/ex/implicit && for a in "2 101 101 1 12345 binary.101x101" "2 51 101 1 54321 binary.51x101" "3 21 21 21 12345 binary.21x21x21" "3 101 101 101 54321 binary.101x101x101"; do python3 $T/scripts/implicit_grid.py $a; done
cd $T/ex/jagged && python3 /home/user/sparta/tools/jagged3d.py 20 20 10 10 10 0.05 sdata.20x20x10x10x10
touch $T/ex/.ok
