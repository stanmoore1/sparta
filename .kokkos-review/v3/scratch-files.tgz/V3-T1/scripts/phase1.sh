#!/bin/bash
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
P=$S/final/V3-T1/scripts/pair.sh
AO=$S/build_base/src/spa_kokkos_omp; BO=$S/build/src/spa_kokkos_omp
$P kk1_A "$AO -k on t 1 -sf kk" kk1_B "$BO -k on t 1 -sf kk"
$P cpuopt_A "$AO" cpuopt_B "$BO"
$P kk4_A "$AO -k on t 4 -sf kk" kk4_B "$BO -k on t 4 -sf kk"
