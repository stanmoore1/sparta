#!/usr/bin/env python3
# stat2.py A1,A2,A3 B1,B2,B3 : per deck/column time-averaged mean, z-score of B-vs-A using pooled rep spread
import sys,os,math
sys.path.insert(0,os.path.dirname(__file__))
from cmp import summ,cmp
from tstat import means
As=sys.argv[1].split(','); Bs=sys.argv[2].split(',')
keys=[k for k in summ(As[0]) if k not in('DONE','DIRDONE') and all(k in summ(c) for c in As+Bs)]
for k in sorted(keys):
    if all(cmp(As[0],c,k)[0]=='IDENT' for c in As[1:]+Bs): continue
    MA=[means(c,k) for c in As]; MB=[means(c,k) for c in Bs]
    worst=None
    for col in MA[0]:
        if not all(col in m for m in MA+MB): continue
        a=[m[col] for m in MA]; b=[m[col] for m in MB]
        ma=sum(a)/len(a); mb=sum(b)/len(b)
        va=sum((x-ma)**2 for x in a)/(len(a)-1); vb=sum((x-mb)**2 for x in b)/(len(b)-1)
        sp=math.sqrt(((len(a)-1)*va+(len(b)-1)*vb)/(len(a)+len(b)-2))
        se=sp*math.sqrt(1/len(a)+1/len(b))
        rel=abs(mb-ma)/max(abs(ma),abs(mb),1e-300)
        z=abs(mb-ma)/se if se>0 else (0 if mb==ma else 99)
        if worst is None or z>worst[0]: worst=(z,col,rel,ma,mb,sp)
    if worst is None: print(f"{k:50s} nocols"); continue
    z,col,rel,ma,mb,sp=worst
    flag='CHECK' if z>4 and rel>1e-3 else 'ok'
    print(f"{k:50s} {flag:5s} maxz={z:5.1f} col={col[1]}(run{col[0]}) A={ma:.6g} B={mb:.6g} rel={rel:.2e} sdRep={sp:.3g}")
