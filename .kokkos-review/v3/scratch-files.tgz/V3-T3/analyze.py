#!/usr/bin/env python3
"""analyze.py <cfg> [<cfg> ...]: dedupe ASAN/LSan/UBSan reports in runs/<cfg>/asan/* and .err files.
Signature = kind + top 4 frames (function file:line, sanitizer/libc frames skipped, paths reduced to basename,
source root stripped so A and B signatures match modulo line numbers).  Prints per signature: kind, count of decks,
decks, frames.  -l: ignore line numbers in signature (for A vs B matching)."""
import sys, os, re, glob, collections
T3 = os.path.dirname(os.path.abspath(__file__))
noline = '-l' in sys.argv
cfgs = [a for a in sys.argv[1:] if not a.startswith('-')]
SKIP = re.compile(r'libsanitizer|asan_|ubsan_|lsan_|libc\.so|libstdc\+\+|/usr/include/c\+\+|libgcc|new_op|operator new|operator delete')
fr = re.compile(r'^\s*#(\d+) 0x[0-9a-f]+ in (.*?) (/\S+|\(\S+\))\s*$')

def frames(lines):
    out = []
    for l in lines:
        m = fr.match(l)
        if not m: continue
        fn, loc = m.group(2), m.group(3)
        if SKIP.search(loc) or SKIP.search(fn): continue
        loc = loc.strip('()')
        b = os.path.basename(loc)
        if noline: b = re.sub(r':\d+(:\d+)?$', '', b)
        fn = re.sub(r'\(.*', '', fn)[:80]
        out.append(fn + '@' + b)
        if len(out) >= 4: break
    return tuple(out)

def parse(path):
    txt = open(path, errors='replace').read().splitlines()
    reps = []; i = 0
    while i < len(txt):
        l = txt[i]
        m = re.search(r'ERROR: AddressSanitizer: (\S+)', l)
        if m:
            j = i + 1
            while j < len(txt) and not txt[j].startswith('SUMMARY'): j += 1
            reps.append(('ASAN ' + m.group(1), frames(txt[i:j]))); i = j; continue
        m = re.match(r'(Direct|Indirect) leak of (\d+) byte', l)
        if m:
            j = i + 1
            while j < len(txt) and txt[j].strip(): j += 1
            reps.append(('LEAK ' + m.group(1) + ' %s' % m.group(2), frames(txt[i:j]))); i = j; continue
        m = re.search(r'(\S+:\d+:\d+): runtime error: (.*)', l)
        if m:
            j = i + 1
            while j < len(txt) and txt[j].lstrip().startswith('#'): j += 1
            msg = re.sub(r'0x[0-9a-f]+', 'ADDR', m.group(2)); msg = re.sub(r'-?\d+(\.\d+)?(e[-+]\d+)?', 'N', msg)
            loc = os.path.basename(m.group(1));
            if noline: loc = re.sub(r':\d+:\d+$', '', loc)
            reps.append(('UBSAN ' + msg[:90] + ' @' + loc, frames(txt[i:j]))); i = j; continue
        if re.search(r'Kokkos::View ERROR|out of bounds|Kokkos ERROR', l):
            reps.append(('KOKKOS ' + l.strip()[:120], ()));
        i += 1
    return reps

sig = collections.defaultdict(set); leakbytes = collections.Counter()
for cfg in cfgs:
    for p in sorted(glob.glob(f'{T3}/runs/{cfg}/asan/*')) + sorted(glob.glob(f'{T3}/runs/{cfg}/*.err')):
        b = os.path.basename(p)
        key = re.sub(r'\.(asan|ubsan|vg)\.\d+$|\.err$', '', b)
        for kind, frs in parse(p):
            k = re.sub(r' \d+$', '', kind) if kind.startswith('LEAK') else kind
            if kind.startswith('LEAK'): leakbytes[(k, frs)] += int(kind.split()[-1])
            sig[(k, frs)].add(f'{cfg}:{key}')
for (k, frs), decks in sorted(sig.items(), key=lambda x: (x[0][0], -len(x[1]))):
    print(f'### {k} | decks={len(decks)}' + (f' bytes={leakbytes[(k,frs)]}' if k.startswith('LEAK') else ''))
    print('    frames: ' + ' <- '.join(frs))
    print('    decks: ' + ' '.join(sorted(decks)[:12]) + (' ...' if len(decks) > 12 else ''))
