#!/bin/bash
# setup: copy V3-T1 capped tree, then run N (N>=100) -> N/5. Idempotent (.ok marker).
T3=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T3
T1=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T1
[ -e $T3/ex/.ok ] && exit 0
[ -e $T1/ex/.ok ] || bash $T1/scripts/setup.sh || exit 1
rm -rf $T3/ex; cp -r $T1/ex $T3/ex; rm -f $T3/ex/.ok
for f in $T3/ex/*/in.*; do
  perl -pi -e 's/^(\s*run\s+)(\d+)/$1.($2>=100?int($2\/5):$2)/e' $f
done
touch $T3/ex/.ok
