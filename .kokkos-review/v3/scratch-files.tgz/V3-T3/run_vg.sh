#!/bin/bash
# run.sh <jobfile>: lines "cfg|binary args|exdir[|deck]"; 2 jobs at once (NPAR). Idempotent: summary keys skipped,
# partially-run dirs redone. Per deck: ASAN/UBSAN logs in runs/<cfg>/asan/<key>.*
T3=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T3
LOCK=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T1/bigmem.lock
export T3 LOCK
one() {
  IFS='|' read cfg cmd e deck <<< "$1"
  OUT=$T3/runs/$cfg; mkdir -p $OUT/asan $OUT/work; S=$OUT/summary.txt; touch $S
  tag=$e; [ -n "$deck" ] && tag=$e.$deck
  grep -q "^DIRDONE $tag$" $S && return
  [ -z "$deck" ] && flock $S sed -i "/^$e\./d" $S
  w=$OUT/work/$tag; rm -rf $w; cp -r $T3/ex/$e $w
  # sibling links (explicit2implicit needs ../ablation ../axi)
  for s in $(ls $T3/ex); do [ -e $OUT/work/$s ] || ln -sfn $T3/ex/$s $OUT/work/$s; done
  decks=$deck; [ -z "$decks" ] && decks=$(cd $T3/ex/$e && ls in.* | sort)
  for inp in $decks; do
    key=$e.$inp
    grep -q "^$key " $S && continue
    rm -f $OUT/asan/$key.*
    LK=""; [ $inp = in.implicit.3d.big ] && LK="flock $LOCK"
    t0=$(date +%s)
    (cd $w && KEY=$key VGOUT=$OUT/asan ASAN_OPTIONS=detect_leaks=1:halt_on_error=0:log_path=$OUT/asan/$key.asan \
      UBSAN_OPTIONS=print_stacktrace=1:halt_on_error=0:log_path=$OUT/asan/$key.ubsan \
      OMP_PROC_BIND=false $LK timeout -k 60 ${TMO:-5400} $cmd -in $inp -echo none -screen $OUT/$key.screen -log $OUT/$key.log >/dev/null 2>$OUT/$key.err </dev/null); rc=$?
    t1=$(date +%s)
    st=OK
    grep -qE "ERROR" $OUT/$key.screen $OUT/$key.log 2>/dev/null && st=ERROR
    na=$(cat $OUT/asan/$key.* 2>/dev/null | grep -cE "^(==[0-9]+==ERROR|SUMMARY|Direct leak|Indirect leak)|runtime error:")
    grep -qiE "bounds|abort|Kokkos::" $OUT/$key.err && st="$st,ERR"
    [ $rc -ne 0 ] && st="$st,rc=$rc"
    flock $S bash -c "echo '$key $st san=$na $((t1-t0))s' >> $S"
  done
  [ -z "$deck" ] && echo "DIRDONE $tag" >> $S
  rm -rf $w
}
export -f one
grep -v "^#" $1 | xargs -P ${NPAR:-2} -d '\n' -I{} bash -c 'one "{}"'
echo "JOBFILE DONE $1 $(date)" >> $T3/run.log
