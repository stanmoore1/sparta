#!/usr/bin/env python3
"""vganalyze.py <cfg>...: dedupe valgrind memcheck reports in runs/<cfg>/asan/*.vg.*.
Signature = kind + first 4 frames that have SPARTA source (file.cpp:N); line numbers dropped (-l default) so A and B match.
Blocks without any SPARTA source frame are counted as runtime noise (OpenMPI/PMIx/libc)."""
import sys, os, re, glob, collections
T3 = os.path.dirname(os.path.abspath(__file__))
KIND = re.compile(r'^==\d+== (Invalid (read|write|free)|Conditional jump|Use of uninitialised|Syscall param|Mismatched free|'
                  r'Source and destination overlap|Argument .* of function|\S+ bytes in \S+ blocks are (definitely|indirectly) lost)')
FR = re.compile(r'^==\d+==\s+(?:at|by) 0x[0-9A-F]+: (.*?) \((.*?)\)\s*$')
sig = collections.defaultdict(set); noise = collections.Counter(); summ = {}
for cfg in sys.argv[1:]:
    for p in sorted(glob.glob(f'{T3}/runs/{cfg}/asan/*.vg.*')):
        key = re.sub(r'\.vg\.\d+$', '', os.path.basename(p))
        L = open(p, errors='replace').read().splitlines()
        if not any('spa_' in l for l in L[:15]): continue   # helper process (orted etc.)
        for l in L:
            m = re.search(r'ERROR SUMMARY: (\d+) errors', l)
            if m: summ[(cfg, key)] = int(m.group(1))
        i = 0
        while i < len(L):
            m = KIND.match(L[i])
            if not m: i += 1; continue
            kind = m.group(1); kind = re.sub(r'^\S+ bytes in \S+ blocks are ', 'LEAK ', kind)
            j = i + 1; frs = []
            while j < len(L) and not re.match(r'^==\d+==\s*$', L[j]):
                f = FR.match(L[j])
                if f and re.search(r'\.(cpp|h):\d+$', f.group(2)) and len(frs) < 4:
                    frs.append(re.sub(r'\(.*', '', f.group(1))[:70] + '@' + re.sub(r':\d+$', '', f.group(2)))
                j += 1
            if frs and frs != ['main@main.cpp']: sig[(kind, tuple(frs))].add(f'{cfg}:{key}')
            else: noise[(cfg, kind)] += 1
            i = j
for (k, frs), d in sorted(sig.items(), key=lambda x: (x[0][0], -len(x[1]))):
    print(f'### {k} | decks={len(d)}\n    frames: ' + ' <- '.join(frs) + '\n    decks: ' + ' '.join(sorted(d)))
print('# noise (no SPARTA frame):', dict(noise))
print('# error summary per deck:', ' '.join(f'{c}:{k}={n}' for (c, k), n in sorted(summ.items())))
