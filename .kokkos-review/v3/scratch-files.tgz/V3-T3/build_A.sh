#!/bin/bash
# build A_asan: e071055f source, same flags as B_asan (build_all.sh basan line)
B=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T3/basan_A
[ -x $B/src/spa_ ] && [ -e $B/.ok ] && exit 0
cmake -S /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/base/cmake -B $B -G Ninja -DCMAKE_BUILD_TYPE=Debug -DBUILD_MPI=off -DPKG_MPI_STUBS=on -DPKG_FFT=on -DPKG_KOKKOS=on -DBUILD_KOKKOS=on -DKokkos_ENABLE_OPENMP=on -DKokkos_ENABLE_DEBUG_BOUNDS_CHECK=on -DCMAKE_CXX_FLAGS="-O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer" -DCMAKE_EXE_LINKER_FLAGS="-fsanitize=address,undefined" > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T3/c_A.log 2>&1 || exit 1
nice -n 5 ninja -C $B -j2 > /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T3/b_A.log 2>&1 && touch $B/.ok
echo "buildA rc=$?" >> /tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T3/b_A.log
