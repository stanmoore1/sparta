#!/bin/bash
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad; W=$S/final/V3-R4
# g.sh tag deck dir np bintype(opt|mpi) mode
tag=$1; deck=$2; dir=$3; np=$4; bt=$5
for v in A B; do
 if [ $bt = opt ]; then [ $v = A ] && BIN=$S/build_base/src/spa_kokkos_omp || BIN=$S/build/src/spa_kokkos_omp; PRE=""; else [ $v = A ] && BIN=$S/bmpi_base/src/spa_kokkos_omp || BIN=$S/bmpi_fixed/src/spa_kokkos_omp; PRE="mpirun --allow-run-as-root --oversubscribe -np $np"; fi
 for m in cpu kk kkr; do
  case $m in cpu) K="";; kk) K="-k on t 1 -sf kk";; kkr) K="-k on t 1 -sf kk -pk kokkos react/retry yes";; esac
  d=$W/work/g.$tag.$v.$m; rm -rf $d; mkdir -p $d; cp -r $W/decks/$dir/. $d; cd $d
  timeout 900 $PRE $BIN $K -in $deck -echo none -screen none -log $W/logs/$tag.$v.$m.log > /dev/null 2>$W/logs/$tag.$v.$m.err
  echo "$tag $v $m rc=$? $(grep -m1 ERROR $W/logs/$tag.$v.$m.log)"; cd $W; rm -rf $d
 done
done
for m in cpu kk kkr; do echo "$tag $m A-vs-B: $(python3 $W/cmp.py $W/logs/$tag.A.$m.log $W/logs/$tag.B.$m.log)"; done
echo "$tag B kk-vs-kkr: $(python3 $W/cmp.py $W/logs/$tag.B.kk.log $W/logs/$tag.B.kkr.log)"
