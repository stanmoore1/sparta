#!/bin/bash
# q.sh <A|B> <deckfile in decks/ambi> <steps> [kx...]
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad; W=$S/final/V3-R4
v=$1; deck=$2; n=$3; shift 3
[ $v = A ] && BIN=$S/build_base/src/spa_kokkos_omp || BIN=$S/build/src/spa_kokkos_omp
d=$W/work/q.$$; rm -rf $d; mkdir -p $d; cp -r $W/decks/${QD:-ambi}/. $d; cd $d
sed -i -E "s/^(run\s+)[0-9]+/\1$n/;s/^stats  +100/stats 5/" $deck
timeout 900 $BIN "$@" -in $deck -echo none 2>&1 | grep -E '^ +[0-9]+ +[0-9.e+-]+ +[0-9]+ |ERROR' | awk '{print $1,$3,$4,$5,$6,$7}' | tail -${TAILN:-3} | tr '\n' ';'; echo
cd $W; rm -rf $d
