import sys,re
def thermo(f):
    out=[];on=False
    try: L=open(f,errors='replace').readlines()
    except: return None
    for l in L:
        if l.split()[:1]==['Step']: on=True; out.append(l.split()); continue
        if l.startswith('Loop time'): on=False; continue
        if on and re.match(r'^\s*-?\d',l): s=l.split(); out.append(s[:1]+s[2:])
    return out
a,b=thermo(sys.argv[1]),thermo(sys.argv[2])
if a is None or b is None: print('MISSING'); sys.exit()
if a==b: print('IDENTICAL',len(a)); sys.exit()
n=min(len(a),len(b)); i=next((i for i in range(n) if a[i]!=b[i]),n)
print('DIFF row',i,len(a),len(b), a[i] if i<len(a) else '', '|', b[i] if i<len(b) else '')
