#!/bin/bash
# run.sh <tag> <exdir> <deck> [runlen]  -> runs A/B x cpu/kk
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
W=$S/final/V3-R4
tag=$1; ex=$2; deck=$3; rl=${4:-200}
for v in A B; do
  [ $v = A ] && BIN=$S/build_base/src/spa_kokkos_omp || BIN=$S/build/src/spa_kokkos_omp
  for m in cpu kk; do
    d=$W/work/$tag.$v.$m; rm -rf $d; mkdir -p $d; cp -r $ex/. $d/
    [ -f "$deck" ] && cp $deck $d/ 
    dn=$(basename $deck)
    sed -i -E "s/^(run\s+)[0-9]+/\1$rl/" $d/$dn
    sed -i -E '/^dump|^write_/d' $d/$dn
    K=""; [ $m = kk ] && K="-k on t 1 -sf kk $KX"
    (cd $d && timeout 600 $BIN $K -in $dn -echo none -screen none -log $W/logs/$tag.$v.$m.log >/dev/null 2>$W/logs/$tag.$v.$m.err)
    echo "$tag $v $m rc=$? $(grep -m1 ERROR $W/logs/$tag.$v.$m.log $W/logs/$tag.$v.$m.err)"
    rm -rf $d
  done
done
