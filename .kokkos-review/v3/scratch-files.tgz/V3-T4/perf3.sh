#!/bin/bash
# perf3.sh: focused re-measure of perf2 outliers: 5 interleaved reps, t1 and t4, OMP_WAIT_POLICY=passive; perf3/summary.txt
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
EX=$S/final/V3-T1/ex; P=$S/final/V3-T4/perf3; mkdir -p $P
A=$S/build_base/src/spa_kokkos_omp; B=$S/build/src/spa_kokkos_omp
export OMP_WAIT_POLICY=passive OMP_PROC_BIND=false; TIMEFORMAT="%U %S"
for d in surf/in.surf.rotate surf_collide/in.circle.adiabatic surf_collide/in.circle.specular sphere/in.sphere adjust_temp/in.circle.adjust emit/in.emit.surf.subsonic variable_timestep/in.variable_dt surf/in.surf.move; do
  e=${d%%/*}; inp=${d#*/}
  for t in 1 4; do for r in 1 2 3 4 5; do for b in A B; do
    key=$e.$inp.t$t.$b.$r; grep -q "^$key " $P/summary.txt 2>/dev/null && continue
    w=$P/w; rm -rf "${w:?}"; mkdir -p $w; cp -r $EX/$e $w/$e; eval bin=\$$b; ld=$(cut -d' ' -f1 /proc/loadavg)
    us=$( { time (cd $w/$e && timeout 1200 $bin -k on t $t -sf kk -in $inp -echo none -screen none -log $P/log >/dev/null 2>&1 </dev/null) ; } 2>&1 )
    lt=$(awk '/^Loop time of/{s+=$4} END{printf "%.4f", s+0}' $P/log)
    echo "$key loop=$lt usrsys=$(echo $us | awk '{print $1+$2}') load=$ld" >> $P/summary.txt
  done; done; done
done
rm -rf "${P:?}/w"; echo DONE >> $P/summary.txt
