#!/bin/bash
# idempotent: run_cfg.sh skips completed keys
M=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T4; BIN=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T4/bmerged/src/spa_kokkos_omp
NPAR=1 $M/scripts/run_cfg.sh kk1_M "$BIN -k on t 1 -sf kk" &
NPAR=1 $M/scripts/run_cfg.sh cpuopt_M "$BIN" &
wait
