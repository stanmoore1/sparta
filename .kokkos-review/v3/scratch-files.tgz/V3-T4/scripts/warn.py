#!/usr/bin/env python3
# warn.py A_logs... -- B_logs... : warnings new in B, normalised (path, line number), tagged if on changed lines
import sys, re, subprocess, collections
args = sys.argv[1:]; i = args.index('--'); la, lb = args[:i], args[i+1:]
pat = re.compile(r'^(/\S+?):(\d+):\d+: warning: (.*)$')
def norm_path(p):
    m = re.search(r'/src/(.*)$', p)
    return m.group(1) if m else p
def parse(files):
    out = {}
    for f in files:
        lines = open(f, errors='replace').read().splitlines()
        for j, l in enumerate(lines):
            m = pat.match(l)
            if not m: continue
            p, ln, msg = norm_path(m.group(1)), int(m.group(2)), m.group(3)
            code = ''
            if j + 1 < len(lines):
                mm = re.match(r'^\s*\d+\s*\|(.*)$', lines[j+1])
                if mm: code = mm.group(1).strip()
            msgn = re.sub(r"'[^']*'", lambda s: s.group(0), msg)
            out[(p, ln, msg)] = code
    return out
A, B = parse(la), parse(lb)
keyA = collections.Counter((p, msg, code) for (p, ln, msg), code in A.items())
keyB = collections.Counter((p, msg, code) for (p, ln, msg), code in B.items())
# changed lines in B (added lines) per file
diff = subprocess.run(['git', '-C', '/home/user/sparta', 'diff', '-U0', 'e071055f', 'HEAD', '--', 'src'],
                      capture_output=True, text=True).stdout
changed = collections.defaultdict(set); cur = None
for l in diff.splitlines():
    if l.startswith('+++ '):
        cur = l[6:] if l.startswith('+++ b/') else None
        if cur: cur = cur[len('src/'):]
    elif l.startswith('@@') and cur:
        m = re.search(r'\+(\d+)(?:,(\d+))?', l)
        s, n = int(m.group(1)), int(m.group(2) or 1)
        changed[cur].update(range(s, s + n))
print(f"A unique warnings: {len(A)}  B unique warnings: {len(B)}")
new = [];
seen = collections.Counter()
for (p, ln, msg), code in sorted(B.items()):
    k = (p, msg, code); seen[k] += 1
    if seen[k] > keyA.get(k, 0):
        new.append((p, ln, msg, code, ln in changed.get(p, ())))
gone = sum(max(0, keyA[k] - keyB.get(k, 0)) for k in keyA)
print(f"new in B: {len(new)} (on changed lines: {sum(1 for x in new if x[4])}); gone in B: {gone}")
for p, ln, msg, code, ch in new:
    print(f"{'CHANGED' if ch else 'context'} {p}:{ln}: {msg} | {code[:110]}")
