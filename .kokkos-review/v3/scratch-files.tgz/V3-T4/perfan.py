#!/usr/bin/env python3
# perfan.py: median usr+sys and loop per deck/binary from perf2/summary.txt; ratio B/A; flag > 1.05
import re, statistics as st, collections, math
P = '/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T4/perf2/summary.txt'
d = collections.defaultdict(lambda: collections.defaultdict(list)); loads = []
for l in open(P):
    m = re.match(r'(\S+)\.([AB])\.(\d) loop=(\S+) usrsys=(\S+) load=(\S+)', l)
    if not m: continue
    d[m.group(1)][m.group(2)].append((float(m.group(5)), float(m.group(4)))); loads.append(float(m.group(6)))
rows = []; lr = []; ur = []
for k, v in d.items():
    if len(v['A']) < 3 or len(v['B']) < 3: continue
    ua, ub = st.median(x[0] for x in v['A']), st.median(x[0] for x in v['B'])
    la, lb = st.median(x[1] for x in v['A']), st.median(x[1] for x in v['B'])
    spreadA = (max(x[0] for x in v['A']) - min(x[0] for x in v['A'])) / ua if ua else 0
    r = ub / ua if ua > 0.5 else float('nan'); rl = lb / la if la > 0.5 else float('nan')
    rows.append((k, ua, ub, r, la, lb, rl, spreadA))
    if not math.isnan(r): ur.append(math.log(r))
    if not math.isnan(rl): lr.append(math.log(rl))
print(f"decks complete: {len(rows)}  load min/median/max: {min(loads):.1f}/{st.median(loads):.1f}/{max(loads):.1f}")
if ur: print(f"geomean usr+sys B/A = {math.exp(st.mean(ur)):.3f} over {len(ur)} decks (>0.5 s); loop B/A = {math.exp(st.mean(lr)):.3f}")
for k, ua, ub, r, la, lb, rl, sp in sorted(rows, key=lambda x: -x[3] if not math.isnan(x[3]) else 0):
    flag = ' <-- >1.05' if (not math.isnan(r) and r > 1.05) else ''
    print(f"{k:55s} usrsys A={ua:8.2f} B={ub:8.2f} r={r:5.3f} | loop A={la:8.2f} B={lb:8.2f} r={rl:5.3f} | Aspread={sp:.2f}{flag}")
