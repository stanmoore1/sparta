#!/bin/bash
# perf.sh : every kk example, A_opt vs B_opt, t 4, 3 repeats interleaved (A B A B A B), serial; resumable
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
EX=$S/final/V3-T1/ex; P=$S/final/V3-T4/perf; mkdir -p $P/work   # B_opt = build/ of 2026-10-30 03:55 (src = HEAD c99e6089)
A=$S/build_base/src/spa_kokkos_omp; B=$S/build/src/spa_kokkos_omp
export OMP_PROC_BIND=false
for e in $(ls $EX); do [ -e $P/work/$e ] || ln -sfn $EX/$e $P/work/$e; done
for e in $(ls $EX); do
  for inp in $(cd $EX/$e && ls in.* | sort); do
    for r in 1 2 3; do for b in A B; do
      key=$e.$inp.$b.$r
      grep -q "^$key " $P/summary.txt 2>/dev/null && continue
      # wait (unbounded) for a quiet machine (other agents)
      # instantaneous runnable count (field 4 of /proc/loadavg), averaged over 5 samples; 1-min loadavg is polluted by our own t4 runs
      while true; do n=0; for j in 1 2 3 4 5; do n=$((n+$(cut -d' ' -f4 /proc/loadavg | cut -d/ -f1)-1)); sleep 0.4; done
        [ $n -le 5 ] && break; sleep 10; done
      la="$(cut -d' ' -f1 /proc/loadavg)/run$n"
      w=$P/work/$e; rm -rf "${w:?}"; cp -r $EX/$e $w
      eval bin=\$$b
      t0=$(date +%s.%N)
      (cd $w && timeout -k 30 1800 $bin -k on t 4 -sf kk -in $inp -echo none -screen none -log $P/log >/dev/null 2>&1 </dev/null); rc=$?
      t1=$(date +%s.%N)
      lt=$(awk '/^Loop time of/{s+=$4} END{printf "%.4f", s+0}' $P/log)
      echo "$key rc=$rc loop=$lt wall=$(echo "$t1-$t0" | bc) load=$la" >> $P/summary.txt
    done; done
  done
  rm -rf "${P:?}/work/$e"; ln -sfn $EX/$e $P/work/$e
done
echo DONE >> $P/summary.txt
