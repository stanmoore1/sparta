#!/bin/bash
# patchtest.sh: (1) shock_tube at a2361d44,e0f9567d ; (2) 8607dc20 + only src/fix_emit.cpp from 5ba5061f -> emit.face.region
M=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T4
$M/bis.sh e0f9567d shock_tube/in.shocktube; $M/bis.sh a2361d44 shock_tube/in.shocktube
if [ ! -x $M/bins/spa_P_emit ]; then
  git -C $M/bis checkout -q --detach 8607dc20 && git -C $M/bis checkout 5ba5061f -- src/fix_emit.cpp
  ninja -C $M/bbis -j2 > $M/bbis.log 2>&1 && cp $M/bbis/src/spa_ $M/bins/spa_P_emit
  git -C $M/bis checkout -q -f 8607dc20
fi
mkdir -p $M/bisruns/P_emit; w=$M/bisruns/P_emit/w; rm -rf "${w:?}"; mkdir -p $w; cp -r $M/../V3-T1/ex/emit $w/
for k in in.emit.face.region in.emit.surf.flow.region in.emit.surf.normal.region; do
 (cd $w/emit && $M/bins/spa_P_emit -in $k -echo none -screen none -log $M/bisruns/P_emit/emit.$k.log >/dev/null 2>&1)
done
rm -rf "${w:?}"; echo PATCHDONE
