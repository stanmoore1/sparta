#!/bin/bash
# perf2.sh: every kk example, A_opt vs B_opt (build/ 10-30 03:55, src HEAD c99e6089), t 4, OMP_WAIT_POLICY=passive,
# 3 interleaved repeats; metric usr+sys CPU (bash time) + Loop time sum; load recorded. Resumable (perf2/summary.txt).
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
EX=$S/final/V3-T1/ex; P=$S/final/V3-T4/perf2; mkdir -p $P/work
A=$S/build_base/src/spa_kokkos_omp; B=$S/build/src/spa_kokkos_omp
export OMP_WAIT_POLICY=passive OMP_PROC_BIND=false
TIMEFORMAT="%U %S"
for e in $(ls $EX); do [ -e $P/work/$e ] || ln -sfn $EX/$e $P/work/$e; done
for e in $(ls $EX); do
  for inp in $(cd $EX/$e && ls in.* | sort); do
    for r in 1 2 3; do for b in A B; do
      key=$e.$inp.$b.$r
      grep -q "^$key " $P/summary.txt 2>/dev/null && continue
      w=$P/work/$e; rm -rf "${w:?}"; cp -r $EX/$e $w
      eval bin=\$$b
      ld=$(cut -d' ' -f1 /proc/loadavg)
      us=$( { time (cd $w && timeout -k 30 1200 $bin -k on t 4 -sf kk -in $inp -echo none -screen none -log $P/log >/dev/null 2>&1 </dev/null) ; } 2>&1 )
      lt=$(awk '/^Loop time of/{s+=$4} END{printf "%.4f", s+0}' $P/log)
      echo "$key loop=$lt usrsys=$(echo $us | awk '{print $1+$2}') load=$ld" >> $P/summary.txt
    done; done
  done
  rm -rf "${P:?}/work/$e"; ln -sfn $EX/$e $P/work/$e
done
echo DONE >> $P/summary.txt
