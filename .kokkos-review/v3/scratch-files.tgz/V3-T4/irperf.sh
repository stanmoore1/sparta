#!/bin/bash
# irperf.sh: load-independent instruction counts (valgrind --tool=lackey is slow; use callgrind totals) A_opt vs B_opt,
# kk t1, OMP passive. usage: irperf.sh ex/in.deck ...  -> irperf/summary.txt "deck A_Ir B_Ir ratio"
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad; P=$S/final/V3-T4/irperf; mkdir -p $P
A=$S/build_base/src/spa_kokkos_omp; B=$S/build/src/spa_kokkos_omp; export OMP_WAIT_POLICY=passive
for d in "$@"; do e=${d%%/*}; i=${d#*/}
  grep -q "^$e.$i " $P/summary.txt 2>/dev/null && continue
  for b in A B; do eval bin=\$$b; w=$P/w; rm -rf "${w:?}"; mkdir -p $w; cp -r $S/final/V3-T1/ex/$e $w/$e
    (cd $w/$e && timeout 3600 valgrind --tool=callgrind --callgrind-out-file=$P/cg.$b.out $bin -k on t 1 -sf kk -in $i -echo none -screen none -log none > /dev/null 2> $P/vg.$b.err)
    eval ir$b=$(grep -m1 "^summary:" $P/cg.$b.out | awk '{print $2}')
    cp $P/cg.$b.out $P/cg.$e.$i.$b.out
  done
  echo "$e.$i A=$irA B=$irB ratio=$(echo "scale=4; $irB/$irA" | bc)" >> $P/summary.txt
done
rm -rf "${P:?}/w"
