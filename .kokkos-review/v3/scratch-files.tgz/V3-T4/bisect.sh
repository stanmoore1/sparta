#!/bin/bash
# bisect.sh <ex/in.deck>... : first-parent bisect of c91b1c5e..origin/ccr-014f4f5c-hhi3vb for the first commit whose
# CPU stats differ from c91b1c5e. Result lines appended to bisect.txt. Idempotent (builds/runs cached by bis.sh).
M=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T4
mapfile -t L < <(git -C /home/user/sparta rev-list --first-parent --reverse c91b1c5e..origin/ccr-014f4f5c-hhi3vb | cut -c1-8)
st() { awk '/^ *Step /{h=1;print;next} /^Loop time/{h=0} h&&/^ *[0-9]/{out=""; for(i=1;i<=NF;i++) if(i!=2) out=out" "$i; print out}' $1; }
for d in "$@"; do
  e=${d%%/*}; inp=${d#*/}; key=$e.$inp
  grep -q "^$key " $M/bisect.txt 2>/dev/null && continue
  $M/bis.sh c91b1c5e $d >/dev/null
  lo=-1; hi=$((${#L[@]}-1))
  $M/bis.sh ${L[$hi]} $d > /dev/null
  if cmp -s <(st $M/bisruns/c91b1c5e/$key.log) <(st $M/bisruns/${L[$hi]}/$key.log); then echo "$key NODIFF-at-tip" >> $M/bisect.txt; continue; fi
  while [ $((hi-lo)) -gt 1 ]; do
    mid=$(((lo+hi)/2)); c=${L[$mid]}
    $M/bis.sh $c $d > /dev/null || { echo "$key BUILDFAIL $c" >> $M/bisect.txt; break; }
    if cmp -s <(st $M/bisruns/c91b1c5e/$key.log) <(st $M/bisruns/$c/$key.log); then lo=$mid; else hi=$mid; fi
  done
  echo "$key first-diff ${L[$hi]} $(git -C /home/user/sparta log -1 --format=%s ${L[$hi]})" >> $M/bisect.txt
done
