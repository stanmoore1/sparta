/* ----------------------------------------------------------------------
   SPARTA - Stochastic PArallel Rarefied-gas Time-accurate Analyzer
   http://sparta.github.io
   Steve Plimpton, sjplimp@gmail.com, Michael Gallis, magalli@sandia.gov
   Sandia National Laboratories

   Copyright (2014) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level SPARTA directory.
------------------------------------------------------------------------- */

#include "spatype.h"
#include "stdlib.h"
#include "string.h"
#include "fix_ablate.h"
#include "update.h"
#include "geometry.h"
#include "grid.h"
#include "domain.h"
#include "decrement_lookup_table.h"
#include "comm.h"
#include "modify.h"
#include "compute.h"
#include "fix.h"
#include "output.h"
#include "input.h"
#include "variable.h"
#include "dump.h"
#include "marching_squares.h"
#include "marching_cubes.h"
#include "random_mars.h"
#include "random_knuth.h"
#include "memory.h"
#include "error.h"

using namespace SPARTA_NS;

enum{COMPUTE,FIX,VARIABLE,RANDOM,UNIFORM};
enum{CVALUE,CDELTA,NVERT};

#define INVOKED_PER_GRID 16
#define DELTAGRID 1024            // must be bigger than split cells per cell
#define DELTASEND 1024
#define EPSILON 1.0e-4            // this is on a scale of 0 to 255
#define EPSILON_DELTA 1.0e-10     // unpaid decrement small enough to call zero
#define MAXDECITER 10             // max decrement/sync passes per ablation

enum{XLO,XHI,YLO,YHI,ZLO,ZHI,INTERIOR};         // same as Domain
enum{NCHILD,NPARENT,NUNKNOWN,NPBCHILD,NPBPARENT,NPBUNKNOWN,NBOUND};  // Update

// remove if fix particles-inside-surfs issue
enum{PKEEP,PINSERT,PDONE,PDISCARD,PENTRY,PEXIT,PSURF};  // several files

// NOTES
// should I store one value or 8 per cell
// how to preserve svalues and set type of new surfs,
//   maybe need local per-cell type
// after create new surfs, need to assign group, sc, sr
// how to impose sgroup like ReadIsurf does after surfs created
// how to prevent adaptation of any cells in the implicit grid group(s)?
//   just testing for surfs is not enough, since it may have no surfs
// need to update neigh corner points even if neigh cell is not in group?
// do a run-time test for gridcut = 0.0 ?
// worry about array_grid having updated values for sub cells?  line in store()
// can I output both per-grid and global values?

/* ---------------------------------------------------------------------- */

FixAblate::FixAblate(SPARTA *sparta, int narg, char **arg) :
  Fix(sparta, narg, arg)
{
  MPI_Comm_rank(world,&me);

  if (narg < 6) error->all(FLERR,"Illegal fix ablate command");

  igroup = grid->find_group(arg[2]);
  if (igroup < 0) error->all(FLERR,"Could not find fix ablate group ID");
  groupbit = grid->bitmask[igroup];

  nevery = atoi(arg[3]);
  if (nevery < 0) error->all(FLERR,"Illegal fix ablate command");

  idsource = NULL;

  scale = atof(arg[4]);
  if (scale < 0.0) error->all(FLERR,"Illegal fix ablate command");

  int iarg = 6;

  if ((strncmp(arg[5],"c_",2) == 0) || (strncmp(arg[5],"f_",2) == 0)) {
    if (arg[5][0] == 'c') which = COMPUTE;
    else if (arg[5][0] == 'f') which = FIX;

    int n = strlen(arg[5]);
    char *suffix = new char[n];
    strcpy(suffix,&arg[5][2]);

    char *ptr = strchr(suffix,'[');
    if (ptr) {
      if (suffix[strlen(suffix)-1] != ']') {
        delete [] suffix;
        error->all(FLERR,"Illegal fix ablate command");
      }
      argindex = atoi(ptr+1);
      *ptr = '\0';
    } else argindex = 0;

    n = strlen(suffix) + 1;
    idsource = new char[n];
    strcpy(idsource,suffix);
    delete [] suffix;

  } else if (strncmp(arg[5],"v_",2) == 0) {
    which = VARIABLE;

    int n = strlen(arg[5]);
    idsource = new char[n];
    strcpy(idsource,&arg[5][2]);

  } else if (strcmp(arg[5],"random") == 0) {
    iarg++;

    if (narg < 7) error->all(FLERR,"Illegal fix ablate command");
    which = RANDOM;
    maxrandom = atoi(arg[6]);

  } else if (strcmp(arg[5],"uniform") == 0) {
    iarg++; // one additional input
    if (narg < 7) error->all(FLERR,"Illegal fix ablate command");
    which = UNIFORM;
    maxrandom = atoi(arg[6]);

  } else error->all(FLERR,"Illegal fix ablate command");

  // process optional command line args

  process_args(narg-iarg,&arg[iarg]);

  // error check

  if (which == COMPUTE) {
    icompute = modify->find_compute(idsource);
    if (icompute < 0)
      error->all(FLERR,"Compute ID for fix ablate does not exist");
    if (modify->compute[icompute]->per_grid_flag == 0)
      error->all(FLERR,
                 "Fix ablate compute does not calculate per-grid values");
    if (modify->compute[icompute]->post_process_isurf_grid_flag == 0)
      error->all(FLERR,
                 "Fix ablate compute does not calculate isurf per-grid values");
    if (argindex == 0 &&
        modify->compute[icompute]->size_per_grid_cols != 0)
      error->all(FLERR,"Fix ablate compute does not "
                 "calculate per-grid vector");
    if (argindex && modify->compute[icompute]->size_per_grid_cols == 0)
      error->all(FLERR,"Fix ablate compute does not "
                 "calculate per-grid array");
    if (argindex && argindex > modify->compute[icompute]->size_per_grid_cols)
      error->all(FLERR,"Fix ablate compute array is accessed out-of-range");

  } else if (which == FIX) {
    ifix = modify->find_fix(idsource);
    if (ifix < 0)
      error->all(FLERR,"Fix ID for fix ablate does not exist");
    if (modify->fix[ifix]->per_grid_flag == 0)
      error->all(FLERR,"Fix ablate fix does not calculate per-grid values");
    if (argindex == 0 && modify->fix[ifix]->size_per_grid_cols != 0)
      error->all(FLERR,
                 "Fix ablate fix does not calculate per-grid vector");
    if (argindex && modify->fix[ifix]->size_per_grid_cols == 0)
      error->all(FLERR,
                 "Fix ablate fix does not calculate per-grid array");
    if (argindex && argindex > modify->fix[ifix]->size_per_grid_cols)
      error->all(FLERR,"Fix ablate fix array is accessed out-of-range");
    if (nevery % modify->fix[ifix]->per_grid_freq)
      error->all(FLERR,
                 "Fix for fix ablate not computed at compatible time");

  } else if (which == VARIABLE) {
    ivariable = input->variable->find(idsource);
    if (ivariable < 0)
      error->all(FLERR,"Could not find fix ablate variable name");
    if (input->variable->grid_style(ivariable) == 0)
      error->all(FLERR,"Fix ablate variable is not grid-style variable");
  }

  // this fix produces a per-grid array and a scalar

  dim = domain->dimension;

  per_grid_flag = 1;
  if (dim == 2) size_per_grid_cols = 4;
  else size_per_grid_cols = 8;
  per_grid_freq = 1;
  gridmigrate = 1;

  scalar_flag = 1;
  vector_flag = 1;
  size_vector = 3;
  global_freq = 1;
  sum_delta = 0.0;
  sum_unpaid = 0.0;
  unpaid_mine = 0.0;
  clamp_mine = 0.0;
  firstwarn_unpaid = 1;
  firstwarn_clamp = 1;
  ndelete = 0;

  storeflag = multi_val_flag = 0;
  isc_default = isr_default = 0;
  array_grid = cvalues = NULL;
  mvalues = NULL;
  tvalues = NULL;
  ncorner = size_per_grid_cols;

  if(dim == 2) nmultiv = 4;
  else nmultiv = 6;

  // local storage

  ixyz = NULL;
  mcflags = NULL;
  celldelta = NULL;
  credit = NULL;
  cdelta = NULL;
  cdelta_ghost = NULL;
  mdelta = NULL;
  mdelta_ghost = NULL;
  nvert = NULL;
  nvert_ghost = NULL;

  numsend = NULL;
  maxgrid = maxghost = 0;

  proclist = NULL;
  locallist = NULL;
  maxsend = 0;

  sbuf = NULL;
  maxbuf = 0;

  vbuf = NULL;
  maxvar = 0;

  ms = NULL;
  mc = NULL;

  // RNG for random decrements
  // for now, use same RNG on every proc
  // uncomment two lines if want to change that
  // b/c set_delta_random() is decrementing the same no matter who owns a cell

  random = NULL;
  if (which == RANDOM) {
    random = new RanKnuth(update->ranmaster->uniform());
    //double seed = update->ranmaster->uniform();
    //random->reset(seed,comm->me,100);
  }

  // nvalid = next step on which end_of_step does something
  // add nvalid to all computes that store invocation times
  // since don't know a priori which are invoked by this fix
  // once in end_of_step() can set timestep for ones actually invoked

  if (nevery) {
    bigint nvalid = (update->ntimestep/nevery)*nevery + nevery;
    modify->addstep_compute_all(nvalid);
  }
}

/* ---------------------------------------------------------------------- */

FixAblate::~FixAblate()
{
  delete [] idsource;
  memory->destroy(cvalues);
  memory->destroy(mvalues);
  memory->destroy(tvalues);

  memory->destroy(ixyz);
  memory->destroy(mcflags);

  memory->destroy(celldelta);
  memory->destroy(credit);
  memory->destroy(cdelta);
  memory->destroy(cdelta_ghost);
  memory->destroy(mdelta);
  memory->destroy(mdelta_ghost);

  memory->destroy(nvert);
  memory->destroy(nvert_ghost);

  memory->destroy(numsend);

  memory->destroy(proclist);
  memory->destroy(locallist);

  memory->destroy(sbuf);
  memory->destroy(vbuf);

  delete ms;
  delete mc;

  delete random;
}

/* ---------------------------------------------------------------------- */

int FixAblate::setmask()
{
  int mask = 0;
  if (nevery) mask |= END_OF_STEP;
  return mask;
}

/* ----------------------------------------------------------------------
   store grid corner point and type values in cvalues and tvalues
   then create implicit surfaces
   called by ReadIsurf when corner point grid is read in
------------------------------------------------------------------------- */

void FixAblate::store_corners(int nx_caller, int ny_caller, int nz_caller,
                              double *cornerlo_caller, double *xyzsize_caller,
                              double **cvalues_caller, double ***mvalues_caller,
                              int *tvalues_caller,
                              double thresh_caller, char *sgroupID, int pushflag)
{
  storeflag = 1;
  if(mvalues_caller) {
    multi_val_flag = 1;
    cvalues = NULL; // likely not needed
  } else {
    multi_val_flag = 0;
    mvalues = NULL; // likely not needed
  }

  // a multivalue fix stores corner state in mvalues and leaves array_grid
  //   (= cvalues) NULL, so it cannot expose the per-grid corner array that
  //   per_grid_flag advertises.  Turn the flag off so generic per-grid
  //   consumers (compute reduce, dump grid, fix ave/grid, ...) reject it
  //   cleanly at setup instead of dereferencing NULL array_grid at run time.
  //   The scalar output (f_ID) is unaffected.

  if (multi_val_flag) per_grid_flag = 0;
  else per_grid_flag = 1;

  nx = nx_caller;
  ny = ny_caller;
  nz = nz_caller;
  cornerlo[0] = cornerlo_caller[0];
  cornerlo[1] = cornerlo_caller[1];
  cornerlo[2] = cornerlo_caller[2];
  xyzsize[0] = xyzsize_caller[0];
  xyzsize[1] = xyzsize_caller[1];
  xyzsize[2] = xyzsize_caller[2];
  thresh = thresh_caller;

  tvalues_flag = 0;
  if (tvalues_caller) tvalues_flag = 1;

  if (sgroupID) {
    int sgroup = surf->find_group(sgroupID);
    if (sgroup < 0) sgroup = surf->add_group(sgroupID);
    sgroupbit = surf->bitmask[sgroup];
  } else sgroupbit = 0;

  // allocate per-grid cell data storage

  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;
  nglocal = grid->nlocal;

  grow_percell(0);

  // copy caller values into local values of FixAblate

  for (int icell = 0; icell < nglocal; icell++) {
    for (int m = 0; m < ncorner; m++) {
      if(!multi_val_flag) cvalues[icell][m] = cvalues_caller[icell][m];
      else {
        for (int n = 0; n < nmultiv; n++)
          mvalues[icell][m][n] = mvalues_caller[icell][m][n];
      }
    }
    if (tvalues_flag) tvalues[icell] = tvalues_caller[icell];
  }

  // set all values to either min or max value

  if (minmaxflag) {
    for (int icell = 0; icell < nglocal; icell++) {
      for (int m = 0; m < ncorner; m++) {
        if (!multi_val_flag) {
          if (cvalues[icell][m] < thresh) cvalues[icell][m] = 0.0;
          else cvalues[icell][m] = 255.0;
        } else {
          for (int n = 0; n < nmultiv; n++) {
            if (mvalues[icell][m][n] < thresh) mvalues[icell][m][n] = 0.0;
            else mvalues[icell][m][n] = 255.0;
          }
        }
      }
    }
  }

  // set ix,iy,iz indices from 1 to Nxyz for each of my owned grid cells
  // same logic as ReadIsurf::create_hash()

  for (int i = 0; i < nglocal; i++)
    ixyz[i][0] = ixyz[i][1] = ixyz[i][2] = 0;

  for (int icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    ixyz[icell][0] =
      static_cast<int> ((cells[icell].lo[0]-cornerlo[0]) / xyzsize[0] + 0.5) + 1;
    ixyz[icell][1] =
      static_cast<int> ((cells[icell].lo[1]-cornerlo[1]) / xyzsize[1] + 0.5) + 1;
    ixyz[icell][2] =
      static_cast<int> ((cells[icell].lo[2]-cornerlo[2]) / xyzsize[2] + 0.5) + 1;
  }

  // push corner pt values with fully external/internal neighbors to 0 or 255
  // adjust individual corner point values too close to threshold

  if (pushflag && !multi_val_flag) push_lohi();

  // check for consistency
  // initflag = 1: this is the initial creation of the corner point values,
  //   where exactly-on-threshold values must be removed unconditionally

  if (multi_val_flag) epsilon_adjust_multiv(1);
  else epsilon_adjust(1);

  // create marching squares/cubes classes, now that have group & threshold

  if (dim == 2) ms = new MarchingSquares(sparta,igroup,thresh);
  else mc = new MarchingCubes(sparta,igroup,thresh);

  // set minimum distance between vertex and grid point (mindist) in marching
  if (dim == 2) ms->mindist = mindist;
  else mc->mindist = mindist;

  // create implicit surfaces

  create_surfs(1);
}

/* ---------------------------------------------------------------------- */

void FixAblate::init()
{
  if (!storeflag)
    error->all(FLERR,"Fix ablate corner point values not stored");

  if (which == COMPUTE) {
    icompute = modify->find_compute(idsource);
    if (icompute < 0)
      error->all(FLERR,"Compute ID for fix ablate does not exist");
  } else if (which == FIX) {
    ifix = modify->find_fix(idsource);
    if (ifix < 0)
      error->all(FLERR,"Fix ID for fix ablate does not exist");
  } else if (which == VARIABLE) {
    ivariable = input->variable->find(idsource);
    if (ivariable < 0)
      error->all(FLERR,"Variable ID for fix ablate does not exist");
  }

  // reallocate per-grid data if necessary

  nglocal = grid->nlocal;
  grow_percell(0);

  // determine default collision/reaction model indices from existing surfaces
  // these values were set by surf_modify and are used during each ablation step
  //   to correctly re-assign models to newly created implicit surfaces
  // implicit surfs are distributed, so allreduce the values to procs
  //   which own no surfs now, since ablation may create surfs in their cells
  // error if surfs are not all assigned to the same models, e.g. by
  //   surf_modify with multiple surf groups, since create_surfs() can only
  //   re-assign one collision/reaction model to all new surfs

  int isc_local = -1;
  int isr_local = -1;
  int flag = 0;

  int nslocal = surf->nlocal;

  if (nslocal > 0) {
    if (dim == 2) {
      Surf::Line *lines = surf->lines;
      isc_local = lines[0].isc;
      isr_local = lines[0].isr;
      for (int i = 1; i < nslocal; i++)
        if (lines[i].isc != isc_local || lines[i].isr != isr_local) flag = 1;
    } else {
      Surf::Tri *tris = surf->tris;
      isc_local = tris[0].isc;
      isr_local = tris[0].isr;
      for (int i = 1; i < nslocal; i++)
        if (tris[i].isc != isc_local || tris[i].isr != isr_local) flag = 1;
    }
  }

  int local_vals[2],global_vals[2];
  local_vals[0] = isc_local;
  local_vals[1] = isr_local;
  MPI_Allreduce(local_vals,global_vals,2,MPI_INT,MPI_MAX,world);
  isc_default = global_vals[0];
  isr_default = global_vals[1];

  if (nslocal > 0 && (isc_local != isc_default || isr_local != isr_default))
    flag = 1;

  int allflag;
  MPI_Allreduce(&flag,&allflag,1,MPI_INT,MPI_MAX,world);
  if (allflag)
    error->all(FLERR,"Fix ablate requires all surfs be assigned "
               "to the same surface collision and reaction models");

  if (isc_default < 0) isc_default = 0;
}

/* ---------------------------------------------------------------------- */

void FixAblate::end_of_step()
{
  // set per-cell delta vector randomly or from compute/fix source

  if (which == RANDOM) set_delta_random();
  else if (which == UNIFORM) set_delta_uniform();
  else set_delta();

  // various decrement and sync routines depending on:
  // 1) are multivalues used?
  // 2) is the decrement distributed to multiple corner points?

  unpaid_mine = 0.0;
  clamp_mine = 0.0;

  if (multi_dec_flag) {
    if (multi_val_flag) {
      decrement_multiv_multid_outside();
      sync_multiv_multid_outside();
      decrement_multiv_multid_inside();
      sync_multiv_multid_inside();
    } else {
      decrement_multid_outside();
      sync_multid_outside();
      decrement_multid_inside();
      sync_multid_inside();
    }
  } else {
    if (multi_val_flag) {
      decrement_multiv();
      sync_multiv();
    } else {

      // pay each cell's decrement from its own corner point values, retrying
      //   the part of a claim that a shared corner point could not cover
      //   because neighbor cells claimed the same corner point in this epoch
      // sync() credits each cell with what its claim actually removed and
      //   leaves the rest in celldelta, so the next pass offers it to the
      //   other corner points of the same cell, which is what this fix
      //   documents itself as doing
      // the first pass is exactly the single decrement/sync pair that came
      //   before, and an epoch that pays in full stops after it, so a run
      //   which never over-claims a corner point is unchanged and pays no
      //   extra communication
      // an epoch that cannot pay in full costs one more pass than that: a
      //   pass has to run to find that it removes nothing.  the conserve
      //   keyword turns the retry off for a run that would rather drop the
      //   remainder than pay for the extra comm_neigh_corners()
      // what is left after the last pass is decrement the cell has no
      //   material left to cover, which end_of_step reports below

      Grid::ChildCell *cells = grid->cells;
      Grid::ChildInfo *cinfo = grid->cinfo;
      double owed_mine,owed_all,owed_previous;

      owed_previous = 0.0;

      for (int iter = 0; iter < MAXDECITER; iter++) {
        decrement();
        sync();

        if (!conserve_flag) break;

        owed_mine = 0.0;
        for (int icell = 0; icell < nglocal; icell++) {
          if (!(cinfo[icell].mask & groupbit)) continue;
          if (cells[icell].nsplit <= 0) continue;
          owed_mine += celldelta[icell];
        }

        MPI_Allreduce(&owed_mine,&owed_all,1,MPI_DOUBLE,MPI_SUM,world);

        // stop when the epoch is paid in full, or when a pass paid nothing
        //   more, which means no corner point of any cell that still owes
        //   has material left and every later pass is a no-op that costs
        //   another comm_neigh_corners() + Allreduce

        if (owed_all == 0.0) break;
        if (iter && owed_all >= owed_previous) break;
        owed_previous = owed_all;
      }

      // remaining celldelta is decrement no corner point of the cell can pay

      for (int icell = 0; icell < nglocal; icell++) {
        if (!(cinfo[icell].mask & groupbit)) continue;
        if (cells[icell].nsplit <= 0) continue;
        unpaid_mine += celldelta[icell];
      }
    }
  }

  // report the part of this epoch's decrement that was requested but never
  //   removed from any corner point, so it is not silently lost
  // decrement() and decrement_multiv() stop when the corner values of a cell
  //   sum to less than its requested decrement: the cell gives up all it has
  //   and the rest of the request is dropped, tallied here as sum_unpaid
  // the two distributed-decrement styles instead pass the deficit to the
  //   inside corner points, which are then clamped at zero by their sync,
  //   an amount that cannot be tallied without double counting corner points
  //   shared by several cells, so only report that it happened
  // both are expected for the random and uniform sources, which keep asking
  //   after a cell is empty, but for a compute/fix source they mean gas
  //   products were created for solid material that was never removed
  // a corner point claimed by several cells in one epoch is a third path,
  //   clamped at zero by sync(), and is not reported

  double unpaid_mine_all[2],unpaid_all[2];
  unpaid_mine_all[0] = unpaid_mine;
  unpaid_mine_all[1] = clamp_mine;
  MPI_Allreduce(unpaid_mine_all,unpaid_all,2,MPI_DOUBLE,MPI_SUM,world);

  if (unpaid_all[0] > 0.0) {
    sum_unpaid += unpaid_all[0];
    if (firstwarn_unpaid) {
      firstwarn_unpaid = 0;
      if (comm->me == 0)
        error->warning(FLERR,"Fix ablate decrement exceeded the corner point "
                       "values available to pay it, remainder dropped: "
                       "cumulative amount is in the fix vector [3]");
    }
  }

  if (unpaid_all[1] > 0.0 && firstwarn_clamp) {
    firstwarn_clamp = 0;
    if (comm->me == 0)
      error->warning(FLERR,"Fix ablate distributed decrement drove an inside "
                     "corner point negative, remainder dropped");
  }

  // sync shared corner point values
  // adjust individual corner point values too close to threshold
  // initflag = 0: mid-ablation, keep the historical mindist-gated behavior
  //   so an ongoing ablation run is unchanged

  if (multi_val_flag) epsilon_adjust_multiv(0);
  else epsilon_adjust(0);

  // re-create implicit surfs

  create_surfs(0);
}

/* ---------------------------------------------------------------------- */

void FixAblate::create_surfs(int outflag)
{
  // DEBUG
  // store copy of last ablation's per-cell MC flags before a new ablation

  // mcflags is already grown to maxgrid by grow_percell(), so reset it in
  //   place.  It used to be reallocated here and the previous one kept as
  //   mcflags_old, an allocate and a free of 4 ints per grid cell on every
  //   rebuild, where mcflags_old was only ever read by a debug print that
  //   is commented out below

  for (int i = 0; i < maxgrid; i++)
    mcflags[i][0] = mcflags[i][1] = mcflags[i][2] = mcflags[i][3] = -1;

  // sort existing particles since may be clearing split cells

  if (!particle->sorted) particle->sort();

  // reassign particles in sub cells to all be in parent split cell

  if (grid->nsplitlocal) {
    Grid::ChildCell *cells = grid->cells;
    for (int icell = 0; icell < nglocal; icell++)
      if (cells[icell].nsplit > 1)
        grid->combine_split_cell_particles(icell,1);
  }

  // call clear_surf before create new surfs, so cell/corner flags are all set

  grid->unset_neighbors();
  grid->remove_ghosts();
  grid->clear_surf();
  surf->clear_implicit();

  // perform Marching Squares/Cubes to create new implicit surfs
  // cvalues = corner point values
  // tvalues = surf type for surfs in each grid cell

  if (dim == 2) ms->invoke(cvalues,mvalues,tvalues);
  else mc->invoke(cvalues,mvalues,tvalues,mcflags);

  // set surf->nsurf and surf->nown

  surf->nown = surf->nlocal;
  bigint nlocal = surf->nlocal;
  MPI_Allreduce(&nlocal,&surf->nsurf,1,MPI_SPARTA_BIGINT,MPI_SUM,world);

  // output extent of implicit surfs, some may be tiny

  if (outflag) {
    if (dim == 2) surf->output_extent(0);
    else surf->output_extent(0);
  }

  // compute normals of new surfs

  if (dim == 2) surf->compute_line_normal(0);
  else surf->compute_tri_normal(0);

  // MC->cleanup() checks for consistent triangles on grid cell faces
  // needs to come after normals are computed
  // it requires neighbor indices and ghost cell info
  // so first acquire ghosts (which will also grab surfs),
  //   then remove ghost surfs and ghost grid cells again

  if (dim == 3) {
    grid->acquire_ghosts(0);
    grid->reset_neighbors();
    mc->cleanup();
    surf->remove_ghosts();
    grid->unset_neighbors();
    grid->remove_ghosts();
  }

  // assign optional surf group to masks of new surfs

  if (sgroupbit) {
    int nsurf = surf->nlocal;
    if (dim == 3) {
      Surf::Tri *tris = surf->tris;
      for (int i = 0; i < nsurf; i++) tris[i].mask |= sgroupbit;
    } else {
      Surf::Line *lines = surf->lines;
      for (int i = 0; i < nsurf; i++) lines[i].mask |= sgroupbit;
    }
  }

  // assign surf collision/reaction models to newly created surfs
  // this assignment can be made in input script via surf_modify
  //   after implicit surfs are created
  // for active ablation, must be re-assigned at every ablation step
  // use isc_default/isr_default which were set during init() by reading
  //   the values surf_modify assigned to existing surfaces

  int nslocal = surf->nlocal;

  if (dim == 2) {
    Surf::Line *lines = surf->lines;
    if (surf->nsc)
      for (int i = 0; i < nslocal; i++)
        lines[i].isc = isc_default;
    if (surf->nsr && isr_default >= 0)
      for (int i = 0; i < nslocal; i++)
        lines[i].isr = isr_default;
  } else {
    Surf::Tri *tris = surf->tris;
    if (surf->nsc)
      for (int i = 0; i < nslocal; i++)
        tris[i].isc = isc_default;
    if (surf->nsr && isr_default >= 0)
      for (int i = 0; i < nslocal; i++)
        tris[i].isr = isr_default;
  }

  // watertight check can be done before surfs are mapped to grid cells

  if (dim == 2) surf->check_watertight_2d();
  else surf->check_watertight_3d();

  // if no surfs created, use clear_surf to set all celltypes = OUTSIDE

  if (surf->nsurf == 0) {
    surf->exist = 0;
    grid->clear_surf();
  }

  // -----------------------
  // map surfs to grid cells
  // -----------------------

  // surfs are already assigned to grid cells
  // create split cells due to new surfs

  grid->surf2grid_implicit(1,outflag);

  // re-setup grid ghosts and neighbors

  grid->setup_owned();
  grid->acquire_ghosts();
  grid->reset_neighbors();
  comm->reset_neighbors();

  // flag cells and corners as OUTSIDE or INSIDE

  grid->set_inout();
  grid->type_check(outflag);

  // reassign particles in a split cell to sub cell owner
  // particles are unsorted afterwards, within new sub cells

  if (grid->nsplitlocal) {
    Grid::ChildCell *cells = grid->cells;
    for (int icell = 0; icell < nglocal; icell++)
      if (cells[icell].nsplit > 1)
        grid->assign_split_cell_particles(icell);
    particle->sorted = 0;
  }

  // notify all classes that store per-grid data that grid has changed

  grid->notify_changed();

  // ------------------------------------------------------------------------
  // DEBUG - should not have to do any of this once marching cubes is perfect
  // only necessary for 3d

  if (dim == 2) return;

  // DEBUG - if this line is uncommented, code will do delete no particles
  //         eventually this should work

  // if (dim == 3) return;

  // DEBUG - remove all particles
  // if these lines are uncommented, all particles are wiped out

  // particle->nlocal = 0;
  // return;

  // DEBUG - remove only the particles that are inside the surfs
  //         after ablation
  // similar code as in fix grid/check

  Grid::ChildCell *cells = grid->cells;
  Grid::SplitInfo *sinfo = grid->sinfo;
  Particle::OnePart *particles = particle->particles;
  int pnlocal = particle->nlocal;

  int ncount;
  int icell,splitcell,subcell,pflag;
  double *x;
  double xcell[3];

  ncount = 0;
  for (int i = 0; i < pnlocal; i++) {
    particles[i].flag = PKEEP;
    icell = particles[i].icell;
    if (cells[icell].nsurf == 0) continue;

    x = particles[i].x;

    // check that particle is outside surfs
    // if no xcell found, cannot check

    pflag = grid->point_outside_surfs(icell,xcell);
    if (!pflag) continue;
    pflag = grid->outside_surfs(icell,x,xcell);

    // check that particle is in correct split subcell

    if (pflag && cells[icell].nsplit <= 0) {
      splitcell = sinfo[cells[icell].isplit].icell;
      if (dim == 2) subcell = update->split2d(splitcell,x);
      else subcell = update->split3d(splitcell,x);
      if (subcell != icell) pflag = 0;
    }

    // discard the particle if either test failed

    if (!pflag) {
      particles[i].flag = PDISCARD;
      // DEBUG - print message about MC flags for cell of deleted particle
      /*
      printf("INSIDE PART: me %d id %d coords %g %g %g "
             "cellID %d celltype %d nsplit %d "
             "MCflags now %d %d %d %d corners %g %g %g %g %g %g %g %g\n",
             comm->me,particles[i].id,x[0],x[1],x[2],
             cells[mcell].id,cinfo[mcell].type,cells[mcell].nsplit,
             mcflags[mcell][0],
             mcflags[mcell][1],
             mcflags[mcell][2],
             mcflags[mcell][3],
             cvalues[mcell][0],
             cvalues[mcell][1],
             cvalues[mcell][2],
             cvalues[mcell][3],
             cvalues[mcell][4],
             cvalues[mcell][5],
             cvalues[mcell][6],
             cvalues[mcell][7]);
      */
      ncount++;
    }
  }

  // compress out the deleted particles
  // NOTE: if end up keeping this section, need logic for custom particle vectors
  //       see Particle::compress_rebalance()

  int nbytes = sizeof(Particle::OnePart);

  int i = 0;
  while (i < pnlocal) {
    if (particles[i].flag == PDISCARD) {
      memcpy(&particles[i],&particles[pnlocal-1],nbytes);
      pnlocal--;
    } else i++;
  }

  // sum in bigint, global deletion count can exceed 2^31
  //   at large proc counts

  bigint ncount_big = ncount;
  MPI_Allreduce(&ncount_big,&ndelete,1,MPI_SPARTA_BIGINT,MPI_SUM,world);

  particle->nlocal = pnlocal;
  particle->sorted = 0;
}

/* ----------------------------------------------------------------------
   set per-cell delta vector randomly
   celldelta = random integer between 0 and maxrandom
   scale = fraction of cells that are decremented
------------------------------------------------------------------------- */

void FixAblate::set_delta_random()
{
  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  // enforce same decrement no matter who owns which cells
  // NOTE: could change this at some point, use differnet RNG for each proc

  if (!grid->hashfilled) grid->rehash();
  Grid::MyHash *hash = grid->hash;
  cellint cellID;
  int rn2,icell;
  double rn1;
  for (bigint i = 0; i < grid->ncell; i++) {
    rn1 = random->uniform();
    rn2 = static_cast<int> (random->uniform()*maxrandom) + 1.0;
    cellID = i+1;
    if (hash->find(cellID) == hash->end()) continue;
    icell = (*hash)[cellID];
    if (icell >= nglocal) continue;     // ghost cell

    if (rn1 > scale) celldelta[icell] = 0.0;
    else celldelta[icell] = rn2;
  }

  // total decrement for output

  double sum = 0.0;
  for (int icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;
    sum += celldelta[icell];
  }

  MPI_Allreduce(&sum,&sum_delta,1,MPI_DOUBLE,MPI_SUM,world);
}

/* ----------------------------------------------------------------------
   set per-cell delta vector uniformly
   celldelta = maxrandom
   scale = fraction of cells that are decremented
------------------------------------------------------------------------- */

void FixAblate::set_delta_uniform()
{
  int nin;
  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  // enforce same decrement no matter who owns which cells
  // NOTE: could change this at some point to use differnet RNG for each proc

  for (int icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    // only ablate surfaces with a surface element (not fully inside or outside)

    nin = 0;
    for (int i = 0; i < ncorner; i++) {
      if (multi_val_flag) {
        if (mvalues[icell][i][0] > thresh) nin++;
      } else {
        if (cvalues[icell][i] > thresh) nin++;
      }
    }

    if (nin == 0 || nin == ncorner) celldelta[icell] = 0.0;
    else celldelta[icell] = maxrandom*scale;
  }

  // total decrement for output

  double sum = 0.0;
  for (int icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;
    sum += celldelta[icell];
  }

  MPI_Allreduce(&sum,&sum_delta,1,MPI_DOUBLE,MPI_SUM,world);
}

/* ----------------------------------------------------------------------
   set per-cell delta vector from compute/fix/variable source
   celldelta = nevery * scale * source-value
   NOTE: how does this work for split cells? should only do parent split?
------------------------------------------------------------------------- */

void FixAblate::set_delta()
{
  int i;

  double prefactor = nevery*scale;

  // compute/fix may invoke computes so wrap with clear/add

  modify->clearstep_compute();

  if (which == COMPUTE) {
    Compute *c = modify->compute[icompute];

    if (!(c->invoked_flag & INVOKED_PER_GRID)) {
      c->compute_per_grid();
      c->invoked_flag |= INVOKED_PER_GRID;
    }
    c->post_process_isurf_grid();

    if (argindex == 0) {
      double *cvec = c->vector_grid;
      for (i = 0; i < nglocal; i++)
        celldelta[i] = prefactor * cvec[i];
    } else {
      double **carray = c->array_grid;
      int im1 = argindex - 1;
      for (i = 0; i < nglocal; i++)
        celldelta[i] = prefactor * carray[i][im1];
    }

  } else if (which == FIX) {
    Fix *f = modify->fix[ifix];

    if (argindex == 0) {
      double *fvec = f->vector_grid;
      for (i = 0; i < nglocal; i++) {
        celldelta[i] = prefactor * fvec[i];
      }
    } else {
      double **farray = f->array_grid;
      int im1 = argindex - 1;
      for (i = 0; i < nglocal; i++)
        celldelta[i] = prefactor * farray[i][im1];
    }

  } else if (which == VARIABLE) {
    if (nglocal > maxvar) {
      maxvar = grid->maxlocal;
      memory->destroy(vbuf);
      memory->create(vbuf,maxvar,"ablate:vbuf");
    }

    input->variable->compute_grid(ivariable,vbuf,1,0);
    for (i = 0; i < nglocal; i++)
      celldelta[i] = prefactor * vbuf[i];
  }

  // NOTE: this does not get invoked on step 100,
  //   b/c needs to also be done in constructor
  //   ditto for fix adapt?
  //   they need nextvalid() methods like fix_ave_time
  //   or do it how output calcs next_stats for next thermo step

  modify->addstep_compute(update->ntimestep + nevery);

  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  double sum = 0.0;
  for (int icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;
    sum += celldelta[icell];
  }

  MPI_Allreduce(&sum,&sum_delta,1,MPI_DOUBLE,MPI_SUM,world);
}

/* ----------------------------------------------------------------------
   decrement corner points of each owned grid cell
   skip cells not in group, with no surfs, and sub-cells
   algorithm:
     no corner pt value can be < 0.0
     decrement smallest corner pt by full delta
     if cannot, decrement to 0.0, decrement next smallest by remainder, etc
------------------------------------------------------------------------- */

void FixAblate::decrement()
{
  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  int i,imin;
  double minvalue,total;
  double *corners;

  // total = full amount to decrement from cell
  // cdelta[icell] = amount to decrement from each corner point of icell

  for (int icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    for (i = 0; i < ncorner; i++) cdelta[icell][i] = 0.0;

    total = celldelta[icell];
    corners = cvalues[icell];
    while (total > 0.0) {
      imin = -1;
      minvalue = 256.0;
      for (i = 0; i < ncorner; i++) {
        if (corners[i] > 0.0 && corners[i] < minvalue &&
            cdelta[icell][i] == 0.0) {
          imin = i;
          minvalue = corners[i];
        }
      }
      if (imin == -1) break;

      if (total < corners[imin]) {
        cdelta[icell][imin] += total;
        total = 0.0;
      } else {
        cdelta[icell][imin] = corners[imin];
        total -= corners[imin];
      }
    }

    // celldelta[icell] is deliberately left alone: it is what this cell still
    //   owes, and sync() subtracts from it what the claims actually remove
    // the part of it the loop above could offer to no corner point, because
    //   they are all spent, therefore stays owed too
  }
}

/* ----------------------------------------------------------------------
   sync all copies of corner points values for all owned grid cells
   algorithm:
     comm my cdelta values that are shared by neighbor
     each corner point is shared by N cells, less on borders
     dsum = sum of decrements to that point by all N cells
     newvalue = MAX(oldvalue-dsum,0)
   all N copies of corner pt are set to newvalue
     in numerically consistent manner (same order of operations)
------------------------------------------------------------------------- */

void FixAblate::sync()
{
  int i,ix,iy,iz,jx,jy,jz,ixfirst,iyfirst,izfirst,jcorner;
  int icell,jcell;
  double total;

  comm_neigh_corners(CDELTA);

  // perform update of corner pts for all my owned grid cells
  //   using contributions from all cells that share the corner point
  // insure order of numeric operations will give exact same answer
  //   for all Ncorner duplicates of a corner point (stored by other cells)

  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  for (icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    ix = ixyz[icell][0];
    iy = ixyz[icell][1];
    iz = ixyz[icell][2];

    credit[icell] = 0.0;

    // loop over corner points

    for (i = 0; i < ncorner; i++) {

      // ixyz first = offset from icell of lower left cell of 2x2x2 stencil
      //              that shares the Ith corner point

      ixfirst = (i % 2) - 1;
      iyfirst = (i/2 % 2) - 1;
      if (dim == 2) izfirst = 0;
      else izfirst = (i / 4) - 1;

      // loop over 2x2x2 stencil of cells that share the corner point
      // also works for 2d, since izfirst = 0

      total = 0.0;
      jcorner = ncorner;

      for (jz = izfirst; jz <= izfirst+1; jz++) {
        for (jy = iyfirst; jy <= iyfirst+1; jy++) {
          for (jx = ixfirst; jx <= ixfirst+1; jx++) {
            jcorner--;

            // check if neighbor cell is within bounds of ablate grid

            if (ix+jx < 1 || ix+jx > nx) continue;
            if (iy+jy < 1 || iy+jy > ny) continue;
            if (iz+jz < 1 || iz+jz > nz) continue;

            // jcell = local index of (jx,jy,jz) neighbor cell of icell

            jcell = walk_to_neigh(icell,jx,jy,jz);

            // update total with one corner point of jcell
            // jcorner descends from ncorner

            if (jcell < nglocal) total += cdelta[jcell][jcorner];
            else total += cdelta_ghost[jcell-nglocal][jcorner];
          }
        }
      }

      // removed = what this corner point can actually give up
      // identical arithmetic to subtracting total when total fits, and an
      //   exact 0.0 when it does not, so all Ncorner duplicates still agree

      double oldvalue = cvalues[icell][i];
      double removed = MIN(total,oldvalue);
      cvalues[icell][i] = oldvalue - removed;

      // credit this cell with its share of what the corner point gave up
      // N cells can claim one corner point in the same epoch and only
      //   oldvalue can be removed, so each claimant gets the fraction of the
      //   removal its own claim asked for: the credits over all claimants
      //   sum to exactly removed, whichever cells they belong to
      // end_of_step() pays the uncredited remainder from another corner point
      //   of the same cell rather than dropping it

      if (total > 0.0) credit[icell] += cdelta[icell][i] * removed / total;

    }
  }

  // subtract what was paid, leaving the still unpaid decrement in celldelta

  for (icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;
    celldelta[icell] -= credit[icell];
    if (celldelta[icell] < EPSILON_DELTA) celldelta[icell] = 0.0;
  }
}

/* ----------------------------------------------------------------------
   ensure each corner point value is not too close to threshold
   this avoids creating tiny or zero-size surface elements
   corner_inside_min and corner_outside_max are set in store_corners()
     via epsilon method or isosurface stuffing method
------------------------------------------------------------------------- */

void FixAblate::epsilon_adjust(int initflag)
{
  if (mindist == 0.0 && !initflag) return;

  int i,icell;

  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  // a corner value exactly equal to thresh makes Marching Squares/Cubes place
  // a vertex exactly on a grid corner point.  When a surface feature is
  // grid-aligned this makes neighboring cells emit coincident vertices there,
  // producing a non-watertight surface (e.g. create_isurf of a body whose flat
  // face lies on a grid line).  Removing exactly-on-threshold values is a hard
  // numerical requirement, so it is enforced unconditionally when the corner
  // point values are first created (initflag = 1).  It is deliberately not
  // applied to the mid-ablation update, where nudging a corner point that
  // happens to land on the threshold would perturb an ongoing ablation run.
  // The wider EPSILON band, which also suppresses tiny surface elements, is
  // applied only when the user requests it via mindist > 0.

  for (icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    for (i = 0; i < ncorner; i++) {
      if (mindist > 0.0) {
        if (cvalues[icell][i] >= thresh && cvalues[icell][i] < thresh + EPSILON)
          cvalues[icell][i] = thresh - EPSILON;
        else if (cvalues[icell][i] < thresh && cvalues[icell][i] > thresh - EPSILON)
          cvalues[icell][i] = thresh - EPSILON;
      } else if (cvalues[icell][i] == thresh) {
        cvalues[icell][i] = thresh - EPSILON;
      }
    }
  }
}

/* ----------------------------------------------------------------------
   push corner points value to 0 or 255
     if all surrounding neighs are below or above threshold
     do this for all N copies of an affected corner point
   algorithm:
     comm my cdelta values that are shared by neighbor
     each corner point is shared by N cells, less on borders
     dsum = sum of decrements to that point by all N cells
     newvalue = MAX(oldvalue-dsum,0)
   all N copies of corner pt are set to newvalue
     in numerically consistent manner (same order of operations)
------------------------------------------------------------------------- */

void FixAblate::push_lohi()
{
  int i,ix,iy,iz,ixfirst,iyfirst,izfirst,jx,jy,jz;
  int icell,jcell,jcorner,pushflag;

  comm_neigh_corners(CVALUE);

  // perform push of corner pt values for all my owned grid cells
  //   by checking corner pt values of all cells that share same corner pt
  // if all surrounding corner pts are > threshold, push corner pt -> 255
  // if all surrounding corner pts are < threshold, push corner pt -> 0

  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  int plo = 0;
  int phi = 0;

  for (icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    ix = ixyz[icell][0];
    iy = ixyz[icell][1];
    iz = ixyz[icell][2];

    // loop over corner points

    for (i = 0; i < ncorner; i++) {

      // flag = -1 if corner pt value < threshold, +1 if > threshold

      if (cvalues[icell][i] < thresh) pushflag = -1;
      else if (cvalues[icell][i] > thresh) pushflag = 1;
      else continue;

      // ixyz first = offset from icell of lower left cell of 2x2x2 stencil
      //              that shares the Ith corner point

      ixfirst = (i % 2) - 1;
      iyfirst = (i/2 % 2) - 1;
      if (dim == 2) izfirst = 0;
      else izfirst = (i / 4) - 1;

      // loop over 2x2x2 stencil of cells that share the corner point
      // also works for 2d, since izfirst = 0

      jcorner = ncorner;

      for (jz = izfirst; jz <= izfirst+1; jz++) {
        for (jy = iyfirst; jy <= iyfirst+1; jy++) {
          for (jx = ixfirst; jx <= ixfirst+1; jx++) {
            jcorner--;

            // check if neighbor cell is within bounds of ablate grid

            if (ix+jx < 1 || ix+jx > nx) continue;
            if (iy+jy < 1 || iy+jy > ny) continue;
            if (iz+jz < 1 || iz+jz > nz) continue;

            // jcell = local index of (jx,jy,jz) neighbor cell of icell

            jcell = walk_to_neigh(icell,jx,jy,jz);

            // set pushflag to 0 if jcorner pt of jcell is not
            //   on same side of threshold as icorner or icell

            if (jcell < nglocal) {
              if ((pushflag == -1 && cvalues[jcell][jcorner] > thresh) ||
                  (pushflag == 1 && cvalues[jcell][jcorner] < thresh))
                pushflag = 0;
            } else {
              if ((pushflag == -1 && cdelta_ghost[jcell-nglocal][jcorner] >
                   thresh) ||
                  (pushflag == 1 && cdelta_ghost[jcell-nglocal][jcorner] <
                   thresh))
                pushflag = 0;
            }
          }
        }
      }

      // DEBUG OFF
      if (pushflag == -1) cvalues[icell][i] = 0;
      else if (pushflag == 1) cvalues[icell][i] = 255;

      if (pushflag == -1) plo++;
      else if (pushflag == 1) phi++;
    }
  }

  bigint bplo = plo;
  bigint bphi = phi;
  bigint ploall,phiall;
  MPI_Allreduce(&bplo,&ploall,1,MPI_SPARTA_BIGINT,MPI_SUM,world);
  MPI_Allreduce(&bphi,&phiall,1,MPI_SPARTA_BIGINT,MPI_SUM,world);

  if (me == 0) {
    if (screen)
      fprintf(screen,"  " BIGINT_FORMAT " " BIGINT_FORMAT
              " pushed corner pt values\n",ploall,phiall);
    if (logfile)
      fprintf(logfile,"  " BIGINT_FORMAT " " BIGINT_FORMAT
              " pushed corner pt values\n",ploall,phiall);
  }
}

/* ----------------------------------------------------------------------
   comm my cdelta values that are shared by neighbor cells
   each corner point is shared by N cells, less on borders
   done via irregular comm
------------------------------------------------------------------------- */

void FixAblate::comm_neigh_corners(int which)
{
  int i,j,k,n,ix,iy,iz,jx,jy,jz;
  bigint m;
  int icell,ifirst,jcell,proc,ilocal;

  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  // make list of datums to send to neighbor procs
  // 8 or 26 cells surrounding icell need icell's cdelta info
  // but only if they are owned by a neighbor proc
  // insure icell is only sent once to same neighbor proc
  // also set proclist and locallist for each sent datum

  int nsend = 0;

  for (icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    ix = ixyz[icell][0];
    iy = ixyz[icell][1];
    iz = ixyz[icell][2];
    ifirst = nsend;

    // loop over 3x3x3 stencil of neighbor cells centered on icell

    for (jz = -1; jz <= 1; jz++) {
      for (jy = -1; jy <= 1; jy++) {
        for (jx = -1; jx <= 1; jx++) {

          // skip neigh = self

          if (jx == 0 && jy == 0 && jz == 0) continue;

          // check if neighbor cell is within bounds of ablate grid

          if (ix+jx < 1 || ix+jx > nx) continue;
          if (iy+jy < 1 || iy+jy > ny) continue;
          if (iz+jz < 1 || iz+jz > nz) continue;

          // jcell = local index of (jx,jy,jz) neighbor cell of icell

          jcell = walk_to_neigh(icell,jx,jy,jz);

          // add a send list entry of icell to proc != me if haven't already

          proc = cells[jcell].proc;
          if (proc != me) {
            for (j = ifirst; j < nsend; j++)
              if (proc == proclist[j]) break;
            if (j == nsend) {
              if (nsend == maxsend) grow_send();
              proclist[nsend] = proc;
              locallist[nsend++] = cells[icell].id;
            }
          }
        }
      }
    }

    // # of neighbor procs to send icell to

    numsend[icell] = nsend - ifirst;
  }

  // realloc sbuf if necessary
  // ncomm = ilocal + Ncorner values

  int ncomm;
  if (multi_val_flag && which != NVERT) ncomm = 1 + ncorner*nmultiv;
  else ncomm = 1 + ncorner;

  if ((bigint) nsend*ncomm > MAXSMALLINT)
    error->one(FLERR,"Fix ablate comm buffer exceeds 2 GB");
  if (nsend*ncomm > maxbuf) {
    memory->destroy(sbuf);
    maxbuf = nsend*ncomm;
    memory->create(sbuf,maxbuf,"ablate:sbuf");
  }

  // pack datums to send
  // datum = ilocal of neigh cell on other proc + Ncorner values

  nsend = 0;
  m = 0;

  for (icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    n = numsend[icell];
    for (i = 0; i < n; i++) {
      sbuf[m++] = ubuf(locallist[nsend]).d;

      if (which == NVERT) {
        for (j = 0; j < ncorner; j++)
          sbuf[m++] = nvert[icell][j];
      } else {
        if (multi_val_flag) {
          if (which == CDELTA) {
            for (j = 0; j < ncorner; j++)
              for (k = 0; k < nmultiv; k++)
                sbuf[m++] = mdelta[icell][j][k];
          } else if (which == CVALUE) {
            for (j = 0; j < ncorner; j++)
              for (k = 0; k < nmultiv; k++)
               sbuf[m++] = mvalues[icell][j][k];
          }
        } else {
          if (which == CDELTA) {
            for (j = 0; j < ncorner; j++)
              sbuf[m++] = cdelta[icell][j];
          } else if (which == CVALUE) {
            for (j = 0; j < ncorner; j++)
              sbuf[m++] = cvalues[icell][j];
          }
        }
      }

      nsend++;

    }
  }

  // perform irregular neighbor comm
  // Comm class manages rbuf memory

  double *rbuf;
  int nrecv = comm->irregular_uniform_neighs(nsend,proclist,(char *) sbuf,
                                             ncomm*sizeof(double),
                                             (char **) &rbuf);

  // realloc cdelta_ghost if necessary

  if (grid->nghost > maxghost) {
    if (multi_val_flag) {
      memory->destroy(mdelta_ghost);
      maxghost = grid->nghost;
      memory->create(mdelta_ghost,maxghost,ncorner,nmultiv,"ablate:mdelta_ghost");
    } else {
      memory->destroy(cdelta_ghost);
      maxghost = grid->nghost;
      memory->create(cdelta_ghost,maxghost,ncorner,"ablate:cdelta_ghost");
    }

    memory->destroy(nvert_ghost);
    maxghost = grid->nghost;
    memory->create(nvert_ghost,maxghost,ncorner,"ablate:nvert_ghost");
  }

  // unpack received data into cdelta_ghost = ghost cell corner points

  // NOTE: need to check if hashfilled
  cellint cellID;
  Grid::MyHash *hash = grid->hash;

  m = 0;
  for (i = 0; i < nrecv; i++) {
    cellID = (cellint) ubuf(rbuf[m++]).u;
    ilocal = (*hash)[cellID];
    icell = ilocal - nglocal;
    if (which == NVERT) {
      for (j = 0; j < ncorner; j++)
        nvert_ghost[icell][j] = rbuf[m++];
    } else {
      if (multi_val_flag) {
        for (j = 0; j < ncorner; j++)
          for (k = 0; k < nmultiv; k++)
            mdelta_ghost[icell][j][k] = rbuf[m++];
      } else {
        for (j = 0; j < ncorner; j++)
          cdelta_ghost[icell][j] = rbuf[m++];
      }
    }

  }
}

/* ----------------------------------------------------------------------
   walk to neighbor of icell, offset by (jx,jy,jz)
   walk first by x, then by y, last by z
   return jcell = local index of neighbor cell
------------------------------------------------------------------------- */

int FixAblate::walk_to_neigh(int icell, int jx, int jy, int jz)
{
  Grid::ChildCell *cells = grid->cells;

  int jcell = icell;

  if (jx < 0) {
    if (grid->neigh_decode(cells[jcell].nmask,XLO) != NCHILD)
      error->one(FLERR,"Fix ablate walk to neighbor cell failed");
    jcell = cells[jcell].neigh[0];
  } else if (jx > 0) {
    if (grid->neigh_decode(cells[jcell].nmask,XHI) != NCHILD)
      error->one(FLERR,"Fix ablate walk to neighbor cell failed");
    jcell = cells[jcell].neigh[1];
  }

  if (jy < 0) {
    if (grid->neigh_decode(cells[jcell].nmask,YLO) != NCHILD)
      error->one(FLERR,"Fix ablate walk to neighbor cell failed");
    jcell = cells[jcell].neigh[2];
  } else if (jy > 0) {
    if (grid->neigh_decode(cells[jcell].nmask,YHI) != NCHILD)
      error->one(FLERR,"Fix ablate walk to neighbor cell failed");
    jcell = cells[jcell].neigh[3];
  }

  if (jz < 0) {
    if (grid->neigh_decode(cells[jcell].nmask,ZLO) != NCHILD)
      error->one(FLERR,"Fix ablate walk to neighbor cell failed");
    jcell = cells[jcell].neigh[4];
  } else if (jz > 0) {
    if (grid->neigh_decode(cells[jcell].nmask,ZHI) != NCHILD)
      error->one(FLERR,"Fix ablate walk to neighbor cell failed");
    jcell = cells[jcell].neigh[5];
  }

  return jcell;
}

/* ----------------------------------------------------------------------
   pack icell values for per-cell arrays into buf
   if icell is a split cell, also pack all sub cell values
   return byte count of amount packed
   if memflag, only return count, do not fill buf
------------------------------------------------------------------------- */

int FixAblate::pack_grid_one(int icell, char *buf, int memflag)
{
  char *ptr = buf;
  Grid::ChildCell *cells = grid->cells;
  Grid::SplitInfo *sinfo = grid->sinfo;

  if (!multi_val_flag) {
    if (memflag) memcpy(ptr,cvalues[icell],ncorner*sizeof(double));
    ptr += ncorner*sizeof(double);
  } else {
    for(int j = 0; j < ncorner; j++) {
      if (memflag) memcpy(ptr,mvalues[icell][j],nmultiv*sizeof(double));
      ptr += nmultiv*sizeof(double);
    }
  }

  if (tvalues_flag) {
    if (memflag) {
      double *dbuf = (double *) ptr;
      dbuf[0] = tvalues[icell];
    }
    ptr += sizeof(double);
  }

  if (memflag) {
    double *dbuf = (double *) ptr;
    dbuf[0] = ixyz[icell][0];
    dbuf[1] = ixyz[icell][1];
    dbuf[2] = ixyz[icell][2];
  }
  ptr += 3*sizeof(double);

  // DEBUG

  if (memflag) {
    double *dbuf = (double *) ptr;
    dbuf[0] = mcflags[icell][0];
    dbuf[1] = mcflags[icell][1];
    dbuf[2] = mcflags[icell][2];
    dbuf[3] = mcflags[icell][3];
  }
  ptr += 4*sizeof(double);

  if (cells[icell].nsplit > 1) {
    int isplit = cells[icell].isplit;
    int nsplit = cells[icell].nsplit;
    for (int i = 0; i < nsplit; i++) {
      int jcell = sinfo[isplit].csubs[i];

      if (!multi_val_flag) {
        if (memflag) memcpy(ptr,cvalues[jcell],ncorner*sizeof(double));
        ptr += ncorner*sizeof(double);
      } else {
        for(int j = 0; j < ncorner; j++) {
          if (memflag) memcpy(ptr,mvalues[jcell][j],nmultiv*sizeof(double));
          ptr += nmultiv*sizeof(double);
        }
      }

    }
  }

  return ptr-buf;
}

/* ----------------------------------------------------------------------
   unpack icell values for per-cell array from buf
   return byte count of amount unpacked
------------------------------------------------------------------------- */

int FixAblate::unpack_grid_one(int icell, char *buf)
{
  char *ptr = buf;
  Grid::ChildCell *cells = grid->cells;
  Grid::SplitInfo *sinfo = grid->sinfo;

  grow_percell(1);

  if (!multi_val_flag) {
    memcpy(cvalues[icell],ptr,ncorner*sizeof(double));
    ptr += ncorner*sizeof(double);
  } else {
    for(int j = 0; j < ncorner; j++) {
      memcpy(mvalues[icell][j],ptr,nmultiv*sizeof(double));
      ptr += nmultiv*sizeof(double);
    }
  }

  if (tvalues_flag) {
    double *dbuf = (double *) ptr;
    tvalues[icell] = static_cast<int> (dbuf[0]);
    ptr += sizeof(double);
  }

  double *dbuf = (double *) ptr;
  ixyz[icell][0] = static_cast<int> (dbuf[0]);
  ixyz[icell][1] = static_cast<int> (dbuf[1]);
  ixyz[icell][2] = static_cast<int> (dbuf[2]);
  ptr += 3*sizeof(double);

  dbuf = (double *) ptr;
  mcflags[icell][0] = static_cast<int> (dbuf[0]);
  mcflags[icell][1] = static_cast<int> (dbuf[1]);
  mcflags[icell][2] = static_cast<int> (dbuf[2]);
  mcflags[icell][3] = static_cast<int> (dbuf[3]);
  ptr += 4*sizeof(double);

  nglocal++;

  if (cells[icell].nsplit > 1) {
    int isplit = cells[icell].isplit;
    int nsplit = cells[icell].nsplit;
    grow_percell(nsplit);
    for (int i = 0; i < nsplit; i++) {
      int jcell = sinfo[isplit].csubs[i];

      if (!multi_val_flag) {
        memcpy(cvalues[jcell],ptr,ncorner*sizeof(double));
        ptr += ncorner*sizeof(double);
      } else {
        for(int j = 0; j < ncorner; j++) {
          memcpy(mvalues[jcell][j],ptr,nmultiv*sizeof(double));
          ptr += nmultiv*sizeof(double);
        }
      }

    }
    nglocal += nsplit;
  }

  return ptr-buf;
}

/* ----------------------------------------------------------------------
   copy per-cell info from Icell to Jcell
   called whenever a grid cell is removed from this processor's list
   caller checks that Icell != Jcell
------------------------------------------------------------------------- */

void FixAblate::copy_grid_one(int icell, int jcell)
{
  if (!multi_val_flag) {
    memcpy(cvalues[jcell],cvalues[icell],ncorner*sizeof(double));
  } else {
    for (int j = 0; j < ncorner; j++)
      memcpy(mvalues[jcell][j],mvalues[icell][j],nmultiv*sizeof(double));
  }

  if (tvalues_flag) tvalues[jcell] = tvalues[icell];

  ixyz[jcell][0] = ixyz[icell][0];
  ixyz[jcell][1] = ixyz[icell][1];
  ixyz[jcell][2] = ixyz[icell][2];

  mcflags[jcell][0] = mcflags[icell][0];
  mcflags[jcell][1] = mcflags[icell][1];
  mcflags[jcell][2] = mcflags[icell][2];
  mcflags[jcell][3] = mcflags[icell][3];
}

/* ----------------------------------------------------------------------
   add a grid cell
   called when a grid cell is added to this processor's list
   initialize values to 0.0
------------------------------------------------------------------------- */

void FixAblate::add_grid_one()
{
  grow_percell(1);

  if (!multi_val_flag) {
    for (int i = 0; i < ncorner; i++) cvalues[nglocal][i] = 0.0;
  } else {
    for (int i = 0; i < ncorner; i++)
      for (int j = 0; j < nmultiv; j++)
        mvalues[nglocal][i][j] = 0.0;
  }

  if (tvalues_flag) tvalues[nglocal] = 0;
  ixyz[nglocal][0] = 0;
  ixyz[nglocal][1] = 0;
  ixyz[nglocal][2] = 0;

  mcflags[nglocal][0] = -1;
  mcflags[nglocal][1] = -1;
  mcflags[nglocal][2] = -1;
  mcflags[nglocal][3] = -1;

  nglocal++;
}

/* ----------------------------------------------------------------------
   reset final grid cell count after grid cell removals
------------------------------------------------------------------------- */

void FixAblate::reset_grid_count(int nlocal)
{
  nglocal = nlocal;
}

/* ----------------------------------------------------------------------
   insure per-cell arrays are allocated long enough for Nnew cells
------------------------------------------------------------------------- */

void FixAblate::grow_percell(int nnew)
{
  if (nglocal+nnew < maxgrid) return;
  if (nnew == 0) maxgrid = nglocal;
  else maxgrid += DELTAGRID;
  if (multi_val_flag) memory->grow(mvalues,maxgrid,ncorner,nmultiv,"ablate:mvalues");
  else memory->grow(cvalues,maxgrid,ncorner,"ablate:cvalues");
  if (tvalues_flag) memory->grow(tvalues,maxgrid,"ablate:tvalues");
  memory->grow(ixyz,maxgrid,3,"ablate:ixyz");
  memory->grow(mcflags,maxgrid,4,"ablate:mcflags");
  memory->grow(celldelta,maxgrid,"ablate:celldelta");
  memory->grow(credit,maxgrid,"ablate:credit");
  if (multi_val_flag) memory->grow(mdelta,maxgrid,ncorner,nmultiv,"ablate:mdelta");
  else memory->grow(cdelta,maxgrid,ncorner,"ablate:cdelta");
  if (multi_dec_flag) memory->grow(nvert,maxgrid,ncorner,"ablate:nvert");
  memory->grow(numsend,maxgrid,"ablate:numsend");

  array_grid = cvalues;
}

/* ----------------------------------------------------------------------
   reallocate send vectors
------------------------------------------------------------------------- */

void FixAblate::grow_send()
{
  maxsend += DELTASEND;
  memory->grow(proclist,maxsend,"ablate:proclist");
  memory->grow(locallist,maxsend,"ablate:locallist");
}

/* ----------------------------------------------------------------------
   output sum of grid cell corner point values
   assume boundary corner points have value = 0.0
   NOTE: else would have to apply duplication weights to each of 4/8 corner pts
------------------------------------------------------------------------- */

double FixAblate::compute_scalar()
{
  int ix,iy,iz;

  Grid::ChildCell *cells = grid->cells;
  Grid::ChildInfo *cinfo = grid->cinfo;

  double sum = 0.0;
  double cavg;
  for (int icell = 0; icell < nglocal; icell++) {
    if (!(cinfo[icell].mask & groupbit)) continue;
    if (cells[icell].nsplit <= 0) continue;

    ix = ixyz[icell][0];
    iy = ixyz[icell][1];
    iz = ixyz[icell][2];

    if (dim == 2 && (ix == 0 || iy == 0)) continue;
    if (dim == 3 && (ix == 0 || iy == 0 || iz == 0)) continue;

    if (!multi_val_flag) sum += cvalues[icell][0];
    else {
      cavg = 0.0;
      for (int j = 0; j < nmultiv; j++) cavg += mvalues[icell][0][j];
      sum += cavg/nmultiv;
    }

  }

  double sumall;
  MPI_Allreduce(&sum,&sumall,1,MPI_DOUBLE,MPI_SUM,world);
  return sumall;
}

/* ----------------------------------------------------------------------
   vector outputs
   1 = last ablation decrement
   2 = # of deleted inside particles at last ablation
------------------------------------------------------------------------- */

double FixAblate::compute_vector(int i)
{
  if (i == 0) return sum_delta;
  if (i == 1) return 1.0*ndelete;
  if (i == 2) return sum_unpaid;
  return 0.0;
}

/* ----------------------------------------------------------------------
   process command line args
------------------------------------------------------------------------- */

void FixAblate::process_args(int narg, char **arg)
{
  mindist = 0.0;
  multi_dec_flag = 0;
  minmaxflag = 0;
  conserve_flag = 1;

  int iarg = 0;
  while (iarg < narg) {
    if (strcmp(arg[iarg],"mindist") == 0)  {
      if (iarg+2 > narg) error->all(FLERR,"Invalid read_isurf command");
      mindist = atof(arg[iarg+1]);
      if (mindist < 0.0 || mindist >= 0.5)
        error->all(FLERR,"Fix ablate mindist value must be >= 0.0 and < 0.5");
      mindist = MAX(mindist,EPSILON);
      iarg += 2;
    } else if (strcmp(arg[iarg],"multiple") == 0) {
      if (iarg+2 > narg) error->all(FLERR,"Invalid read_isurf command");
      if (strcmp(arg[iarg+1],"no") == 0) multi_dec_flag = 0;
      else if (strcmp(arg[iarg+1],"yes") == 0) multi_dec_flag = 1;
      else error->all(FLERR,"Illegal fix_ablate command");
      iarg += 2;
    } else if (strcmp(arg[iarg],"conserve") == 0) {
      if (iarg+2 > narg) error->all(FLERR,"Invalid fix ablate command");
      if (strcmp(arg[iarg+1],"no") == 0) conserve_flag = 0;
      else if (strcmp(arg[iarg+1],"yes") == 0) conserve_flag = 1;
      else error->all(FLERR,"Illegal fix_ablate command");
      iarg += 2;
    } else if (strcmp(arg[iarg],"minmax") == 0) {
      if (iarg+2 > narg) error->all(FLERR,"Invalid read_isurf command");
      if (strcmp(arg[iarg+1],"no") == 0) minmaxflag = 0;
      else if (strcmp(arg[iarg+1],"yes") == 0) minmaxflag = 1;
      else error->all(FLERR,"Illegal fix_ablate command");
      iarg += 2;
    } else error->all(FLERR,"Illegal fix_ablate command");
  }

}

/* ----------------------------------------------------------------------
   memory usage
------------------------------------------------------------------------- */

double FixAblate::memory_usage()
{
  double bytes = 0.0;
  if (multi_val_flag)
    bytes += (bigint) maxgrid*ncorner*nmultiv * sizeof(double); // mvalues
  else bytes += (bigint) maxgrid*ncorner * sizeof(double);   // cvalues
  if (tvalues_flag) bytes += maxgrid * sizeof(int);   // tvalues
  bytes += (bigint) maxgrid*3 * sizeof(int);            // ixyz
  // NOTE: add for mcflags if keep
  bytes += maxgrid * sizeof(double);           // celldelta
  bytes += maxgrid * sizeof(double);           // credit
  if (multi_val_flag)
    bytes += (bigint) maxgrid*ncorner*nmultiv * sizeof(double); // mdelta
  else bytes += (bigint) maxgrid*ncorner * sizeof(double);   // cdelta
  if (multi_val_flag)
    bytes += (bigint) maxgrid*ncorner*nmultiv * sizeof(double); // mdelta_ghost
  else bytes += (bigint) maxgrid*ncorner * sizeof(double);   // cdelta_ghost
  bytes += 3*((bigint) maxsend) * sizeof(int);            // proclist,locallist,numsend
  bytes += maxbuf * sizeof(double);            // sbuf
  return bytes;
}
