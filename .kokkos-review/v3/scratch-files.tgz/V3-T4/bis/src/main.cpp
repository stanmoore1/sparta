/* ----------------------------------------------------------------------
   SPARTA - Stochastic PArallel Rarefied-gas Time-accurate Analyzer
   http://sparta.github.io
   Steve Plimpton, sjplimp@gmail.com, Michael Gallis, magalli@sandia.gov
   Sandia National Laboratories

   Copyright (2014) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level SPARTA directory.
------------------------------------------------------------------------- */

#include "mpi.h"
#include "sparta.h"
#include "input.h"
#include "library.h"
#include "spaexception.h"

#include "stdlib.h"

using namespace SPARTA_NS;

// for convenience

static void finalize()
{
  sparta_kokkos_finalize();
}

/* ----------------------------------------------------------------------
   main program to drive SPARTA
------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
  MPI_Init(&argc,&argv);

  try {
    SPARTA *sparta = new SPARTA(argc,argv,MPI_COMM_WORLD);
    sparta->input->file();
    delete sparta;
  } catch (SpartaAbortException &e) {
    finalize();
    MPI_Abort(e.get_universe(),1);
  } catch (SpartaException &) {
    // error message was already printed by the Error class
    finalize();
    MPI_Finalize();
    exit(1);
  }

  finalize();

  MPI_Finalize();
}
