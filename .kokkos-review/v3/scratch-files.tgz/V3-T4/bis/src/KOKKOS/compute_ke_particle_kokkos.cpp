/* ----------------------------------------------------------------------
   SPARTA - Stochastic PArallel Rarefied-gas Time-accurate Analyzer
   http://sparta.github.io
   Steve Plimpton, sjplimp@gmail.com, Michael Gallis, magalli@sandia.gov
   Sandia National Laboratories

   Copyright (2014) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level SPARTA directory.
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------
   Contributing author: Alan Stagg (Sandia)
------------------------------------------------------------------------- */

#include "string.h"
#include "compute_ke_particle_kokkos.h"
#include "particle_kokkos.h"
#include "memory_kokkos.h"
#include "kokkos.h"
#include "update.h"
#include "sparta_masks.h"
#include "modify.h"
#include "comm.h"
#include "memory.h"
#include "error.h"

using namespace SPARTA_NS;

/* ---------------------------------------------------------------------- */

ComputeKEParticleKokkos::ComputeKEParticleKokkos(SPARTA *sparta, int narg, char **arg) :
  ComputeKEParticle(sparta, narg, arg)
{
  kokkos_flag = 1;
}

/* ---------------------------------------------------------------------- */

ComputeKEParticleKokkos::~ComputeKEParticleKokkos()
{
  if (copymode) return;
  memoryKK->destroy_kokkos(k_vector_particle,vector_particle);
  vector_particle = NULL;

  // ke aliases vector_particle in the host implementation
  //   (compute_ke_particle.cpp:71 "vector_particle = ke"), and
  //   ~ComputeKEParticle() frees ke.  Without clearing it here that base
  //   destructor frees the allocation just released above -- a double free
  //   at shutdown, after a run that produced entirely correct output

  ke = NULL;
}

/* ---------------------------------------------------------------------- */

void ComputeKEParticleKokkos::compute_per_particle()
{
  if (sparta->kokkos->prewrap) {
    ComputeKEParticle::compute_per_particle();
  }  else {
    compute_per_particle_kokkos();
    k_vector_particle.sync_host();
  }
}

/* ---------------------------------------------------------------------- */

void ComputeKEParticleKokkos::compute_per_particle_kokkos()
{
  invoked_per_particle = update->ntimestep;

  // grow ke array (d_vector_particle) if necessary
  // also when a prewrap host invocation allocated only the host ke
  if (particle->nlocal > nmax ||
      (int) k_vector_particle.extent(0) < particle->nlocal) {
    memoryKK->destroy_kokkos(k_vector_particle,vector_particle);
    ke = NULL;
    nmax = particle->maxlocal;
    memoryKK->create_kokkos(k_vector_particle,vector_particle,nmax,"ke/particle:vector_particle");
    d_vector_particle = k_vector_particle.view_device();
  }

  ParticleKokkos* particle_kk = (ParticleKokkos*) particle;
  particle_kk->sync(Device,PARTICLE_MASK|SPECIES_MASK);
  d_particles = particle_kk->k_particles.view_device();
  d_species = particle_kk->k_species.view_device();
  int nlocal = particle->nlocal;
  mvv2e = update->mvv2e;

  // compute kinetic energy for each atom in group
  copymode = 1;
  Kokkos::parallel_for(Kokkos::RangePolicy<DeviceType>(0,nlocal),*this);
  copymode = 0;

  k_vector_particle.modify_device();

  d_particles = t_particle_1d(); // destroy reference to reduce memory use
}

KOKKOS_INLINE_FUNCTION
void ComputeKEParticleKokkos::operator()(const int &i) const {
  const int ispecies = d_particles[i].ispecies;
  const double mass = d_species[ispecies].mass;
  double *v = d_particles[i].v;
  d_vector_particle[i] = 0.5 * mvv2e * mass * (v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
}
