# Install/unInstall package files in SPARTA
# mode = 0/1/2 for uninstall/install/update

mode=$1

# enforce using portable C locale
LC_ALL=C
export LC_ALL

# arg1 = file, arg2 = file it depends on

action () {
  if (test $mode = 0) then
    rm -f ../$1
  fi
}

# force rebuild of files with SPARTA_KOKKOS switch

KOKKOS_INSTALLED=0
if (test -e ../Makefile.package) then
  KOKKOS_INSTALLED=`grep DSPARTA_KOKKOS ../Makefile.package | wc -l`
fi

if (test $mode = 1) then
  if (test $KOKKOS_INSTALLED = 0) then
    touch ../accelerator_kokkos.h
  fi
elif (test $mode = 0) then
  if (test $KOKKOS_INSTALLED != 0) then
    touch ../accelerator_kokkos.h
  fi
fi

# list of files with optional dependencies

action collide_vss_kokkos.cpp
action collide_vss_kokkos.h
action compute_boundary_kokkos.cpp
action compute_boundary_kokkos.h
action compute_count_kokkos.cpp
action compute_count_kokkos.h
action compute_distsurf_grid_kokkos.cpp
action compute_distsurf_grid_kokkos.h
action compute_dt_grid_kokkos.cpp
action compute_dt_grid_kokkos.h
action compute_eflux_grid_kokkos.cpp
action compute_eflux_grid_kokkos.h
action compute_gas_collision_grid_kokkos.cpp
action compute_gas_collision_grid_kokkos.h
action compute_gas_reaction_grid_kokkos.cpp
action compute_gas_reaction_grid_kokkos.h
action compute_gas_collision_tally_kokkos.cpp
action compute_gas_collision_tally_kokkos.h
action compute_gas_reaction_tally_kokkos.cpp
action compute_gas_reaction_tally_kokkos.h
action compute_surf_collision_tally_kokkos.cpp
action compute_surf_collision_tally_kokkos.h
action compute_surf_reaction_tally_kokkos.cpp
action compute_surf_reaction_tally_kokkos.h
action compute_grid_kokkos.cpp
action compute_grid_kokkos.h
action compute_isurf_grid_kokkos.cpp
action compute_isurf_grid_kokkos.h
action compute_property_surf_kokkos.cpp
action compute_property_surf_kokkos.h
action compute_react_boundary_kokkos.cpp
action compute_react_boundary_kokkos.h
action compute_react_isurf_grid_kokkos.cpp
action compute_react_isurf_grid_kokkos.h
action compute_react_surf_kokkos.cpp
action compute_react_surf_kokkos.h
action compute_reduce_kokkos.cpp
action compute_reduce_kokkos.h
action compute_ke_particle_kokkos.cpp
action compute_ke_particle_kokkos.h
action compute_lambda_grid_kokkos.cpp
action compute_lambda_grid_kokkos.h
action compute_pflux_grid_kokkos.cpp
action compute_pflux_grid_kokkos.h
action compute_property_grid_kokkos.cpp
action compute_property_grid_kokkos.h
action compute_sonine_grid_kokkos.cpp
action compute_sonine_grid_kokkos.h
action compute_surf_kokkos.cpp
action compute_surf_kokkos.h
action compute_temp_kokkos.cpp
action compute_temp_kokkos.h
action compute_thermal_grid_kokkos.cpp
action compute_thermal_grid_kokkos.h
action compute_tvib_grid_kokkos.cpp
action compute_tvib_grid_kokkos.h
action comm_kokkos.cpp
action comm_kokkos.h
action domain_kokkos.cpp
action domain_kokkos.h
action fix_adapt_kokkos.cpp
action fix_adapt_kokkos.h
action fix_ambipolar_kokkos.cpp
action fix_ambipolar_kokkos.h
action fix_ave_grid_kokkos.cpp
action fix_ave_grid_kokkos.h
action fix_balance_kokkos.cpp
action fix_balance_kokkos.h
action fix_ave_histo_kokkos.cpp
action fix_ave_histo_kokkos.h
action fix_ave_histo_weight_kokkos.cpp
action fix_ave_histo_weight_kokkos.h
action fix_dt_reset_kokkos.cpp
action fix_dt_reset_kokkos.h
action fix_surf_temp_kokkos.cpp
action fix_surf_temp_kokkos.h
action fix_move_surf_kokkos.cpp
action fix_move_surf_kokkos.h
action fix_temp_global_rescale_kokkos.cpp
action fix_temp_global_rescale_kokkos.h
action fix_temp_rescale_kokkos.cpp
action fix_temp_rescale_kokkos.h
action fix_vibmode_kokkos.cpp
action fix_vibmode_kokkos.h
action geometry_kokkos.h
action grid_custom_kokkos.cpp
action grid_id_kokkos.cpp
action grid_kokkos.cpp
action grid_kokkos.h
action irregular_kokkos.cpp
action irregular_kokkos.h
action kokkos.cpp
action kokkos.h
action kokkos_base.h
action kokkos_copy.h
action kokkos_type.h
action math_extra_kokkos.h
action memory_kokkos.h
action modify_kokkos.cpp
action modify_kokkos.h
action particle_custom_kokkos.cpp
action particle_kokkos.cpp
action particle_kokkos.h
action rand_pool_wrap.cpp
action rand_pool_wrap.h
action react_bird_kokkos.cpp
action react_bird_kokkos.h
action react_qk_kokkos.cpp
action react_qk_kokkos.h
action react_tce_kokkos.cpp
action react_tce_kokkos.h
action react_tce_qk_kokkos.cpp
action react_tce_qk_kokkos.h
action surf_collide_adiabatic_kokkos.cpp
action surf_collide_adiabatic_kokkos.h
action surf_collide_cll_kokkos.cpp
action surf_collide_cll_kokkos.h
action surf_collide_diffuse_kokkos.cpp
action surf_collide_diffuse_kokkos.h
action surf_collide_impulsive_kokkos.cpp
action surf_collide_impulsive_kokkos.h
action surf_collide_piston_kokkos.cpp
action surf_collide_piston_kokkos.h
action surf_collide_specular_kokkos.cpp
action surf_collide_specular_kokkos.h
action surf_collide_td_kokkos.cpp
action surf_collide_td_kokkos.h
action surf_collide_transparent_kokkos.cpp
action surf_collide_transparent_kokkos.h
action surf_collide_vanish_kokkos.cpp
action surf_collide_vanish_kokkos.h
action surf_custom_kokkos.cpp
action surf_kokkos.cpp
action surf_kokkos.h
action surf_react_adsorb_kokkos.cpp
action surf_react_adsorb_kokkos.h
action surf_react_global_kokkos.cpp
action surf_react_global_kokkos.h
action surf_react_prob_kokkos.cpp
action surf_react_prob_kokkos.h
action update_kokkos.cpp
action update_kokkos.h
action kokkos_scan.cpp
action create_particles_kokkos.cpp
action create_particles_kokkos.h
action fix_emit_face_kokkos.cpp
action fix_emit_face_kokkos.h
action fix_emit_face_file_kokkos.cpp
action fix_emit_face_file_kokkos.h
action fix_emit_kokkos.h
action fix_emit_surf_kokkos.cpp
action fix_emit_surf_kokkos.h
action fix_field_grid_kokkos.cpp
action fix_field_grid_kokkos.h
action fix_field_particle_kokkos.cpp
action fix_field_particle_kokkos.h
action fix_grid_check_kokkos.cpp
action fix_grid_check_kokkos.h
action read_surf_kokkos.cpp
action read_surf_kokkos.h
action region_block_kokkos.cpp
action region_block_kokkos.h
action region_cylinder_kokkos.cpp
action region_cylinder_kokkos.h
action region_intersect_kokkos.cpp
action region_intersect_kokkos.h
action region_prim_kokkos.h
action region_union_kokkos.cpp
action region_union_kokkos.h
action region_plane_kokkos.cpp
action region_plane_kokkos.h
action region_sphere_kokkos.cpp
action region_sphere_kokkos.h
action remove_surf_kokkos.cpp
action remove_surf_kokkos.h
action variable_kokkos.cpp
action variable_kokkos.h

action compute_fft_grid_kokkos.cpp compute_fft_grid.cpp
action compute_fft_grid_kokkos.h compute_fft_grid.h
action fftdata_kokkos.h fftdata.h
action fft3d_kokkos.cpp fft3d.cpp
action fft3d_kokkos.h fft3d.h
action fft2d_kokkos.cpp fft2d.cpp
action fft2d_kokkos.h fft2d.h
action kissfft_kokkos.h kissfft.h
action pack2d_kokkos.h pack2d.h
action pack3d_kokkos.h pack3d.h
action remap2d_kokkos.cpp remap2d.cpp
action remap2d_kokkos.h remap2d.h
action remap3d_kokkos.cpp remap3d.cpp
action remap3d_kokkos.h remap3d.h
action kokkos_base_fft.h fftdata.h

# edit 2 Makefile.package files to include/exclude package info

if (test $1 = 1 || test $1 = 2) then
  echo "The KOKKOS package no longer supports the GNU Makefile build system. Please build SPARTA with CMake instead."
  exit 1

elif (test $1 = 0) then

  if (test -e ../Makefile.package) then
    sed -i -e 's/[^ \t]*kokkos[^ \t]* //g' ../Makefile.package
    sed -i -e 's/[^ \t]*KOKKOS[^ \t]* //g' ../Makefile.package
  fi

  if (test -e ../Makefile.package.settings) then
    sed -i -e '/CXX\ =\ \$(CC)/d' ../Makefile.package.settings
    sed -i -e '/^include.*kokkos.*$/d' ../Makefile.package.settings
  fi

fi
