/* ----------------------------------------------------------------------
   SPARTA - Stochastic PArallel Rarefied-gas Time-accurate Analyzer
   http://sparta.github.io
   Steve Plimpton, sjplimp@gmail.com, Michael Gallis, magalli@sandia.gov
   Sandia National Laboratories

   Copyright (2014) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level SPARTA directory.
------------------------------------------------------------------------- */

#include "string.h"
#include "compute_react_surf_kokkos.h"
#include "surf_kokkos.h"
#include "surf_react.h"
#include "grid.h"
#include "update.h"
#include "memory_kokkos.h"
#include "error.h"
#include "sparta_masks.h"
#include "kokkos.h"

using namespace SPARTA_NS;

/* ---------------------------------------------------------------------- */

ComputeReactSurfKokkos::ComputeReactSurfKokkos(SPARTA *sparta, int narg, char **arg) :
  ComputeReactSurf(sparta, narg, arg)
{
  kokkos_flag = 1;
  compressed = 0;
  nsurf_tally_alloc = 0;
}

ComputeReactSurfKokkos::ComputeReactSurfKokkos(SPARTA *sparta) :
  ComputeReactSurf(sparta)
{
  copy = 1;
  compressed = 0;
  nsurf_tally_alloc = 0;
}

/* ---------------------------------------------------------------------- */

ComputeReactSurfKokkos::~ComputeReactSurfKokkos()
{
  if (copy) return;

  memoryKK->destroy_kokkos(k_tally2surf,tally2surf);
  memoryKK->destroy_kokkos(k_array_surf_tally,array_surf_tally);
}

/* ---------------------------------------------------------------------- */

void ComputeReactSurfKokkos::init()
{
  ComputeReactSurf::init();

  if (rpflag) {
    int nreaction = surf->sr[isr]->nlist;
    d_reaction2col = DAT::t_int_2d("react/surf:reaction2col",nreaction,ntotal);
    auto h_r2c = Kokkos::create_mirror_view(d_reaction2col);
    for (int i = 0; i < nreaction; i++)
      for (int j = 0; j < ntotal; j++)
        h_r2c(i,j) = reaction2col[i][j];
    Kokkos::deep_copy(d_reaction2col,h_r2c);
  }

  resize_device(surf->nlocal + surf->nghost);
}

/* ---------------------------------------------------------------------- */

void ComputeReactSurfKokkos::resize_device(int nsurf)
{
  if (nsurf < 1) nsurf = 1;

  memoryKK->grow_kokkos(k_tally2surf,tally2surf,nsurf,"react/surf:tally2surf");
  d_tally2surf = k_tally2surf.view_device();

  d_surf2tally = DAT::t_int_1d("react/surf:surf2tally",nsurf);
  Kokkos::deep_copy(d_surf2tally,-1);

  memoryKK->grow_kokkos(k_array_surf_tally,array_surf_tally,nsurf,ntotal,
                        "react/surf:array_surf_tally");
  d_array_surf_tally = k_array_surf_tally.view_device();

  nsurf_tally_alloc = nsurf;
}

/* ---------------------------------------------------------------------- */

void ComputeReactSurfKokkos::clear()
{
  int nsurf = surf->nlocal + surf->nghost;
  if (nsurf > nsurf_tally_alloc) resize_device(nsurf);

  Kokkos::deep_copy(d_array_surf_tally,0);
  Kokkos::deep_copy(d_surf2tally,-1);

  ntally = 0;
  combined = 0;
  compressed = 0;
}

/* ---------------------------------------------------------------------- */

void ComputeReactSurfKokkos::pre_surf_tally()
{
  SurfKokkos* surf_kk = (SurfKokkos*) surf;
  surf_kk->sync(Device,ALL_MASK);
  d_lines = surf_kk->k_lines.view_device();
  d_tris = surf_kk->k_tris.view_device();

  need_dup = sparta->kokkos->need_dup<DeviceType>();
  if (need_dup)
    dup_array_surf_tally = Kokkos::Experimental::create_scatter_view<typename Kokkos::Experimental::ScatterSum, typename Kokkos::Experimental::ScatterDuplicated>(d_array_surf_tally);
  else
    ndup_array_surf_tally = Kokkos::Experimental::create_scatter_view<typename Kokkos::Experimental::ScatterSum, typename Kokkos::Experimental::ScatterNonDuplicated>(d_array_surf_tally);
}

/* ---------------------------------------------------------------------- */

void ComputeReactSurfKokkos::post_surf_tally()
{
  if (need_dup) {
    Kokkos::Experimental::contribute(d_array_surf_tally, dup_array_surf_tally);
    dup_array_surf_tally = {};
  }

  k_tally2surf.modify_device();
  k_array_surf_tally.modify_device();
}

/* ----------------------------------------------------------------------
   sync device tallies to host and compress to dense list (ntally tallies)
------------------------------------------------------------------------- */

int ComputeReactSurfKokkos::tallyinfo(surfint *&ptr)
{
  // compressing below is destructive, so only do it once per clear() cycle

  if (compressed) {
    ptr = tally2surf;
    return ntally;
  }
  compressed = 1;

  k_tally2surf.sync_host();
  ptr = tally2surf;

  k_array_surf_tally.sync_host();
  auto h_surf2tally = Kokkos::create_mirror_view(d_surf2tally);
  Kokkos::deep_copy(h_surf2tally,d_surf2tally);

  int nsurf = surf->nlocal + surf->nghost;
  int istart = 0;
  int iend = nsurf-1;

  while (1) {
    while (istart < nsurf && h_surf2tally[istart] != -1) istart++;
    while (h_surf2tally[iend] == -1 && iend > 0) iend--;
    if (istart >= iend) {
      ntally = istart;
      break;
    }
    for (int k = 0; k < ntotal; k++)
      array_surf_tally[istart][k] = array_surf_tally[iend][k];
    h_surf2tally[istart] = h_surf2tally[iend];
    h_surf2tally[iend] = -1;
    tally2surf[istart] = tally2surf[iend];
  }

  // see ComputeSurfKokkos::tallyinfo(): the compression rewrites the host side
  //   in place and the caller consumes it immediately, so the two sides are
  //   deliberately apart until the next clear()

  k_tally2surf.clear_sync_state();
  k_array_surf_tally.clear_sync_state();

  return ntally;
}

/* ----------------------------------------------------------------------
   sync device tally to host before the host base collates to per-surf;
   consumers (dump surf, compute reduce, ...) read via post_process_surf()
------------------------------------------------------------------------- */

void ComputeReactSurfKokkos::post_process_surf()
{
  if (combined) return;
  surfint *dummy;
  tallyinfo(dummy);
  ComputeReactSurf::post_process_surf();
}

/* ---------------------------------------------------------------------- */

void ComputeReactSurfKokkos::grow_tally()
{
  resize_device(surf->nlocal + surf->nghost);
}
