/* ----------------------------------------------------------------------
   SPARTA - Stochastic PArallel Rarefied-gas Time-accurate Analyzer
   http://sparta.github.io
   Steve Plimpton, sjplimp@gmail.com, Michael Gallis, magalli@sandia.gov
   Sandia National Laboratories

   Copyright (2014) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level SPARTA directory.
------------------------------------------------------------------------- */

/* ----------------------------------------------------------------------
   Contributing author: Nathan Fabian (Sandia)
------------------------------------------------------------------------- */

#include "mpi.h"
#include "math.h"
#include "ctype.h"
#include "stdlib.h"
#include "string.h"
#include "image.h"
#include "math_extra.h"
#include "math_const.h"
#include "error.h"
#include "memory.h"

#ifdef SPARTA_JPEG
#include "jpeglib.h"
#endif

#ifdef SPARTA_PNG
#include <png.h>
#include <zlib.h>
#include <setjmp.h>
#include "version.h"
#endif

using namespace SPARTA_NS;
using namespace MathConst;

#define NCOLORS 140
#define BIG 1.0e20
#define EPSILON 1.0e-6

enum{NUMERIC,MINVALUE,MAXVALUE};
enum{CONTINUOUS,DISCRETE,SEQUENTIAL};
enum{ABSOLUTE,FRACTIONAL};
enum{NO,YES};

// the surroundings mirrored by metallic surfaces: a bright sky above a dark
// ground.  these are not adjustable on purpose.  the effect is a cheap
// imitation, and a fake environment with more settings still cannot compete
// with rendering the same scene in a ray tracer

static const double SKYCOLOR[3] = {0.90, 0.94, 1.00};
static const double GROUNDCOLOR[3] = {0.10, 0.10, 0.12};

// screen-door transparency is realized with an ordered dither: a pixel of an
// object is only drawn when the threshold at its position in a repeating
// 16x16 Bayer matrix is at or below the requested opacity.  the pattern is
// anchored to the screen and not to the object, so it is the same on every
// MPI rank and costs a single table lookup per pixel.  pixels that are
// skipped are never passed to draw_pixel(), so every pixel that is drawn
// stays fully opaque and the depth buffer and the merge() compositing work
// unchanged.  see https://en.wikipedia.org/wiki/Ordered_dithering
//
// the matrix can be generated for any power of 2 rank with this python code:
//
// import numpy as np
//
// def bayer_matrix(n: int) -> np.ndarray:
//     """Generate an n x n Bayer (ordered dither) matrix for n a power of 2."""
//     if n == 1:
//         return np.array([[0]], dtype=int)
//     m = n // 2
//     B = bayer_matrix(m)
//     return np.block([[4 * B + 0, 4 * B + 2],
//                      [4 * B + 3, 4 * B + 1]])
//
// n = 16
// matrix = (bayer_matrix(n) + 0.5) / (n * n)
// for iy in range(0,n):
//     print([ "%.9f" % matrix[ix][iy] for ix in range(0,n) ])

static const int TRANK = 16;
static const double transthresh[TRANK][TRANK] = {
  {0.001953125, 0.751953125, 0.189453125, 0.939453125, 0.048828125,
   0.798828125, 0.236328125, 0.986328125, 0.013671875, 0.763671875,
   0.201171875, 0.951171875, 0.060546875, 0.810546875, 0.248046875,
   0.998046875},
  {0.501953125, 0.251953125, 0.689453125, 0.439453125, 0.548828125,
   0.298828125, 0.736328125, 0.486328125, 0.513671875, 0.263671875,
   0.701171875, 0.451171875, 0.560546875, 0.310546875, 0.748046875,
   0.498046875},
  {0.126953125, 0.876953125, 0.064453125, 0.814453125, 0.173828125,
   0.923828125, 0.111328125, 0.861328125, 0.138671875, 0.888671875,
   0.076171875, 0.826171875, 0.185546875, 0.935546875, 0.123046875,
   0.873046875},
  {0.626953125, 0.376953125, 0.564453125, 0.314453125, 0.673828125,
   0.423828125, 0.611328125, 0.361328125, 0.638671875, 0.388671875,
   0.576171875, 0.326171875, 0.685546875, 0.435546875, 0.623046875,
   0.373046875},
  {0.033203125, 0.783203125, 0.220703125, 0.970703125, 0.017578125,
   0.767578125, 0.205078125, 0.955078125, 0.044921875, 0.794921875,
   0.232421875, 0.982421875, 0.029296875, 0.779296875, 0.216796875,
   0.966796875},
  {0.533203125, 0.283203125, 0.720703125, 0.470703125, 0.517578125,
   0.267578125, 0.705078125, 0.455078125, 0.544921875, 0.294921875,
   0.732421875, 0.482421875, 0.529296875, 0.279296875, 0.716796875,
   0.466796875},
  {0.158203125, 0.908203125, 0.095703125, 0.845703125, 0.142578125,
   0.892578125, 0.080078125, 0.830078125, 0.169921875, 0.919921875,
   0.107421875, 0.857421875, 0.154296875, 0.904296875, 0.091796875,
   0.841796875},
  {0.658203125, 0.408203125, 0.595703125, 0.345703125, 0.642578125,
   0.392578125, 0.580078125, 0.330078125, 0.669921875, 0.419921875,
   0.607421875, 0.357421875, 0.654296875, 0.404296875, 0.591796875,
   0.341796875},
  {0.009765625, 0.759765625, 0.197265625, 0.947265625, 0.056640625,
   0.806640625, 0.244140625, 0.994140625, 0.005859375, 0.755859375,
   0.193359375, 0.943359375, 0.052734375, 0.802734375, 0.240234375,
   0.990234375},
  {0.509765625, 0.259765625, 0.697265625, 0.447265625, 0.556640625,
   0.306640625, 0.744140625, 0.494140625, 0.505859375, 0.255859375,
   0.693359375, 0.443359375, 0.552734375, 0.302734375, 0.740234375,
   0.490234375},
  {0.134765625, 0.884765625, 0.072265625, 0.822265625, 0.181640625,
   0.931640625, 0.119140625, 0.869140625, 0.130859375, 0.880859375,
   0.068359375, 0.818359375, 0.177734375, 0.927734375, 0.115234375,
   0.865234375},
  {0.634765625, 0.384765625, 0.572265625, 0.322265625, 0.681640625,
   0.431640625, 0.619140625, 0.369140625, 0.630859375, 0.380859375,
   0.568359375, 0.318359375, 0.677734375, 0.427734375, 0.615234375,
   0.365234375},
  {0.041015625, 0.791015625, 0.228515625, 0.978515625, 0.025390625,
   0.775390625, 0.212890625, 0.962890625, 0.037109375, 0.787109375,
   0.224609375, 0.974609375, 0.021484375, 0.771484375, 0.208984375,
   0.958984375},
  {0.541015625, 0.291015625, 0.728515625, 0.478515625, 0.525390625,
   0.275390625, 0.712890625, 0.462890625, 0.537109375, 0.287109375,
   0.724609375, 0.474609375, 0.521484375, 0.271484375, 0.708984375,
   0.458984375},
  {0.166015625, 0.916015625, 0.103515625, 0.853515625, 0.150390625,
   0.900390625, 0.087890625, 0.837890625, 0.162109375, 0.912109375,
   0.099609375, 0.849609375, 0.146484375, 0.896484375, 0.083984375,
   0.833984375},
  {0.666015625, 0.416015625, 0.603515625, 0.353515625, 0.650390625,
   0.400390625, 0.587890625, 0.337890625, 0.662109375, 0.412109375,
   0.599609375, 0.349609375, 0.646484375, 0.396484375, 0.583984375,
   0.333984375}
};

/* ---------------------------------------------------------------------- */

Image::Image(SPARTA *sparta, int nmap_caller) : Pointers(sparta)
{
  MPI_Comm_rank(world,&me);
  MPI_Comm_size(world,&nprocs);

  // defaults for 3d viz

  width = height = 512;
  theta = 60.0 * MY_PI/180.0;
  phi = 30.0 * MY_PI/180.0;
  zoom = 1.0;
  shiny = 1.0;
  gamma = 1.0;
  ssao = NO;
  ssaosamples = 0;
  fsaa = NO;
  depthcue = NO;
  depthcueint = 0.0;
  depthcuecolor = NULL;
  depthcuestartflag = 0;
  depthcuestart = 0.0;
  defocus = NO;
  defocusint = 0.0;
  defocusstartflag = 0;
  defocusstart = 0.0;
  outline = NO;
  outlinewidth = 0;
  outlinecolor = NULL;
  for (int i = 0; i < 6; i++) boxbounds[i] = 0.0;

  up[0] = 0.0;
  up[1] = 0.0;
  up[2] = 1.0;

  // colors

  ncolors = 0;
  username = NULL;
  userrgb = NULL;

  boxcolor = color2rgb("yellow");
  background[0] = background[1] = background[2] = 0;
  background2[0] = background2[1] = background2[2] = -1;

  // define nmap colormaps, all with default settings

  nmap = nmap_caller;
  maps = new ColorMap*[nmap];
  for (int i = 0; i < nmap; i++)
    maps[i] = new ColorMap(sparta,this);

  // static parameters

  FOV = MY_PI/6.0;              // 30 degrees
  ambientColor[0] = 0.0;
  ambientColor[1] = 0.0;
  ambientColor[2] = 0.0;

  keyLightPhi = -MY_PI4;        // -45 degrees
  keyLightTheta = MY_PI/6.0;    // 30 degrees
  keyLightColor[0] = 0.9;
  keyLightColor[1] = 0.9;
  keyLightColor[2] = 0.9;

  fillLightPhi = MY_PI/6.0;     // 30 degrees
  fillLightTheta = 0;
  fillLightColor[0] = 0.45;
  fillLightColor[1] = 0.45;
  fillLightColor[2] = 0.45;

  backLightPhi = MY_PI;         // 180 degrees
  backLightTheta = MY_PI/12.0;  // 15 degrees
  backLightColor[0] = 0.9;
  backLightColor[1] = 0.9;
  backLightColor[2] = 0.9;

  specularflag = 0;
  nospecular = 0;
  specularHardness = 16.0;
  specularIntensity = 1.0;

  // metallic shading is off by default, so that images are unchanged.
  // the default surroundings are a bright sky over a dark ground, which
  // is what makes a polished surface read as metal rather than as plastic

  metallic = 0.0;
  finishMirror = 0;
  finishBand = 0.6;
  finishWidth = 2.0;

  // MPI_Gatherv vectors

  recvcounts = NULL;
  displs = NULL;
}

/* ---------------------------------------------------------------------- */

Image::~Image()
{
  for (int i = 0; i < nmap; i++) delete maps[i];
  delete [] maps;

  for (int i = 0; i < ncolors; i++) delete [] username[i];
  memory->sfree(username);
  memory->destroy(userrgb);

  memory->destroy(depthBuffer);
  memory->destroy(surfaceBuffer);
  memory->destroy(imageBuffer);
  memory->destroy(depthcopy);
  memory->destroy(surfacecopy);
  memory->destroy(rgbcopy);

  memory->destroy(recvcounts);
  memory->destroy(displs);
}

/* ----------------------------------------------------------------------
   allocate image and depth buffers
   called after image size is set
------------------------------------------------------------------------- */

void Image::buffers()
{
  npixels = width * height;
  memory->create(depthBuffer,npixels,"image:depthBuffer");
  memory->create(surfaceBuffer,2*npixels,"image:surfaceBuffer");
  memory->create(imageBuffer,3*npixels,"image:imageBuffer");
  memory->create(depthcopy,npixels,"image:depthcopy");
  memory->create(surfacecopy,2*npixels,"image:surfacecopy");
  memory->create(rgbcopy,3*npixels,"image:rgbcopy");
}

/* ----------------------------------------------------------------------
   reset view parameters
   called once if view is STATIC
   called before every render if view is DYNAMIC
------------------------------------------------------------------------- */

void Image::view_params(double boxxlo, double boxxhi, double boxylo,
                        double boxyhi, double boxzlo, double boxzhi)
{
  // keep box bounds for projecting the box onto the view direction

  boxbounds[0] = boxxlo;
  boxbounds[1] = boxxhi;
  boxbounds[2] = boxylo;
  boxbounds[3] = boxyhi;
  boxbounds[4] = boxzlo;
  boxbounds[5] = boxzhi;

  // camDir points at the camera, view direction = -camDir

  camDir[0] = sin(theta)*cos(phi);
  camDir[1] = sin(theta)*sin(phi);
  camDir[2] = cos(theta);

  // normalize up vector

  if (up[0] == 0.0 && up[1] == 0.0 && up[2] == 0.0)
    error->all(FLERR,"Invalid image up vector");
  MathExtra::norm3(up);

  // adjust camDir by epsilon if camDir and up are parallel
  // do this by tweaking view direction, not up direction
  // try to insure continuous images as changing view passes thru up
  // sufficient to handle common cases where theta = 0 or 180 is degenerate?

  double dot = MathExtra::dot3(up,camDir);
  if (fabs(dot) > 1.0-EPSILON) {
    if (theta == 0.0) {
      camDir[0] = sin(EPSILON)*cos(phi);
      camDir[1] = sin(EPSILON)*sin(phi);
      camDir[2] = cos(EPSILON);
    } else if (theta == MY_PI) {
      camDir[0] = sin(theta-EPSILON)*cos(phi);
      camDir[1] = sin(theta-EPSILON)*sin(phi);
      camDir[2] = cos(theta-EPSILON);
    } else {
      camDir[0] = sin(theta+EPSILON)*cos(phi);
      camDir[1] = sin(theta+EPSILON)*sin(phi);
      camDir[2] = cos(theta+EPSILON);
    }
  }

  // camUp = camDir x (Up x camDir)

  MathExtra::cross3(up,camDir,camRight);
  MathExtra::norm3(camRight);
  MathExtra::cross3(camDir,camRight,camUp);
  if (camUp[0] == 0.0 && camUp[1] == 0.0 && camUp[2] == 0.0)
    error->all(FLERR,"Invalid image up vector");
  MathExtra::norm3(camUp);

  // zdist = camera distance = function of zoom & bounding box
  // camPos = camera position = function of camDir and zdist

  double delx = 2.0*(boxxhi-boxxlo);
  double dely = 2.0*(boxyhi-boxylo);
  double delz = 2.0*(boxzhi-boxzlo);
  double maxdel = MAX(delx,dely);
  maxdel = MAX(maxdel,delz);

  zdist = maxdel;
  zdist /= tan(FOV);
  zdist += 0.5 * (delx*camDir[0] + dely*camDir[1] + delz*camDir[2]);
  zdist /= zoom;

  camPos[0] = camDir[0] * zdist;
  camPos[1] = camDir[1] * zdist;
  camPos[2] = camDir[2] * zdist;

  // light directions in terms of -camDir = z

  setup_lights();

  // the brightness of the specular highlights follows shiny; their width
  // also follows shiny unless set with a dump_modify specular preset;
  // dump_modify specular none disables the highlights entirely

  specularIntensity = nospecular ? 0.0 : shiny;
  if (!specularflag) specularHardness = 16.0 * shiny;

  // adjust strength of the SSAO

  if (ssao) {
    SSAORadius = maxdel * 0.05 * ssaoint;
    SSAOSamples = static_cast<int> (8.0 + 32.0*ssaoint);
    SSAOJitter = MY_PI / 12;
    ambientColor[0] = 0.5;
    ambientColor[1] = 0.5;
    ambientColor[2] = 0.5;
  }

  // param for rasterizing spheres

  tanPerPixel = -(maxdel / (double) height);
}

/* ----------------------------------------------------------------------
   compute light directions from their theta/phi angles
   the angles are relative to the viewer with z pointing at the camera:
   theta > 0 moves a light above the view direction, phi > 0 to the right
------------------------------------------------------------------------- */

void Image::setup_lights()
{
  keyLightDir[0] = cos(keyLightTheta) * sin(keyLightPhi);
  keyLightDir[1] = sin(keyLightTheta);
  keyLightDir[2] = cos(keyLightTheta) * cos(keyLightPhi);

  fillLightDir[0] = cos(fillLightTheta) * sin(fillLightPhi);
  fillLightDir[1] = sin(fillLightTheta);
  fillLightDir[2] = cos(fillLightTheta) * cos(fillLightPhi);

  backLightDir[0] = cos(backLightTheta) * sin(backLightPhi);
  backLightDir[1] = sin(backLightTheta);
  backLightDir[2] = cos(backLightTheta) * cos(backLightPhi);

  keyHalfDir[0] = 0 + keyLightDir[0];
  keyHalfDir[1] = 0 + keyLightDir[1];
  keyHalfDir[2] = 1 + keyLightDir[2];
  MathExtra::norm3(keyHalfDir);
}

/* ----------------------------------------------------------------------
   initialize image to background color and depth buffer
   no need to init surfaceBuffer, since will be based on depth
------------------------------------------------------------------------- */

void Image::clear()
{
  int red = background[0];
  int green = background[1];
  int blue = background[2];

  int ix,iy;

  if (background2[0] < 0) {
    for (iy = 0; iy < height; iy ++)
      for (ix = 0; ix < width; ix ++) {
        imageBuffer[iy * width * 3 + ix * 3 + 0] = red;
        imageBuffer[iy * width * 3 + ix * 3 + 1] = green;
        imageBuffer[iy * width * 3 + ix * 3 + 2] = blue;
        depthBuffer[iy * width + ix] = -1;
      }

  // vertical gradient from background at bottom to background2 at top

  } else {
    for (iy = 0; iy < height; iy ++) {
      double fraction = (double) iy / (double) height;
      red = static_cast<int>
        (fraction*background2[0] + (1.0-fraction)*background[0]);
      green = static_cast<int>
        (fraction*background2[1] + (1.0-fraction)*background[1]);
      blue = static_cast<int>
        (fraction*background2[2] + (1.0-fraction)*background[2]);
      for (ix = 0; ix < width; ix ++) {
        imageBuffer[iy * width * 3 + ix * 3 + 0] = red;
        imageBuffer[iy * width * 3 + ix * 3 + 1] = green;
        imageBuffer[iy * width * 3 + ix * 3 + 2] = blue;
        depthBuffer[iy * width + ix] = -1;
      }
    }
  }
}

/* ----------------------------------------------------------------------
   merge image from each processor into one composite image
   done pixel by pixel, respecting depth buffer
   hi procs send to lo procs, cascading down logarithmically
------------------------------------------------------------------------- */

void Image::merge()
{
  MPI_Request requests[3];
  MPI_Status statuses[3];

  int nhalf = 1;
  while (nhalf < nprocs) nhalf *= 2;
  nhalf /= 2;

  while (nhalf) {
    if (me < nhalf && me+nhalf < nprocs) {
      MPI_Irecv(rgbcopy,npixels*3,MPI_BYTE,me+nhalf,0,world,&requests[0]);
      MPI_Irecv(depthcopy,npixels,MPI_DOUBLE,me+nhalf,0,world,&requests[1]);
      if (ssao)
        MPI_Irecv(surfacecopy,npixels*2,MPI_DOUBLE,
                  me+nhalf,0,world,&requests[2]);
      if (ssao) MPI_Waitall(3,requests,statuses);
      else MPI_Waitall(2,requests,statuses);

      for (int i = 0; i < npixels; i++) {
        if (depthBuffer[i] < 0 || (depthcopy[i] >= 0 &&
                                   depthcopy[i] < depthBuffer[i])) {
          depthBuffer[i] = depthcopy[i];
          imageBuffer[i*3+0] = rgbcopy[i*3+0];
          imageBuffer[i*3+1] = rgbcopy[i*3+1];
          imageBuffer[i*3+2] = rgbcopy[i*3+2];
          if (ssao) {
            surfaceBuffer[i*2+0] = surfacecopy[i*2+0];
            surfaceBuffer[i*2+1] = surfacecopy[i*2+1];
          }
        }
      }

    } else if (me >= nhalf && me < 2*nhalf) {
      MPI_Send(imageBuffer,npixels*3,MPI_BYTE,me-nhalf,0,world);
      MPI_Send(depthBuffer,npixels,MPI_DOUBLE,me-nhalf,0,world);
      if (ssao) MPI_Send(surfaceBuffer,npixels*2,MPI_DOUBLE,me-nhalf,0,world);
    }

    nhalf /= 2;
  }

  // extra SSAO enhancement
  // bcast full image to all procs
  // each works on subset of pixels
  // MPI_Gather() result back to proc 0
  // use Gatherv() if subset of pixels is not the same size on every proc

  if (ssao) {
    MPI_Bcast(imageBuffer,npixels*3,MPI_BYTE,0,world);
    MPI_Bcast(surfaceBuffer,npixels*2,MPI_DOUBLE,0,world);
    MPI_Bcast(depthBuffer,npixels,MPI_DOUBLE,0,world);
    compute_SSAO();

    int pixelstart = 3 * static_cast<int> (1.0*me/nprocs * npixels);
    int pixelstop = 3 * static_cast<int> (1.0*(me+1)/nprocs * npixels);
    int mypixels = pixelstop - pixelstart;

    if (npixels % nprocs == 0) {
      MPI_Gather(imageBuffer+pixelstart,mypixels,MPI_BYTE,
                 rgbcopy,mypixels,MPI_BYTE,0,world);

    } else {
      if (recvcounts == NULL) {
        memory->create(recvcounts,nprocs,"image:recvcounts");
        memory->create(displs,nprocs,"image:displs");
        MPI_Allgather(&mypixels,1,MPI_INT,recvcounts,1,MPI_INT,world);
        displs[0] = 0;
        for (int i = 1; i < nprocs; i++)
          displs[i] = displs[i-1] + recvcounts[i-1];
      }

      MPI_Gatherv(imageBuffer+pixelstart,mypixels,MPI_BYTE,
                  rgbcopy,recvcounts,displs,MPI_BYTE,0,world);
    }

    writeBuffer = rgbcopy;
  } else {
    writeBuffer = imageBuffer;
  }

  // draw outlines at depth discontinuities

  if (outline && me == 0) compute_outline();

  // apply depth cueing to the final composited image

  if (depthcue && me == 0) compute_depthcue();

  // blur the more distant objects in the final composited image

  if (defocus && me == 0) compute_defocus();

  // scale down image for anti-aliasing
  // can be done in place with simple averaging

  if (fsaa) {
    for (int h = 0; h < height; h += 2) {
      for (int w = 0; w < width; w += 2) {
        int idx1 = 3*width*h + 3*w;
        int idx2 = 3*width*h + 3*(w+1);
        int idx3 = 3*width*(h+1) + 3*w;
        int idx4 = 3*width*(h+1) + 3*(w+1);

        int out = 3*(width/2)*(h/2) + 3*(w/2);
        for (int i = 0; i < 3; ++i) {
          writeBuffer[out+i] = (unsigned char)
            (0.25*((int)(unsigned char)writeBuffer[idx1+i]
                   +(int)(unsigned char)writeBuffer[idx2+i]
                   +(int)(unsigned char)writeBuffer[idx3+i]
                   +(int)(unsigned char)writeBuffer[idx4+i]));
        }
      }
    }
  }
}

/* ----------------------------------------------------------------------
   draw a line as a cylinder
------------------------------------------------------------------------- */

void Image::draw_line(double *x1, double *x2, double *color, double diameter,
                      double opacity)
{
  if (opacity <= 0.0) return;
  draw_cylinder(x1,x2,color,diameter,3,opacity);
}

/* ----------------------------------------------------------------------
   draw outline of a 3d box as 12 cylinders
------------------------------------------------------------------------- */

void Image::draw_box(double (*corners)[3], double *color, double diameter,
                     double opacity)
{
  if (opacity <= 0.0) return;

  draw_cylinder(corners[0],corners[1],color,diameter,3,opacity);
  draw_cylinder(corners[2],corners[3],color,diameter,3,opacity);
  draw_cylinder(corners[0],corners[2],color,diameter,3,opacity);
  draw_cylinder(corners[1],corners[3],color,diameter,3,opacity);
  draw_cylinder(corners[0],corners[4],color,diameter,3,opacity);
  draw_cylinder(corners[1],corners[5],color,diameter,3,opacity);
  draw_cylinder(corners[2],corners[6],color,diameter,3,opacity);
  draw_cylinder(corners[3],corners[7],color,diameter,3,opacity);
  draw_cylinder(corners[4],corners[5],color,diameter,3,opacity);
  draw_cylinder(corners[6],corners[7],color,diameter,3,opacity);
  draw_cylinder(corners[4],corners[6],color,diameter,3,opacity);
  draw_cylinder(corners[5],corners[7],color,diameter,3,opacity);
}

/* ----------------------------------------------------------------------
   draw outline of a 2d rectangle as 4 cylinders
------------------------------------------------------------------------- */

void Image::draw_box2d(double (*corners)[3], double *color, double diameter,
                       double opacity)
{
  if (opacity <= 0.0) return;

  draw_cylinder(corners[0],corners[1],color,diameter,3,opacity);
  draw_cylinder(corners[2],corners[3],color,diameter,3,opacity);
  draw_cylinder(corners[0],corners[2],color,diameter,3,opacity);
  draw_cylinder(corners[1],corners[3],color,diameter,3,opacity);
}

/* ----------------------------------------------------------------------
   draw XYZ axes in red/green/blue
   axes = 4 end points
------------------------------------------------------------------------- */

void Image::draw_axes(double (*axes)[3], double diameter, double opacity)
{
  if (opacity <= 0.0) return;

  draw_cylinder(axes[0],axes[1],color2rgb("red"),diameter,3,opacity);
  draw_cylinder(axes[0],axes[2],color2rgb("green"),diameter,3,opacity);
  draw_cylinder(axes[0],axes[3],color2rgb("blue"),diameter,3,opacity);
}

/* ----------------------------------------------------------------------
   draw sphere at x with surfaceColor and diameter
   render pixel by pixel onto image plane with depth buffering
------------------------------------------------------------------------- */

void Image::draw_sphere(double *x, double *surfaceColor, double diameter,
                        double opacity)
{
  if (opacity <= 0.0) return;

  int ix,iy;
  double projRad;
  double xlocal[3],surface[3];
  double depth;

  xlocal[0] = x[0] - xctr;
  xlocal[1] = x[1] - yctr;
  xlocal[2] = x[2] - zctr;

  double xmap = MathExtra::dot3(camRight,xlocal);
  double ymap = MathExtra::dot3(camUp,xlocal);
  double dist = MathExtra::dot3(camPos,camDir) - MathExtra::dot3(xlocal,camDir);

  double radius = 0.5*diameter;
  double radsq = radius*radius;
  double pixelWidth = (tanPerPixel > 0) ? tanPerPixel * dist :
    -tanPerPixel / zoom;
  double pixelRadiusFull = radius / pixelWidth;
  int pixelRadius = static_cast<int> (pixelRadiusFull + 0.5) + 1;

  double xf = xmap / pixelWidth;
  double yf = ymap / pixelWidth;
  int xc = static_cast<int> (xf);
  int yc = static_cast<int> (yf);
  double width_error = xf - xc;
  double height_error = yf - yc;

  // shift 0,0 to screen center (vs lower left)

  xc += width / 2;
  yc += height / 2;

  for (iy = yc - pixelRadius; iy <= yc + pixelRadius; iy++) {
    for (ix = xc - pixelRadius; ix <= xc + pixelRadius; ix++) {
      if (iy < 0 || iy >= height || ix < 0 || ix >= width) continue;
      if (opacity < 1.0 && transthresh[ix % TRANK][iy % TRANK] > opacity)
        continue;

      surface[1] = ((iy - yc) - height_error) * pixelWidth;
      surface[0] = ((ix - xc) - width_error) * pixelWidth;
      projRad = surface[0]*surface[0] + surface[1]*surface[1];

      // outside the sphere in the projected image

      if (projRad > radsq) continue;
      surface[2] = sqrt(radsq - projRad);
      depth = dist - surface[2];

      surface[0] /= radius;
      surface[1] /= radius;
      surface[2] /= radius;

      draw_pixel (ix, iy, depth, surface, surfaceColor);
    }
  }
}

/* ----------------------------------------------------------------------
   draw axis oriented brick at x with surfaceColor and diameter[3] in extent
   render pixel by pixel onto image plane with depth buffering
------------------------------------------------------------------------- */

void Image::draw_brick(double *x, double *surfaceColor, double *diameter,
                       double opacity)
{
  // no test on diameter, the grid cutting planes pass a zero extent

  if (opacity <= 0.0) return;

  double xlocal[3],surface[3],normal[3];
  double t,tdir[3];
  double depth;

  xlocal[0] = x[0] - xctr;
  xlocal[1] = x[1] - yctr;
  xlocal[2] = x[2] - zctr;

  double xmap = MathExtra::dot3(camRight,xlocal);
  double ymap = MathExtra::dot3(camUp,xlocal);
  double dist = MathExtra::dot3(camPos,camDir) - MathExtra::dot3(xlocal,camDir);

  double radius[3];
  radius[0] = 0.5*diameter[0];
  radius[1] = 0.5*diameter[1];
  radius[2] = 0.5*diameter[2];

  double pixelWidth = (tanPerPixel > 0) ? tanPerPixel * dist :
    -tanPerPixel / zoom;

  double halfWidth = MAX(diameter[0],diameter[1]);
  halfWidth = MAX(halfWidth,diameter[2]);
  double pixelHalfWidthFull = halfWidth / pixelWidth;
  int pixelHalfWidth = static_cast<int> (pixelHalfWidthFull + 0.5);

  double xf = xmap / pixelWidth;
  double yf = ymap / pixelWidth;
  int xc = static_cast<int> (xf);
  int yc = static_cast<int> (yf);
  double width_error = xf - xc;
  double height_error = yf - yc;

  // shift 0,0 to screen center (vs lower left)

  xc += width / 2;
  yc += height / 2;

  for (int iy = yc - pixelHalfWidth; iy <= yc + pixelHalfWidth; iy ++) {
    for (int ix = xc - pixelHalfWidth; ix <= xc + pixelHalfWidth; ix ++) {
      if (iy < 0 || iy >= height || ix < 0 || ix >= width) continue;
      if (opacity < 1.0 && transthresh[ix % TRANK][iy % TRANK] > opacity)
        continue;

      double sy = ((iy - yc) - height_error) * pixelWidth;
      double sx = ((ix - xc) - width_error) * pixelWidth;
      surface[0] = camRight[0] * sx + camUp[0] * sy;
      surface[1] = camRight[1] * sx + camUp[1] * sy;
      surface[2] = camRight[2] * sx + camUp[2] * sy;

      // iterate through each of the 6 axis-oriented planes of the box
      // only render up to 3 which are facing the camera
      // these checks short circuit a dot product, testing for > 0

      for (int dim = 0; dim < 3; dim ++) {
        if (camDir[dim] > 0) {          // positive faces camera
          t = (radius[dim] - surface[dim]) / camDir[dim];
          normal[0] = camRight[dim];
          normal[1] = camUp[dim];
          normal[2] = camDir[dim];
        } else if (camDir[dim] < 0) {   // negative faces camera
          t = -(radius[dim] + surface[dim]) / camDir[dim];
          normal[0] = -camRight[dim];
          normal[1] = -camUp[dim];
          normal[2] = -camDir[dim];
        }
        if (camDir[dim] != 0) {
          tdir[0] = camDir[0] * t;
          tdir[1] = camDir[1] * t;
          tdir[2] = camDir[2] * t;

          bool xin = ((surface[0]+tdir[0]) >= -radius[0]) &&
            ((surface[0]+tdir[0]) <= radius[0]);
          bool yin = ((surface[1]+tdir[1]) >= -radius[1]) &&
            ((surface[1]+tdir[1]) <= radius[1]);
          bool zin = ((surface[2]+tdir[2]) >= -radius[2]) &&
            ((surface[2]+tdir[2]) <= radius[2]);

          switch (dim) {
          case 0:
            if (yin & zin) {
              depth = dist - t;
              draw_pixel (ix, iy, depth, normal, surfaceColor);
            }
            break;
          case 1:
            if (xin & zin) {
              depth = dist - t;
              draw_pixel (ix, iy, depth, normal, surfaceColor);
            }
            break;
          case 2:
            if (xin & yin) {
              depth = dist - t;
              draw_pixel (ix, iy, depth, normal, surfaceColor);
            }
            break;
          }
        }
      }
    }
  }
}

/* ----------------------------------------------------------------------
   draw cylinder from x to y with surfaceColor and diameter
   render pixel by pixel onto image plane with depth buffering
   if sflag = 0, draw no end spheres
   if sflag = 1, draw 1st end sphere
   if sflag = 2, draw 2nd end sphere
   if sflag = 3, draw both end spheres
------------------------------------------------------------------------- */

void Image::draw_cylinder(double *x, double *y,
                          double *surfaceColor, double diameter, int sflag,
                          double opacity)
{
  if (opacity <= 0.0) return;

  double surface[3], normal[3];
  double mid[3],xaxis[3],yaxis[3],zaxis[3];
  double camLDir[3], camLRight[3], camLUp[3];
  double zmin, zmax;

  if (sflag % 2) draw_sphere(x,surfaceColor,diameter,opacity);
  if (sflag/2) draw_sphere(y,surfaceColor,diameter,opacity);

  double radius = 0.5*diameter;
  double radsq = radius*radius;

  zaxis[0] = y[0] - x[0];
  zaxis[1] = y[1] - x[1];
  zaxis[2] = y[2] - x[2];

  double rasterWidth = fabs(MathExtra::dot3(zaxis, camRight)) + diameter;
  double rasterHeight = fabs(MathExtra::dot3(zaxis, camUp)) + diameter;

  mid[0] = (y[0] + x[0]) * 0.5 - xctr;
  mid[1] = (y[1] + x[1]) * 0.5 - yctr;
  mid[2] = (y[2] + x[2]) * 0.5 - zctr;

  double len = MathExtra::len3(zaxis);
  MathExtra::scale3(1.0/len,zaxis);
  len *= 0.5;
  zmax = len;
  zmin = -len;

  double xmap = MathExtra::dot3(camRight,mid);
  double ymap = MathExtra::dot3(camUp,mid);
  double dist = MathExtra::dot3(camPos,camDir) - MathExtra::dot3(mid,camDir);

  double pixelWidth = (tanPerPixel > 0) ? tanPerPixel * dist :
    -tanPerPixel / zoom;

  double xf = xmap / pixelWidth;
  double yf = ymap / pixelWidth;
  int xc = static_cast<int> (xf);
  int yc = static_cast<int> (yf);
  double width_error = xf - xc;
  double height_error = yf - yc;

  // shift 0,0 to screen center (vs lower left)

  xc += width / 2;
  yc += height / 2;

  double pixelHalfWidthFull = (rasterWidth * 0.5) / pixelWidth;
  double pixelHalfHeightFull = (rasterHeight * 0.5) / pixelWidth;
  int pixelHalfWidth = static_cast<int> (pixelHalfWidthFull + 0.5);
  int pixelHalfHeight = static_cast<int> (pixelHalfHeightFull + 0.5);

  if (zaxis[0] == camDir[0] && zaxis[1] == camDir[1] && zaxis[2] == camDir[2])
    return;
  if (zaxis[0] == -camDir[0] && zaxis[1] == -camDir[1] &&
      zaxis[2] == -camDir[2]) return;

  MathExtra::cross3(zaxis,camDir,yaxis);
  MathExtra::norm3(yaxis);
  MathExtra::cross3(yaxis,zaxis,xaxis);
  MathExtra::norm3(xaxis);

  camLDir[0] = MathExtra::dot3(camDir,xaxis);
  camLDir[1] = 0.0;
  camLDir[2] = MathExtra::dot3(camDir,zaxis);

  camLRight[0] = MathExtra::dot3(camRight,xaxis);
  camLRight[1] = MathExtra::dot3(camRight,yaxis);
  camLRight[2] = MathExtra::dot3(camRight,zaxis);
  MathExtra::norm3(camLRight);

  camLUp[0] = MathExtra::dot3(camUp,xaxis);
  camLUp[1] = MathExtra::dot3(camUp,yaxis);
  camLUp[2] = MathExtra::dot3(camUp,zaxis);
  MathExtra::norm3(camLUp);

  double a = camLDir[0] * camLDir[0];

  for (int iy = yc - pixelHalfHeight; iy <= yc + pixelHalfHeight; iy ++) {
    for (int ix = xc - pixelHalfWidth; ix <= xc + pixelHalfWidth; ix ++) {
      if (iy < 0 || iy >= height || ix < 0 || ix >= width) continue;
      if (opacity < 1.0 && transthresh[ix % TRANK][iy % TRANK] > opacity)
        continue;

      double sy = ((iy - yc) - height_error) * pixelWidth;
      double sx = ((ix - xc) - width_error) * pixelWidth;
      surface[0] = camLRight[0] * sx + camLUp[0] * sy;
      surface[1] = camLRight[1] * sx + camLUp[1] * sy;
      surface[2] = camLRight[2] * sx + camLUp[2] * sy;

      double b = 2 * camLDir[0] * surface[0];
      double c = surface[0] * surface[0] + surface[1] * surface[1] - radsq;

      double partial = b*b - 4*a*c;
      if (partial < 0) continue;
      partial = sqrt (partial);

      double t = (-b + partial) / (2*a);
      double t2 = (-b - partial) / (2*a);
      if (t2 > t) { t = t2; }

      surface[0] += t * camLDir[0];
      surface[1] += t * camLDir[1];
      surface[2] += t * camLDir[2];

      if (surface[2] > zmax || surface[2] < zmin) continue;

      // convert surface into the surface normal

      normal[0] = surface[0] / radius;
      normal[1] = surface[1] / radius;
      normal[2] = 0.0;

      // in camera space

      surface[0] = MathExtra::dot3 (normal, camLRight);
      surface[1] = MathExtra::dot3 (normal, camLUp);
      surface[2] = MathExtra::dot3 (normal, camLDir);

      double depth = dist - t;
      draw_pixel (ix, iy, depth, surface, surfaceColor);
    }
  }
}

/* ----------------------------------------------------------------------
   draw triangle with 3 corner points x,y,z and surfaceColor
------------------------------------------------------------------------- */

void Image::draw_triangle(double *x, double *y, double *z,
                          double *surfaceColor, double opacity)
{
  if (opacity <= 0.0) return;

  double d1[3], d1len, d2[3], d2len, normal[3], invndotd;
  double xlocal[3], ylocal[3], zlocal[3];
  double surface[3];
  double depth;

  xlocal[0] = x[0] - xctr;
  xlocal[1] = x[1] - yctr;
  xlocal[2] = x[2] - zctr;
  ylocal[0] = y[0] - xctr;
  ylocal[1] = y[1] - yctr;
  ylocal[2] = y[2] - zctr;
  zlocal[0] = z[0] - xctr;
  zlocal[1] = z[1] - yctr;
  zlocal[2] = z[2] - zctr;

  MathExtra::sub3 (xlocal, ylocal, d1);
  d1len = MathExtra::len3 (d1);
  MathExtra::scale3 (1.0 / d1len, d1);
  MathExtra::sub3 (zlocal, ylocal, d2);
  d2len = MathExtra::len3 (d2);
  MathExtra::scale3 (1.0 / d2len, d2);

  MathExtra::cross3 (d1, d2, normal);
  MathExtra::norm3 (normal);

  // ----------------
  // old code

  //invndotd = 1.0 / MathExtra::dot3(normal, camDir);

  // invalid triangle (parallel)

  //if (invndotd == 0) return;

  // ----------------
  // new code

  double ndotd = MathExtra::dot3(normal,camDir);
  if (ndotd >= 0.0) return;
  invndotd = 1.0 / ndotd;

  // ----------------

  double r[3],u[3];

  r[0] = MathExtra::dot3(camRight,xlocal);
  r[1] = MathExtra::dot3(camRight,ylocal);
  r[2] = MathExtra::dot3(camRight,zlocal);

  u[0] = MathExtra::dot3(camUp,xlocal);
  u[1] = MathExtra::dot3(camUp,ylocal);
  u[2] = MathExtra::dot3(camUp,zlocal);

  double rasterLeft = r[0] - MIN(r[0],MIN(r[1],r[2]));
  double rasterRight = MAX(r[0],MAX(r[1],r[2])) - r[0];
  double rasterDown = u[0] - MIN(u[0],MIN(u[1],u[2]));
  double rasterUp = MAX(u[0],MAX(u[1],u[2])) - u[0];

  double xmap = MathExtra::dot3(camRight,xlocal);
  double ymap = MathExtra::dot3(camUp,xlocal);
  double dist = MathExtra::dot3(camPos,camDir) - MathExtra::dot3(xlocal,camDir);

  double pixelWidth = (tanPerPixel > 0) ? tanPerPixel * dist :
    -tanPerPixel / zoom;

  double xf = xmap / pixelWidth;
  double yf = ymap / pixelWidth;
  int xc = static_cast<int> (xf);
  int yc = static_cast<int> (yf);
  double width_error = xf - xc;
  double height_error = yf - yc;

  // shift 0,0 to screen center (vs lower left)

  xc += width / 2;
  yc += height / 2;

  double pixelLeftFull = rasterLeft / pixelWidth;
  double pixelRightFull = rasterRight / pixelWidth;
  double pixelDownFull = rasterDown / pixelWidth;
  double pixelUpFull = rasterUp / pixelWidth;

  //old
  //int pixelLeft = static_cast<int> (pixelLeftFull + 0.5);
  //int pixelRight = static_cast<int> (pixelRightFull + 0.5);
  //int pixelDown = static_cast<int> (pixelDownFull + 0.5);
  //int pixelUp = static_cast<int> (pixelUpFull + 0.5);

  // new
  int pixelLeft = static_cast<int> (pixelLeftFull + 1.0);
  int pixelRight = static_cast<int> (pixelRightFull + 1.0);
  int pixelDown = static_cast<int> (pixelDownFull + 1.0);
  int pixelUp = static_cast<int> (pixelUpFull + 1.0);

  for (int iy = yc - pixelDown; iy <= yc + pixelUp; iy ++) {
    for (int ix = xc - pixelLeft; ix <= xc + pixelRight; ix ++) {
      if (iy < 0 || iy >= height || ix < 0 || ix >= width) continue;
      if (opacity < 1.0 && transthresh[ix % TRANK][iy % TRANK] > opacity)
        continue;

      double sy = ((iy - yc) - height_error) * pixelWidth;
      double sx = ((ix - xc) - width_error) * pixelWidth;
      surface[0] = camRight[0] * sx + camUp[0] * sy;
      surface[1] = camRight[1] * sx + camUp[1] * sy;
      surface[2] = camRight[2] * sx + camUp[2] * sy;

      double t = -MathExtra::dot3(normal,surface) * invndotd;

      // test inside the triangle

      double p[3];
      p[0] = xlocal[0] + surface[0] + camDir[0] * t;
      p[1] = xlocal[1] + surface[1] + camDir[1] * t;
      p[2] = xlocal[2] + surface[2] + camDir[2] * t;

      double s1[3], s2[3], s3[3];
      double c1[3], c2[3];

      MathExtra::sub3 (zlocal, xlocal, s1);
      MathExtra::sub3 (ylocal, xlocal, s2);
      MathExtra::sub3 (p, xlocal, s3);
      MathExtra::cross3 (s1, s2, c1);
      MathExtra::cross3 (s1, s3, c2);
      if (MathExtra::dot3 (c1, c2) <= 0) continue;

      MathExtra::sub3 (xlocal, ylocal, s1);
      MathExtra::sub3 (zlocal, ylocal, s2);
      MathExtra::sub3 (p, ylocal, s3);
      MathExtra::cross3 (s1, s2, c1);
      MathExtra::cross3 (s1, s3, c2);
      if (MathExtra::dot3 (c1, c2) <= 0) continue;

      MathExtra::sub3 (ylocal, zlocal, s1);
      MathExtra::sub3 (xlocal, zlocal, s2);
      MathExtra::sub3 (p, zlocal, s3);
      MathExtra::cross3 (s1, s2, c1);
      MathExtra::cross3 (s1, s3, c2);
      if (MathExtra::dot3 (c1, c2) <= 0) continue;

      double cNormal[3];
      cNormal[0] = MathExtra::dot3(camRight, normal);
      cNormal[1] = MathExtra::dot3(camUp, normal);
      cNormal[2] = MathExtra::dot3(camDir, normal);

      depth = dist - t;
      draw_pixel(ix,iy,depth,cNormal,surfaceColor);
    }
  }
}

/* ---------------------------------------------------------------------- */

void Image::draw_pixel(int ix, int iy, double depth,
                           double *surface, double *surfaceColor)
{
  double diffuseKey,diffuseFill,diffuseBack,specularKey;
  if (depth < 0 || (depthBuffer[ix + iy*width] >= 0 &&
                    depth >= depthBuffer[ix + iy*width])) return;
  depthBuffer[ix + iy*width] = depth;

  // store only the tangent relative to the camera normal (0,0,-1)

  surfaceBuffer[0 + ix * 2 + iy*width * 2] = surface[1];
  surfaceBuffer[1 + ix * 2 + iy*width * 2] = -surface[0];

  diffuseKey = saturate(MathExtra::dot3(surface, keyLightDir));
  diffuseFill = saturate(MathExtra::dot3(surface, fillLightDir));
  diffuseBack = saturate(MathExtra::dot3(surface, backLightDir));

  // a metal reflects nearly all light directly and tints the reflection with
  // its own color, while a non-conductor scatters light diffusely and reflects
  // it without tinting.  "metallic" blends between those two limits: it scales
  // down the diffuse contributions and turns "reflect" into the color of the
  // reflected light.  for metallic = 0.0 this reproduces the plain shading.

  const double diffuse = 1.0 - metallic;
  double reflect[3];
  reflect[0] = metallic * surfaceColor[0] + diffuse;
  reflect[1] = metallic * surfaceColor[1] + diffuse;
  reflect[2] = metallic * surfaceColor[2] + diffuse;

  // the view dependent terms below need a camera facing normal.  draw_sphere
  // and draw_cylinder supply one, but draw_triangle passes the outward normal
  // of the element, which for a drawn face points away from the camera
  // because of the back face cull there.  flip a copy so both conventions
  // give the same result; the diffuse and specular terms above keep using the
  // normal as passed, so images without metallic shading are unchanged.

  double vnormal[3];
  if (surface[2] < 0.0) {
    vnormal[0] = -surface[0];
    vnormal[1] = -surface[1];
    vnormal[2] = -surface[2];
  } else {
    vnormal[0] = surface[0];
    vnormal[1] = surface[1];
    vnormal[2] = surface[2];
  }

  // every surface becomes mirror-like when viewed at a grazing angle, which
  // brightens the outline of a curved object.  the amount follows Schlick's
  // approximation.  the viewing direction is (0,0,1) in these coordinates,
  // so its dot product with the surface normal is simply the z component

  const double viewdot = saturate(vnormal[2]);
  const double grazing =
    (1.0-viewdot)*(1.0-viewdot)*(1.0-viewdot)*(1.0-viewdot)*(1.0-viewdot);
  reflect[0] += (1.0 - reflect[0]) * grazing;
  reflect[1] += (1.0 - reflect[1]) * grazing;
  reflect[2] += (1.0 - reflect[2]) * grazing;

  double c[3];
  c[0] = surfaceColor[0] * ambientColor[0] * diffuse;
  c[1] = surfaceColor[1] * ambientColor[1] * diffuse;
  c[2] = surfaceColor[2] * ambientColor[2] * diffuse;

  c[0] += surfaceColor[0] * keyLightColor[0] * diffuseKey * diffuse;
  c[1] += surfaceColor[1] * keyLightColor[1] * diffuseKey * diffuse;
  c[2] += surfaceColor[2] * keyLightColor[2] * diffuseKey * diffuse;

  // specular highlights are disabled with dump_modify specular none.
  // check the flag here since view_params() may not run again after
  // dump_modify for static views

  if (!nospecular && specularIntensity > 0.0) {
    specularKey = pow(saturate(MathExtra::dot3(surface, keyHalfDir)),
                      specularHardness) * specularIntensity;

    c[0] += keyLightColor[0] * reflect[0] * specularKey;
    c[1] += keyLightColor[1] * reflect[1] * specularKey;
    c[2] += keyLightColor[2] * reflect[2] * specularKey;
  }

  c[0] += surfaceColor[0] * fillLightColor[0] * diffuseFill * diffuse;
  c[1] += surfaceColor[1] * fillLightColor[1] * diffuseFill * diffuse;
  c[2] += surfaceColor[2] * fillLightColor[2] * diffuseFill * diffuse;

  c[0] += surfaceColor[0] * backLightColor[0] * diffuseBack * diffuse;
  c[1] += surfaceColor[1] * backLightColor[1] * diffuseBack * diffuse;
  c[2] += surfaceColor[2] * backLightColor[2] * diffuseBack * diffuse;

  // a metal also mirrors its surroundings, which are approximated by a sky
  // color above and a ground color below.  the direction into which the
  // surface reflects the viewer is 2 (n.v) n - v, and only its vertical
  // component is needed to pick the color from that gradient

  if (metallic > 0.0) {
    const double updir = finishMirror ? 2.0*viewdot*vnormal[1] : vnormal[1];
    double updown = saturate(0.5 * (updir + 1.0));
    updown = updown * updown * (3.0 - 2.0*updown);    // narrow the horizon

    // brighten a band around the horizon, where the surroundings of a real
    // scene are brightest.  this is what produces the light streak across a
    // polished surface that reads as "shiny metal" rather than "dark paint"

    double band = 0.0;
    if (finishBand > 0.0)
      band = finishBand * pow(1.0 - fabs(2.0*updown - 1.0), finishWidth);

    c[0] += metallic * reflect[0] *
      (GROUNDCOLOR[0] + updown*(SKYCOLOR[0]-GROUNDCOLOR[0]) + band);
    c[1] += metallic * reflect[1] *
      (GROUNDCOLOR[1] + updown*(SKYCOLOR[1]-GROUNDCOLOR[1]) + band);
    c[2] += metallic * reflect[2] *
      (GROUNDCOLOR[2] + updown*(SKYCOLOR[2]-GROUNDCOLOR[2]) + band);
  }

  c[0] = saturate(c[0]);
  c[1] = saturate(c[1]);
  c[2] = saturate(c[2]);

  // apply gamma adjustment to the summed up light contributions

  if (gamma != 1.0) {
    c[0] = pow(c[0], 1.0 / gamma);
    c[1] = pow(c[1], 1.0 / gamma);
    c[2] = pow(c[2], 1.0 / gamma);
  }

  imageBuffer[0 + ix*3 + iy*width*3] = static_cast<int>(c[0] * 255.0);
  imageBuffer[1 + ix*3 + iy*width*3] = static_cast<int>(c[1] * 255.0);
  imageBuffer[2 + ix*3 + iy*width*3] = static_cast<int>(c[2] * 255.0);
}

/* ---------------------------------------------------------------------- */

void Image::compute_SSAO()
{
  // number of horizon directions per pixel.  a chosen value must override
  // the automatic one here, since view_params() may have run before it was set

  const int nsamples = (ssaosamples > 0) ? ssaosamples : SSAOSamples;

  // used for rasterizing the spheres

  double delTheta = 2.0*MY_PI / nsamples;

  // typical neighborhood value for shading

  double pixelWidth = (tanPerPixel > 0) ? tanPerPixel :
        -tanPerPixel / zoom;
  int pixelRadius = (int) trunc (SSAORadius / pixelWidth + 0.5);

  // each proc is assigned a subset of contiguous pixels from the full image
  // pixels are contiguous in x (columns within a row), then by row
  // index = pixels from 0 to npixel-1
  // x = column # from 0 to width-1
  // y = row # from 0 to height-1

  int pixelstart = static_cast<int> (1.0*me/nprocs * npixels);
  int pixelstop = static_cast<int> (1.0*(me+1)/nprocs * npixels);

  // shift of the jitter noise pattern derived from the seed value

  const double seedshift = fmod(0.618033988749895 * (double) seed, 1.0);

  // table of evenly spaced horizon directions, computed once; each pixel
  // rotates the whole table by its per-pixel jitter angle

  double *dirTable = new double[2*nsamples];
  for (int s = 0; s < nsamples; s++) {
    dirTable[2*s]   = cos(s * delTheta);
    dirTable[2*s+1] = sin(s * delTheta);
  }

  for (int index = pixelstart; index < pixelstop; index++) {
    int x = index % width;
    int y = index / width;

    double cdepth = depthBuffer[index];
    if (cdepth < 0) { continue; }

    double sx = surfaceBuffer[index * 2 + 0];
    double sy = surfaceBuffer[index * 2 + 1];
    double sin_t = -sqrt(sx*sx + sy*sy);

    // deterministic per-pixel jitter from interleaved gradient noise, so
    // shading is independent of the number of MPI ranks and images of
    // unchanged scenes are reproducible

    double ign = fmod(0.06711056 * x + 0.00583715 * y + seedshift, 1.0);
    const double mytheta = fmod(52.9829189 * ign, 1.0) * SSAOJitter;
    const double cosj = cos(mytheta);
    const double sinj = sin(mytheta);
    double ao = 0.0;

    for (int s = 0; s < nsamples; s ++) {
      double hx = cosj * dirTable[2*s] - sinj * dirTable[2*s+1];
      double hy = sinj * dirTable[2*s] + cosj * dirTable[2*s+1];

      // multiply by z cross surface tangent
      // so that dot (aka cos) works here

      double scaled_sin_t = sin_t * (hx*sy + hy*sx);

      // Bresenham's line algorithm to march over depthBuffer

      int dx = static_cast<int> (hx * pixelRadius);
      int dy = static_cast<int> (hy * pixelRadius);
      int ex = x + dx;
      if (ex < 0) { ex = 0; } if (ex >= width) { ex = width - 1; }
      int ey = y + dy;
      if (ey < 0) { ey = 0; } if (ey >= height) { ey = height - 1; }
      double delta;
      int small, large;
      double lenIncr;
      if (fabs(hx) > fabs(hy)) {
        small = (hx > 0) ? 1 : -1;
        large = (hy > 0) ? width : -width;
        delta = fabs(hy / hx);
      } else {
        small = (hy > 0) ? width : -width;
        large = (hx > 0) ? 1 : -1;
        delta = fabs(hx / hy);
      }
      lenIncr = sqrt (1 + delta * delta) * pixelWidth;

      // initialize with one step
      // because the center point doesn't need testing

      int end = ex + ey * width;
      int ind = index + small;
      double len = lenIncr;
      double err = delta;
      if (err >= 1.0) {
        ind += large;
        err -= 1.0;
      }

      double minPeak = -1;
      double peakLen = 0.0;
      int stepsTaken = 1;
      while ((small > 0 && ind <= end) || (small < 0 && ind >= end)) {
        if (ind < 0 || ind >= (width*height)) {
          break;
        }

        // cdepth - depthBuffer B/C we want it in the negative z direction

        if (minPeak < 0 || (depthBuffer[ind] >= 0 &&
                            depthBuffer[ind] < minPeak)) {
          minPeak = depthBuffer[ind];
          peakLen = len;
        }
        ind += small;
        len += lenIncr;
        err += delta;
        if (err >= 1.0) {
          ind += large;
          err -= 1.0;
        }
        stepsTaken ++;
      }

      if (peakLen > 0) {
        double h = atan ((cdepth - minPeak) / peakLen);
        ao += saturate(sin (h) - scaled_sin_t);
      } else {
        ao += saturate(-scaled_sin_t);
      }
    }
    ao /= (double)nsamples;

    double c[3];
    c[0] = (double) (*(unsigned char *) &imageBuffer[index * 3 + 0]);
    c[1] = (double) (*(unsigned char *) &imageBuffer[index * 3 + 1]);
    c[2] = (double) (*(unsigned char *) &imageBuffer[index * 3 + 2]);
    c[0] *= (1.0 - ao);
    c[1] *= (1.0 - ao);
    c[2] *= (1.0 - ao);
    imageBuffer[index * 3 + 0] = (int) c[0];
    imageBuffer[index * 3 + 1] = (int) c[1];
    imageBuffer[index * 3 + 2] = (int) c[2];
  }

  delete [] dirTable;
}

/* ----------------------------------------------------------------------
   largest of the 3 doubled box extents, the length scale the renderer
   uses for the view; same quantity view_params() derives from its args
------------------------------------------------------------------------- */

double Image::box_maxdel() const
{
  const double delx = 2.0 * (boxbounds[1] - boxbounds[0]);
  const double dely = 2.0 * (boxbounds[3] - boxbounds[2]);
  const double delz = 2.0 * (boxbounds[5] - boxbounds[4]);
  double maxdel = MAX(delx,dely);
  return MAX(maxdel,delz);
}

/* ----------------------------------------------------------------------
   draw outlines on the composited image on the output rank: color
   drawn pixels that have a significantly more distant pixel or the
   background within the outline width.  the outline hugs the nearer
   object at depth discontinuities, which gives the flat illustration
   look known from hand-drawn molecular graphics.
------------------------------------------------------------------------- */

void Image::compute_outline()
{
  // only depth jumps between immediately adjacent pixels that are larger
  // than a small fraction of the box size count as edges.  the smooth but
  // steep depth changes where a curved surface turns away from the viewer
  // must not be outlined, so the threshold is of the order of typical
  // particle sizes and the comparison spans only one pixel

  const double threshold = 0.02 * box_maxdel();

  // the outline width follows the internal image size with FSAA

  int w = outlinewidth;
  if (fsaa) w *= 2;

  const char red   = (char) static_cast<unsigned char> (outlinecolor[0] * 255.0);
  const char green = (char) static_cast<unsigned char> (outlinecolor[1] * 255.0);
  const char blue  = (char) static_cast<unsigned char> (outlinecolor[2] * 255.0);

  // mark drawn pixels that have a much more distant immediate neighbor
  // or border on the background

  char *edges = new char[npixels];
  memset(edges,0,npixels);

  for (int iy = 0; iy < height; iy++) {
    for (int ix = 0; ix < width; ix++) {
      const double d = depthBuffer[iy*width + ix];
      if (d < 0.0) continue;

      static const int xoff[4] = {-1, 1, 0, 0};
      static const int yoff[4] = {0, 0, -1, 1};
      for (int k = 0; k < 4; k++) {
        const int jx = ix + xoff[k];
        const int jy = iy + yoff[k];
        if (jx < 0 || jx >= width || jy < 0 || jy >= height) continue;
        const double dj = depthBuffer[jy*width + jx];
        if (dj < 0.0 || (dj - d) > threshold) {
          edges[iy*width + ix] = 1;
          break;
        }
      }
    }
  }

  // widen the outline: color drawn pixels near an edge pixel, but only
  // on the near side of the depth jump so the outline hugs the nearer
  // object and does not bleed onto more distant objects

  for (int iy = 0; iy < height; iy++) {
    for (int ix = 0; ix < width; ix++) {
      const double d = depthBuffer[iy*width + ix];
      if (d < 0.0) continue;

      bool paint = false;
      for (int dy = -w+1; dy < w && !paint; dy++) {
        const int jy = iy + dy;
        if (jy < 0 || jy >= height) continue;
        for (int dx = -w+1; dx < w; dx++) {
          const int jx = ix + dx;
          if (jx < 0 || jx >= width) continue;
          if (!edges[jy*width + jx]) continue;
          if ((d - depthBuffer[jy*width + jx]) < threshold) {
            paint = true;
            break;
          }
        }
      }

      if (paint) {
        const int i = iy*width + ix;
        writeBuffer[i*3+0] = red;
        writeBuffer[i*3+1] = green;
        writeBuffer[i*3+2] = blue;
      }
    }
  }

  delete [] edges;
}

/* ----------------------------------------------------------------------
   depth range of the drawn pixels of the composited image.  returns
   false if nothing was drawn; background pixels have a depth < 0
------------------------------------------------------------------------- */

bool Image::depth_minmax(double &dmin, double &dmax) const
{
  bool first = true;
  dmin = dmax = 0.0;
  for (int i = 0; i < npixels; i++) {
    const double d = depthBuffer[i];
    if (d < 0.0) continue;
    if (first) {
      dmin = dmax = d;
      first = false;
    } else {
      dmin = MIN(dmin,d);
      dmax = MAX(dmax,d);
    }
  }
  return !first;
}

/* ----------------------------------------------------------------------
   distance of the near and far side of the simulation box from the
   camera, by projecting the eight box corners onto the view direction
------------------------------------------------------------------------- */

void Image::box_depth_minmax(double &dnear, double &dfar) const
{
  const double dcam = MathExtra::dot3(camPos,camDir);
  dnear = dfar = 0.0;
  for (int ic = 0; ic < 8; ic++) {
    double corner[3];
    corner[0] = ((ic & 1) ? boxbounds[1] : boxbounds[0]) - xctr;
    corner[1] = ((ic & 2) ? boxbounds[3] : boxbounds[2]) - yctr;
    corner[2] = ((ic & 4) ? boxbounds[5] : boxbounds[4]) - zctr;
    const double d = dcam - MathExtra::dot3(corner,camDir);
    if (ic == 0) {
      dnear = dfar = d;
    } else {
      dnear = MIN(dnear,d);
      dfar = MAX(dfar,d);
    }
  }
}

/* ----------------------------------------------------------------------
   apply depth cueing to the composited image on the output rank:
   fade drawn pixels toward the fog color with increasing distance from
   the viewer.  the fade ends at the most distant drawn pixel and starts
   at the nearest drawn pixel or at a chosen fraction of the simulation
   box projected onto the view direction.
------------------------------------------------------------------------- */

void Image::compute_depthcue()
{
  // determine depth range of drawn pixels; nothing to do without drawn
  // pixels or without depth variation

  // the depth spread carries simulation length units, so the test for a
  // degenerate range must scale with the box rather than use a fixed value

  const double deps = EPSILON * box_maxdel();

  double dmin,dmax;
  if (!depth_minmax(dmin,dmax)) return;
  if (dmax - dmin <= deps) return;

  // start of the fade: by default the nearest drawn pixel.  with a start
  // fraction set, place it at that fraction between the near and far side
  // of the simulation box as seen from the camera

  double dstart = dmin;
  if (depthcuestartflag) {
    double dnear,dfar;
    box_depth_minmax(dnear,dfar);
    dstart = dnear + depthcuestart * (dfar - dnear);
    if (dstart >= dmax - deps) return;      // fading starts behind all pixels
  }
  const double dscale = depthcueint / (dmax - dstart);

  // blend pixel colors toward the fog color.  by default this is the
  // background color, with a gradient enabled the same per-row color as
  // in clear(); a custom fog color is used for all rows unchanged

  for (int iy = 0; iy < height; iy++) {
    int red,green,blue;
    if (depthcuecolor) {
      red   = static_cast<int> (depthcuecolor[0] * 255.0);
      green = static_cast<int> (depthcuecolor[1] * 255.0);
      blue  = static_cast<int> (depthcuecolor[2] * 255.0);
    } else if (background2[0] >= 0) {
      const double fraction = (double) iy / (double) height;
      red   = static_cast<int> (fraction*background2[0] + (1.0-fraction)*background[0]);
      green = static_cast<int> (fraction*background2[1] + (1.0-fraction)*background[1]);
      blue  = static_cast<int> (fraction*background2[2] + (1.0-fraction)*background[2]);
    } else {
      red   = background[0];
      green = background[1];
      blue  = background[2];
    }
    for (int ix = 0; ix < width; ix++) {
      const int i = iy * width + ix;
      const double d = depthBuffer[i];
      if (d < 0.0 || d <= dstart) continue;
      const double f = MIN(1.0, (d - dstart) * dscale);
      for (int k = 0; k < 3; k++) {
        const double oldc = (double) (unsigned char) writeBuffer[i*3+k];
        const double newc = (k == 0) ? red : ((k == 1) ? green : blue);
        writeBuffer[i*3+k] = (char)
          static_cast<unsigned char> ((1.0 - f) * oldc + f * newc);
      }
    }
  }
}

/* ----------------------------------------------------------------------
   defocus the background of the composited image on the output rank:
   objects are blurred more the further they are behind the start of the
   blur, which puts the visual emphasis on the objects in front of it.
   everything closer than the start stays sharp, so this is not the full
   depth of field of a camera lens, which would blur the foreground too.
------------------------------------------------------------------------- */

void Image::compute_defocus()
{
  // largest blur radius in pixels, expressed as a fraction of the image
  // height so that the effect does not depend on the image size.  the
  // internal image is twice as large with FSAA, which scales the radius
  // along with it

  const double maxradius = defocusint * 0.01 * height;
  if (maxradius < 1.0) return;    // blur is smaller than a pixel

  // determine depth range of drawn pixels; nothing to do without drawn
  // pixels or without depth variation

  // the depth spread carries simulation length units, so the test for a
  // degenerate range must scale with the box rather than use a fixed value

  const double deps = EPSILON * box_maxdel();

  double dmin,dmax;
  if (!depth_minmax(dmin,dmax)) return;
  if (dmax - dmin <= deps) return;

  // start of the blur: by default the nearest drawn pixel, so that the
  // front of the scene stays sharp.  with a start fraction set, place it
  // at that fraction between the near and far side of the simulation box
  // as seen from the camera

  double dstart = dmin;
  if (defocusstartflag) {
    double dnear,dfar;
    box_depth_minmax(dnear,dfar);
    dstart = dnear + defocusstart * (dfar - dnear);
    if (dstart >= dmax - deps) return;      // blurring starts behind all pixels
  }
  const double dscale = maxradius / (dmax - dstart);

  // blur radius of each pixel.  pixels in front of the start of the blur
  // stay sharp, behind it the radius grows with the distance from the
  // viewer.  the background has no depth and is treated as maximally
  // blurred, so that blurred objects in the back dissolve into it
  // instead of keeping a sharp silhouette

  double *radiusBuffer = new double[npixels];

  for (int i = 0; i < npixels; i++) {
    const double d = depthBuffer[i];
    if (d < 0.0) radiusBuffer[i] = maxradius;
    else if (d <= dstart) radiusBuffer[i] = 0.0;
    else radiusBuffer[i] = (d - dstart) * dscale;
  }

  // sample positions on a unit disk, placed on a spiral with the golden
  // angle between them, which spreads them evenly.  using the disk shape
  // of a camera aperture rather than a bell shaped blur keeps the blurred
  // objects looking out of focus instead of looking like fog.  the number
  // of samples follows the largest blur radius, so that wide blurs do not
  // show the individual samples

  int nsamples = static_cast<int> (4.0 * maxradius);
  nsamples = MAX(nsamples,16);
  nsamples = MIN(nsamples,64);

  const double GOLDEN_ANGLE = 2.39996322972865332;
  double *sample = new double[3*nsamples];
  for (int s = 0; s < nsamples; s++) {
    const double r = sqrt((s + 0.5) / nsamples);
    const double angle = s * GOLDEN_ANGLE;
    sample[3*s+0] = r * cos(angle);
    sample[3*s+1] = r * sin(angle);
    sample[3*s+2] = r;
  }

  // collect the blur from an unmodified copy of the composited image

  char *source = new char[3*npixels];
  memcpy(source,writeBuffer,3*npixels);

  for (int iy = 0; iy < height; iy++) {
    for (int ix = 0; ix < width; ix++) {
      const int i = iy*width + ix;
      const double radius = radiusBuffer[i];
      if (radius < 0.5) continue;   // in focus, the pixel is left alone

      // turn the whole sample pattern by a per-pixel angle taken from
      // interleaved gradient noise.  this replaces the rings that the
      // repeated sample pattern would leave in wide blurs by a fine
      // grain, and does not depend on the number of MPI ranks

      const double noise = fmod(0.06711056*ix + 0.00583715*iy, 1.0);
      const double angle = fmod(52.9829189*noise, 1.0) * MY_2PI;
      const double cosa = cos(angle);
      const double sina = sin(angle);

      // a sample only contributes if its own blur circle reaches this
      // pixel.  that keeps sharp objects in front from bleeding into the
      // blurred background, which would show up as a halo around them.
      // the contribution fades out over the last pixel of that reach, so
      // that the blur does not gain visible steps

      double c[3];
      c[0] = (double) (unsigned char) source[3*i+0];
      c[1] = (double) (unsigned char) source[3*i+1];
      c[2] = (double) (unsigned char) source[3*i+2];
      double wsum = 1.0;

      for (int s = 0; s < nsamples; s++) {
        const double dx = radius * (cosa*sample[3*s+0] - sina*sample[3*s+1]);
        const double dy = radius * (sina*sample[3*s+0] + cosa*sample[3*s+1]);
        const int jx = ix + static_cast<int> (lround(dx));
        const int jy = iy + static_cast<int> (lround(dy));
        if (jx < 0 || jx >= width || jy < 0 || jy >= height) continue;

        const int j = jy*width + jx;
        const double weight = saturate(radiusBuffer[j] - radius * sample[3*s+2]);
        if (weight <= 0.0) continue;

        c[0] += weight * (double) (unsigned char) source[3*j+0];
        c[1] += weight * (double) (unsigned char) source[3*j+1];
        c[2] += weight * (double) (unsigned char) source[3*j+2];
        wsum += weight;
      }

      for (int k = 0; k < 3; k++)
        writeBuffer[3*i+k] = (char)
          static_cast<unsigned char> (lround(c[k]/wsum));
    }
  }

  delete [] source;
  delete [] sample;
  delete [] radiusBuffer;
}

/* ---------------------------------------------------------------------- */

#ifdef SPARTA_JPEG
void Image::write_JPG(FILE *fp)
{
  struct jpeg_compress_struct cinfo;
  struct jpeg_error_mgr jerr;
  JSAMPROW row_pointer;

  // with FSAA the image was rendered at 2x and downsampled in merge()

  const int aafactor = fsaa ? 2 : 1;
  const int outwidth = width/aafactor;
  const int outheight = height/aafactor;

  cinfo.err = jpeg_std_error(&jerr);
  jpeg_create_compress(&cinfo);
  jpeg_stdio_dest(&cinfo,fp);
  cinfo.image_width = outwidth;
  cinfo.image_height = outheight;
  cinfo.input_components = 3;
  cinfo.in_color_space = JCS_RGB;

  jpeg_set_defaults(&cinfo);
  jpeg_set_quality(&cinfo,85,TRUE);
  jpeg_start_compress(&cinfo,TRUE);

  while (cinfo.next_scanline < cinfo.image_height) {
    row_pointer = (JSAMPROW)
      &writeBuffer[(cinfo.image_height - 1 - cinfo.next_scanline) *
                   3 * outwidth];
    jpeg_write_scanlines(&cinfo,&row_pointer,1);
  }

  jpeg_finish_compress(&cinfo);
  jpeg_destroy_compress(&cinfo);
}
#else
void Image::write_JPG(FILE*)
{
}
#endif

/* ---------------------------------------------------------------------- */

#ifdef SPARTA_PNG
void Image::write_PNG(FILE *fp)
{
  png_structp png_ptr;
  png_infop info_ptr;

  png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);

  if (!png_ptr) return;

  info_ptr = png_create_info_struct(png_ptr);
  if (!info_ptr) {
    png_destroy_write_struct(&png_ptr, NULL);
    return;
  }

  if (setjmp(png_jmpbuf(png_ptr))) {
    png_destroy_write_struct(&png_ptr, &info_ptr);
    return;
  }

  // with FSAA the image was rendered at 2x and downsampled in merge()

  const int aafactor = fsaa ? 2 : 1;
  const int outwidth = width/aafactor;
  const int outheight = height/aafactor;

  png_init_io(png_ptr, fp);
  png_set_compression_level(png_ptr,Z_BEST_COMPRESSION);
  png_set_IHDR(png_ptr,info_ptr,outwidth,outheight,8,PNG_COLOR_TYPE_RGB,
    PNG_INTERLACE_NONE,PNG_COMPRESSION_TYPE_DEFAULT,PNG_FILTER_TYPE_DEFAULT);

  png_text text_ptr[2];
  memset(text_ptr,0,2*sizeof(png_text));

  char key0[]  = "Software";
  char text0[] = "SPARTA " SPARTA_VERSION;
  char key1[]  = "Description";
  char text1[] = "Dump image snapshot";
  text_ptr[0].key = key0;
  text_ptr[0].text = text0;
  text_ptr[1].key = key1;
  text_ptr[1].text = text1;
  text_ptr[0].compression = PNG_TEXT_COMPRESSION_NONE;
  text_ptr[1].compression = PNG_TEXT_COMPRESSION_NONE;

  png_set_text(png_ptr,info_ptr,text_ptr,1);
  png_write_info(png_ptr,info_ptr);

  png_bytep row_pointers[outheight];
  for (int i=0; i < outheight; ++i)
    row_pointers[i] = (png_bytep) &writeBuffer[(outheight-i-1)*3*outwidth];

  png_write_image(png_ptr, row_pointers);
  png_write_end(png_ptr, info_ptr);

  png_destroy_write_struct(&png_ptr, &info_ptr);
}
#else
void Image::write_PNG(FILE *)
{
}
#endif

/* ---------------------------------------------------------------------- */

void Image::write_PPM(FILE *fp)
{
  // with FSAA the image was rendered at 2x and downsampled in merge()

  const int aafactor = fsaa ? 2 : 1;
  const int outwidth = width/aafactor;
  const int outheight = height/aafactor;

  fprintf(fp,"P6\n%d %d\n255\n",outwidth,outheight);

  int y;
  for (y = outheight-1; y >= 0; y--)
    fwrite(&writeBuffer[y*outwidth*3],3,outwidth,fp);
}

/* ----------------------------------------------------------------------
   return static/dynamic status of color map index
------------------------------------------------------------------------- */

int Image::map_dynamic(int index)
{
  return maps[index]->dynamic;
}

/* ----------------------------------------------------------------------
   redefine properties of the color map index
   return 1 if any error in args, else return 0
------------------------------------------------------------------------- */

int Image::map_reset(int index, int narg, char **arg)
{
  return maps[index]->reset(narg,arg);
}

/* ----------------------------------------------------------------------
   set min/max bounds of dynamic color map index
------------------------------------------------------------------------- */

int Image::map_minmax(int index, double mindynamic, double maxdynamic)
{
  return maps[index]->minmax(mindynamic,maxdynamic);
}

/* ----------------------------------------------------------------------
   return 3-vector color corresponding to value from color map index
------------------------------------------------------------------------- */

double *Image::map_value2color(int index, double value)
{
  return maps[index]->value2color(value);
}

/* ----------------------------------------------------------------------
   add a new color to username and userrgb
   redefine RGB values in userrgb if name already exists
   return 1 if RGB values are invalid, else return 0
------------------------------------------------------------------------- */

int Image::addcolor(char *name, double r, double g, double b)
{
  int icolor;
  for (icolor = 0; icolor < ncolors; icolor++)
    if (strcmp(name,username[icolor]) == 0) break;

  if (icolor == ncolors) {
    username = (char **)
      memory->srealloc(username,(ncolors+1)*sizeof(char *),"image:username");
    memory->grow(userrgb,ncolors+1,3,"image:userrgb");
    ncolors++;
  }

  int n = strlen(name) + 1;
  username[icolor] = new char[n];
  strcpy(username[icolor],name);

  if (r < 0.0 || r > 1.0 || g < 0.0 || g > 1.0 || b < 0.0 || b > 1.0)
    return 1;

  userrgb[icolor][0] = r;
  userrgb[icolor][1] = g;
  userrgb[icolor][2] = b;

  return 0;
}

/* ----------------------------------------------------------------------
   if index > 0, return ptr to index-1 color from rgb
   if index < 0, return ptr to -index-1 color from userrgb
   if index = 0, search the 2 lists of color names for the string color
   search user-defined color names first, then the list of NCOLORS names
   return a pointer to the 3 floating point RGB values or NULL if didn't find
------------------------------------------------------------------------- */

double *Image::color2rgb(const char *color, int index)
{
  static const char *name[NCOLORS] = {
    "aliceblue",
    "antiquewhite",
    "aqua",
    "aquamarine",
    "azure",
    "beige",
    "bisque",
    "black",
    "blanchedalmond",
    "blue",
    "blueviolet",
    "brown",
    "burlywood",
    "cadetblue",
    "chartreuse",
    "chocolate",
    "coral",
    "cornflowerblue",
    "cornsilk",
    "crimson",
    "cyan",
    "darkblue",
    "darkcyan",
    "darkgoldenrod",
    "darkgray",
    "darkgreen",
    "darkkhaki",
    "darkmagenta",
    "darkolivegreen",
    "darkorange",
    "darkorchid",
    "darkred",
    "darksalmon",
    "darkseagreen",
    "darkslateblue",
    "darkslategray",
    "darkturquoise",
    "darkviolet",
    "deeppink",
    "deepskyblue",
    "dimgray",
    "dodgerblue",
    "firebrick",
    "floralwhite",
    "forestgreen",
    "fuchsia",
    "gainsboro",
    "ghostwhite",
    "gold",
    "goldenrod",
    "gray",
    "green",
    "greenyellow",
    "honeydew",
    "hotpink",
    "indianred",
    "indigo",
    "ivory",
    "khaki",
    "lavender",
    "lavenderblush",
    "lawngreen",
    "lemonchiffon",
    "lightblue",
    "lightcoral",
    "lightcyan",
    "lightgoldenrodyellow",
    "lightgreen",
    "lightgrey",
    "lightpink",
    "lightsalmon",
    "lightseagreen",
    "lightskyblue",
    "lightslategray",
    "lightsteelblue",
    "lightyellow",
    "lime",
    "limegreen",
    "linen",
    "magenta",
    "maroon",
    "mediumaquamarine",
    "mediumblue",
    "mediumorchid",
    "mediumpurple",
    "mediumseagreen",
    "mediumslateblue",
    "mediumspringgreen",
    "mediumturquoise",
    "mediumvioletred",
    "midnightblue",
    "mintcream",
    "mistyrose",
    "moccasin",
    "navajowhite",
    "navy",
    "oldlace",
    "olive",
    "olivedrab",
    "orange",
    "orangered",
    "orchid",
    "palegoldenrod",
    "palegreen",
    "paleturquoise",
    "palevioletred",
    "papayawhip",
    "peachpuff",
    "peru",
    "pink",
    "plum",
    "powderblue",
    "purple",
    "red",
    "rosybrown",
    "royalblue",
    "saddlebrown",
    "salmon",
    "sandybrown",
    "seagreen",
    "seashell",
    "sienna",
    "silver",
    "skyblue",
    "slateblue",
    "slategray",
    "snow",
    "springgreen",
    "steelblue",
    "tan",
    "teal",
    "thistle",
    "tomato",
    "turquoise",
    "violet",
    "wheat",
    "white",
    "whitesmoke",
    "yellow",
    "yellowgreen"
  };

  static double rgb[NCOLORS][3] = {
    {240/255.0, 248/255.0, 255/255.0},
    {250/255.0, 235/255.0, 215/255.0},
    {0/255.0, 255/255.0, 255/255.0},
    {127/255.0, 255/255.0, 212/255.0},
    {240/255.0, 255/255.0, 255/255.0},
    {245/255.0, 245/255.0, 220/255.0},
    {255/255.0, 228/255.0, 196/255.0},
    {0/255.0, 0/255.0, 0/255.0},
    {255/255.0, 255/255.0, 205/255.0},
    {0/255.0, 0/255.0, 255/255.0},
    {138/255.0, 43/255.0, 226/255.0},
    {165/255.0, 42/255.0, 42/255.0},
    {222/255.0, 184/255.0, 135/255.0},
    {95/255.0, 158/255.0, 160/255.0},
    {127/255.0, 255/255.0, 0/255.0},
    {210/255.0, 105/255.0, 30/255.0},
    {255/255.0, 127/255.0, 80/255.0},
    {100/255.0, 149/255.0, 237/255.0},
    {255/255.0, 248/255.0, 220/255.0},
    {220/255.0, 20/255.0, 60/255.0},
    {0/255.0, 255/255.0, 255/255.0},
    {0/255.0, 0/255.0, 139/255.0},
    {0/255.0, 139/255.0, 139/255.0},
    {184/255.0, 134/255.0, 11/255.0},
    {169/255.0, 169/255.0, 169/255.0},
    {0/255.0, 100/255.0, 0/255.0},
    {189/255.0, 183/255.0, 107/255.0},
    {139/255.0, 0/255.0, 139/255.0},
    {85/255.0, 107/255.0, 47/255.0},
    {255/255.0, 140/255.0, 0/255.0},
    {153/255.0, 50/255.0, 204/255.0},
    {139/255.0, 0/255.0, 0/255.0},
    {233/255.0, 150/255.0, 122/255.0},
    {143/255.0, 188/255.0, 143/255.0},
    {72/255.0, 61/255.0, 139/255.0},
    {47/255.0, 79/255.0, 79/255.0},
    {0/255.0, 206/255.0, 209/255.0},
    {148/255.0, 0/255.0, 211/255.0},
    {255/255.0, 20/255.0, 147/255.0},
    {0/255.0, 191/255.0, 255/255.0},
    {105/255.0, 105/255.0, 105/255.0},
    {30/255.0, 144/255.0, 255/255.0},
    {178/255.0, 34/255.0, 34/255.0},
    {255/255.0, 250/255.0, 240/255.0},
    {34/255.0, 139/255.0, 34/255.0},
    {255/255.0, 0/255.0, 255/255.0},
    {220/255.0, 220/255.0, 220/255.0},
    {248/255.0, 248/255.0, 255/255.0},
    {255/255.0, 215/255.0, 0/255.0},
    {218/255.0, 165/255.0, 32/255.0},
    {128/255.0, 128/255.0, 128/255.0},
    {0/255.0, 128/255.0, 0/255.0},
    {173/255.0, 255/255.0, 47/255.0},
    {240/255.0, 255/255.0, 240/255.0},
    {255/255.0, 105/255.0, 180/255.0},
    {205/255.0, 92/255.0, 92/255.0},
    {75/255.0, 0/255.0, 130/255.0},
    {255/255.0, 240/255.0, 240/255.0},
    {240/255.0, 230/255.0, 140/255.0},
    {230/255.0, 230/255.0, 250/255.0},
    {255/255.0, 240/255.0, 245/255.0},
    {124/255.0, 252/255.0, 0/255.0},
    {255/255.0, 250/255.0, 205/255.0},
    {173/255.0, 216/255.0, 230/255.0},
    {240/255.0, 128/255.0, 128/255.0},
    {224/255.0, 255/255.0, 255/255.0},
    {250/255.0, 250/255.0, 210/255.0},
    {144/255.0, 238/255.0, 144/255.0},
    {211/255.0, 211/255.0, 211/255.0},
    {255/255.0, 182/255.0, 193/255.0},
    {255/255.0, 160/255.0, 122/255.0},
    {32/255.0, 178/255.0, 170/255.0},
    {135/255.0, 206/255.0, 250/255.0},
    {119/255.0, 136/255.0, 153/255.0},
    {176/255.0, 196/255.0, 222/255.0},
    {255/255.0, 255/255.0, 224/255.0},
    {0/255.0, 255/255.0, 0/255.0},
    {50/255.0, 205/255.0, 50/255.0},
    {250/255.0, 240/255.0, 230/255.0},
    {255/255.0, 0/255.0, 255/255.0},
    {128/255.0, 0/255.0, 0/255.0},
    {102/255.0, 205/255.0, 170/255.0},
    {0/255.0, 0/255.0, 205/255.0},
    {186/255.0, 85/255.0, 211/255.0},
    {147/255.0, 112/255.0, 219/255.0},
    {60/255.0, 179/255.0, 113/255.0},
    {123/255.0, 104/255.0, 238/255.0},
    {0/255.0, 250/255.0, 154/255.0},
    {72/255.0, 209/255.0, 204/255.0},
    {199/255.0, 21/255.0, 133/255.0},
    {25/255.0, 25/255.0, 112/255.0},
    {245/255.0, 255/255.0, 250/255.0},
    {255/255.0, 228/255.0, 225/255.0},
    {255/255.0, 228/255.0, 181/255.0},
    {255/255.0, 222/255.0, 173/255.0},
    {0/255.0, 0/255.0, 128/255.0},
    {253/255.0, 245/255.0, 230/255.0},
    {128/255.0, 128/255.0, 0/255.0},
    {107/255.0, 142/255.0, 35/255.0},
    {255/255.0, 165/255.0, 0/255.0},
    {255/255.0, 69/255.0, 0/255.0},
    {218/255.0, 112/255.0, 214/255.0},
    {238/255.0, 232/255.0, 170/255.0},
    {152/255.0, 251/255.0, 152/255.0},
    {175/255.0, 238/255.0, 238/255.0},
    {219/255.0, 112/255.0, 147/255.0},
    {255/255.0, 239/255.0, 213/255.0},
    {255/255.0, 239/255.0, 213/255.0},
    {205/255.0, 133/255.0, 63/255.0},
    {255/255.0, 192/255.0, 203/255.0},
    {221/255.0, 160/255.0, 221/255.0},
    {176/255.0, 224/255.0, 230/255.0},
    {128/255.0, 0/255.0, 128/255.0},
    {255/255.0, 0/255.0, 0/255.0},
    {188/255.0, 143/255.0, 143/255.0},
    {65/255.0, 105/255.0, 225/255.0},
    {139/255.0, 69/255.0, 19/255.0},
    {250/255.0, 128/255.0, 114/255.0},
    {244/255.0, 164/255.0, 96/255.0},
    {46/255.0, 139/255.0, 87/255.0},
    {255/255.0, 245/255.0, 238/255.0},
    {160/255.0, 82/255.0, 45/255.0},
    {192/255.0, 192/255.0, 192/255.0},
    {135/255.0, 206/255.0, 235/255.0},
    {106/255.0, 90/255.0, 205/255.0},
    {112/255.0, 128/255.0, 144/255.0},
    {255/255.0, 250/255.0, 250/255.0},
    {0/255.0, 255/255.0, 127/255.0},
    {70/255.0, 130/255.0, 180/255.0},
    {210/255.0, 180/255.0, 140/255.0},
    {0/255.0, 128/255.0, 128/255.0},
    {216/255.0, 191/255.0, 216/255.0},
    {253/255.0, 99/255.0, 71/255.0},
    {64/255.0, 224/255.0, 208/255.0},
    {238/255.0, 130/255.0, 238/255.0},
    {245/255.0, 222/255.0, 179/255.0},
    {255/255.0, 255/255.0, 255/255.0},
    {245/255.0, 245/255.0, 245/255.0},
    {255/255.0, 255/255.0, 0/255.0},
    {154/255.0, 205/255.0, 50/255.0}
  };

  if (index > 0) {
    if (index > NCOLORS) return NULL;
    return rgb[index-1];
  }
  if (index < 0) {
    if (-index > ncolors) return NULL;
    return userrgb[-index-1];
  }

  for (int i = 0; i < ncolors; i++)
    if (strcmp(color,username[i]) == 0) return userrgb[i];
  for (int i = 0; i < NCOLORS; i++)
    if (strcmp(color,name[i]) == 0) return rgb[i];
  return NULL;
}

/* ----------------------------------------------------------------------
   return number of default colors
------------------------------------------------------------------------- */

int Image::default_colors()
{
  return NCOLORS;
}

// ----------------------------------------------------------------------
// ----------------------------------------------------------------------
// ColorMap class
// ----------------------------------------------------------------------
// ----------------------------------------------------------------------

ColorMap::ColorMap(SPARTA *sparta, Image *caller) : Pointers(sparta)
{
  image = caller;

  // default color map

  dynamic = 1;

  mlo = MINVALUE;
  mhi = MAXVALUE;
  mstyle = CONTINUOUS;
  mrange = FRACTIONAL;

  nentry = 2;
  mentry = new MapEntry[nentry];
  mentry[0].single = MINVALUE;
  mentry[0].color = image->color2rgb("blue");
  mentry[1].single = MAXVALUE;
  mentry[1].color = image->color2rgb("red");
}

/* ---------------------------------------------------------------------- */

ColorMap::~ColorMap()
{
  delete [] mentry;
}

/* ----------------------------------------------------------------------
   redefine color map
   args = lo hi style delta N entry1 entry2 ... entryN as defined by caller
   return 1 if any error in args, else return 0
------------------------------------------------------------------------- */

int ColorMap::reset(int narg, char **arg)
{
  if (!islower(arg[0][0])) {
    mlo = NUMERIC;
    mlovalue = atof(arg[0]);
  } else if (strcmp(arg[0],"min") == 0) mlo = MINVALUE;
  else return 1;

  if (!islower(arg[1][0])) {
    mhi = NUMERIC;
    mhivalue = atof(arg[1]);
  } else if (strcmp(arg[1],"max") == 0) mhi = MAXVALUE;
  else return 1;

  if (mlo == NUMERIC && mhi == NUMERIC && mlovalue >= mhivalue) return 1;

  if (mlo == MINVALUE || mhi == MAXVALUE) dynamic = 1;
  else dynamic = 0;

  if (strlen(arg[2]) != 2) return 1;
  if (arg[2][0] == 'c') mstyle = CONTINUOUS;
  else if (arg[2][0] == 'd') mstyle = DISCRETE;
  else if (arg[2][0] == 's') mstyle = SEQUENTIAL;
  else return 1;
  if (arg[2][1] == 'a') mrange = ABSOLUTE;
  else if (arg[2][1] == 'f') mrange = FRACTIONAL;
  else return 1;

  if (mstyle == SEQUENTIAL) {
    mbinsize = atof(arg[3]);
    if (mbinsize <= 0.0) return 1;
    mbinsizeinv = 1.0/mbinsize;
  }

  nentry = atoi(arg[4]);
  if (nentry < 1) return 1;
  delete [] mentry;
  mentry = new MapEntry[nentry];

  int n = 5;
  for (int i = 0; i < nentry; i++) {
    if (mstyle == CONTINUOUS) {
      if (n+2 > narg) return 1;
      if (!islower(arg[n][0])) {
        mentry[i].single = NUMERIC;
        mentry[i].svalue = atof(arg[n]);
      } else if (strcmp(arg[n],"min") == 0) mentry[i].single = MINVALUE;
      else if (strcmp(arg[n],"max") == 0) mentry[i].single = MAXVALUE;
      else return 1;
      mentry[i].color = image->color2rgb(arg[n+1]);
      n += 2;
    } else if (mstyle == DISCRETE) {
      if (n+3 > narg) return 1;
      if (!islower(arg[n][0])) {
        mentry[i].lo = NUMERIC;
        mentry[i].lvalue = atof(arg[n]);
      } else if (strcmp(arg[n],"min") == 0) mentry[i].lo = MINVALUE;
      else if (strcmp(arg[n],"max") == 0) mentry[i].lo = MAXVALUE;
      else return 1;
      if (!islower(arg[n+1][0])) {
        mentry[i].hi = NUMERIC;
        mentry[i].hvalue = atof(arg[n+1]);
      } else if (strcmp(arg[n+1],"min") == 0) mentry[i].hi = MINVALUE;
      else if (strcmp(arg[n+1],"max") == 0) mentry[i].hi = MAXVALUE;
      else return 1;
      mentry[i].color = image->color2rgb(arg[n+2]);
      n += 3;
    } else if (mstyle == SEQUENTIAL) {
      if (n+1 > narg) return 1;
      mentry[i].color = image->color2rgb(arg[n]);
      n += 1;
    }
    if (mentry[i].color == NULL) return 1;
  }

  if (mstyle == CONTINUOUS) {
    if (nentry < 2) return 1;
    if (mentry[0].single != MINVALUE || mentry[nentry-1].single != MAXVALUE)
      return 1;
    for (int i = 2; i < nentry-1; i++) {
      if (mentry[i].svalue <= mentry[i-1].svalue) return 1;
    }
  } else if (mstyle == DISCRETE) {
    if (nentry < 1) return 1;
    if (mentry[nentry-1].lo != MINVALUE || mentry[nentry-1].hi != MAXVALUE)
      return 1;
  } else if (mstyle == SEQUENTIAL) {
    if (nentry < 1) return 1;
  }

  // one-time call to minmax if color map is static

  if (!dynamic) return minmax(mlovalue,mhivalue);

  return 0;
}

/* ----------------------------------------------------------------------
   set explicit values for all min/max settings in color map
     from min/max dynamic values
   set lo/hi current and lvalue/hvalue entries that are MIN/MAX VALUE
   called only once if mlo/mhi != MIN/MAX VALUE, else called repeatedly
   return 1 = error if any values now overlap incorrectly with dynamic bounds
   else return 0
------------------------------------------------------------------------- */

int ColorMap::minmax(double mindynamic, double maxdynamic)
{
  if (mlo == MINVALUE) locurrent = mindynamic;
  else locurrent = mlovalue;
  if (mhi == MAXVALUE) hicurrent = maxdynamic;
  else hicurrent = mhivalue;
  if (locurrent > hicurrent) return 1;

  if (mstyle == CONTINUOUS) {
    if (mrange == ABSOLUTE) mentry[0].svalue = locurrent;
    else mentry[0].svalue = 0.0;
    if (mrange == ABSOLUTE) mentry[nentry-1].svalue = hicurrent;
    else mentry[nentry-1].svalue = 1.0;

    // error in ABSOLUTE mode if new lo/hi current cause
    // first/last entry to become lo > hi with adjacent entry

    if (mrange == ABSOLUTE) {
      if (mentry[0].svalue > mentry[1].svalue) return 1;
      if (mentry[nentry-2].svalue > mentry[nentry-1].svalue) return 1;
    }

  // OK if new lo/hi current cause an entry to have lo > hi,
  // since last entry will always be a match

  } else if (mstyle == DISCRETE) {
    for (int i = 0; i < nentry; i++) {
      if (mentry[i].lo == MINVALUE) {
        if (mrange == ABSOLUTE) mentry[i].lvalue = locurrent;
        else mentry[i].lvalue = 0.0;
      }
      if (mentry[i].hi == MAXVALUE) {
        if (mrange == ABSOLUTE) mentry[i].hvalue = hicurrent;
        else mentry[i].hvalue = 1.0;
      }
    }
  }

  return 0;
}

/* ----------------------------------------------------------------------
   convert value into an RGB color via color map
   return pointer to 3-vector
------------------------------------------------------------------------- */

double *ColorMap::value2color(double value)
{
  double lo;

  value = MAX(value,locurrent);
  value = MIN(value,hicurrent);

  if (mrange == FRACTIONAL) {
    if (locurrent == hicurrent) value = 0.0;
    else value = (value-locurrent) / (hicurrent-locurrent);
    lo = 0.0;
  } else {
    lo = locurrent;
  }

  if (mstyle == CONTINUOUS) {
    for (int i = 0; i < nentry-1; i++)
      if (value >= mentry[i].svalue && value <= mentry[i+1].svalue) {
        double fraction = (value-mentry[i].svalue) /
          (mentry[i+1].svalue-mentry[i].svalue);
        interpolate[0] = mentry[i].color[0] +
          fraction*(mentry[i+1].color[0]-mentry[i].color[0]);
        interpolate[1] = mentry[i].color[1] +
          fraction*(mentry[i+1].color[1]-mentry[i].color[1]);
        interpolate[2] = mentry[i].color[2] +
          fraction*(mentry[i+1].color[2]-mentry[i].color[2]);
        return interpolate;
      }
  } else if (mstyle == DISCRETE) {
    for (int i = 0; i < nentry; i++)
      if (value >= mentry[i].lvalue && value <= mentry[i].hvalue)
        return mentry[i].color;
  } else {
    int ibin = static_cast<int> ((value-lo) * mbinsizeinv);
    return mentry[ibin%nentry].color;
  }

  return NULL;
}
