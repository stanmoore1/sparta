/* ----------------------------------------------------------------------
   SPARTA - Stochastic PArallel Rarefied-gas Time-accurate Analyzer
   http://sparta.github.io
   Steve Plimpton, sjplimp@gmail.com, Michael Gallis, magalli@sandia.gov
   Sandia National Laboratories

   Copyright (2014) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level SPARTA directory.
------------------------------------------------------------------------- */

#include "spatype.h"
#include "stdlib.h"
#include "string.h"
#include "run.h"
#include "domain.h"
#include "grid.h"
#include "update.h"
#include "collide.h"
#include "input.h"
#include "modify.h"
#include "output.h"
#include "stats.h"
#include "finish.h"
#include "timer.h"
#include "error.h"

using namespace SPARTA_NS;

/* ---------------------------------------------------------------------- */

Run::Run(SPARTA *sparta) : Pointers(sparta) {}

/* ----------------------------------------------------------------------
   put the run state back on the way out of Run::command, whichever way out
   it takes.  Error::all() throws rather than exiting the process, so an
   error raised during setup or in the middle of timestepping unwinds
   straight past the assignments at the bottom of command() that used to do
   this -- leaving update->runflag set.  That flag is what
   sparta_is_running() reports, and an embedder reads it to decide whether it
   may start a run, stop one, or shut down; stuck at 1 it refuses all three.
   A mistake in an input deck is the commonest thing a user makes, so this is
   reachable on the first one.  The copied per-step commands are freed here
   too, for the same reason.
------------------------------------------------------------------------- */

namespace {
struct RunCleanup {
  SPARTA_NS::Update *update;
  char ***commands;
  int *ncommands;
  ~RunCleanup() {
    update->runflag = 0;
    update->firststep = update->laststep = 0;
    update->beginstep = update->endstep = 0;
    if (*commands) {
      for (int i = 0; i < *ncommands; i++) delete [] (*commands)[i];
      delete [] *commands;
      *commands = NULL;
    }
  }
};
}

/* ---------------------------------------------------------------------- */

void Run::command(int narg, char **arg)
{
  if (narg < 1) error->all(FLERR,"Illegal run command");

  // restore timeout in case a previous run was interrupted
  // by force_timeout() via the library interface,
  // then open a fresh timeout window for this command.
  // the order matters: reset first so that init_timeout() saves the real limit
  //   rather than an expired 0.0.  a "fix halt ... error soft" defeats the
  //   reset on purpose, via force_timeout(1), because it is documented to skip
  //   subsequent run commands
  // init_timeout() is called once here rather than beside each
  //   timer->barrier_start(TIME_LOOP) below, so that a "run N every M" spends
  //   one timeout window over the whole command instead of restarting the
  //   clock on every sub-run
  // and invalidate the stats cache of the previous run

  timer->reset_timeout();
  timer->init_timeout();
  output->stats->reset_cache();

  if (!grid->exist)
    error->all(FLERR,"Run command before grid is defined");
  if (!grid->exist_ghost)
    error->all(FLERR,"Run command before grid ghost cells are defined");

  bigint nsteps_input = ATOBIGINT(arg[0]);

  // parse optional args

  int uptoflag = 0;
  int startflag = 0;
  int stopflag = 0;
  bigint start,stop;
  int preflag = 1;
  int postflag = 1;
  int nevery = 0;
  int ncommands = 0;
  int first,last;

  int iarg = 1;
  while (iarg < narg) {
    if (strcmp(arg[iarg],"upto") == 0) {
      if (iarg+1 > narg) error->all(FLERR,"Illegal run command");
      uptoflag = 1;
      iarg += 1;
    } else if (strcmp(arg[iarg],"start") == 0) {
      if (iarg+2 > narg) error->all(FLERR,"Illegal run command");
      startflag = 1;
      start = ATOBIGINT(arg[iarg+1]);
      iarg += 2;
    } else if (strcmp(arg[iarg],"stop") == 0) {
      if (iarg+2 > narg) error->all(FLERR,"Illegal run command");
      stopflag = 1;
      stop = ATOBIGINT(arg[iarg+1]);
      iarg += 2;
    } else if (strcmp(arg[iarg],"pre") == 0) {
      if (iarg+2 > narg) error->all(FLERR,"Illegal run command");
      if (strcmp(arg[iarg+1],"no") == 0) preflag = 0;
      else if (strcmp(arg[iarg+1],"yes") == 0) preflag = 1;
      else error->all(FLERR,"Illegal run command");
      iarg += 2;
    } else if (strcmp(arg[iarg],"post") == 0) {
      if (iarg+2 > narg) error->all(FLERR,"Illegal run command");
      if (strcmp(arg[iarg+1],"no") == 0) postflag = 0;
      else if (strcmp(arg[iarg+1],"yes") == 0) postflag = 1;
      else error->all(FLERR,"Illegal run command");
      iarg += 2;

      // all remaining args are commands
      // first,last = arg index of first/last commands
      // set ncommands = 0 if single command and it is NULL

    } else if (strcmp(arg[iarg],"every") == 0) {
      if (iarg+3 > narg) error->all(FLERR,"Illegal run command");
      nevery = atoi(arg[iarg+1]);
      if (nevery <= 0) error->all(FLERR,"Illegal run command");
      first = iarg+2;
      last = narg-1;
      ncommands = last-first + 1;
      if (ncommands == 1 && strcmp(arg[first],"NULL") == 0) ncommands = 0;
      iarg = narg;
    } else error->all(FLERR,"Illegal run command");
  }

  // set nsteps as integer, using upto value if specified

  int nsteps;
  if (!uptoflag) {
    if (nsteps_input < 0 || nsteps_input > MAXSMALLINT)
      error->all(FLERR,"Invalid run command N value");
    nsteps = static_cast<int> (nsteps_input);
  } else {
    bigint delta = nsteps_input - update->ntimestep;
    if (delta < 0 || delta > MAXSMALLINT)
      error->all(FLERR,"Invalid run command upto value");
    nsteps = static_cast<int> (delta);
  }

  // error check

  if (startflag) {
    if (start < 0 || start > MAXBIGINT)
      error->all(FLERR,"Invalid run command start/stop value");
    if (start > update->ntimestep)
      error->all(FLERR,"Run command start value is after start of run");
  }
  if (stopflag) {
    if (stop < 0 || stop > MAXBIGINT)
      error->all(FLERR,"Invalid run command start/stop value");
    if (stop < update->ntimestep + nsteps)
      error->all(FLERR,"Run command stop value is before end of run");
  }

  // if nevery, make copies of arg strings that are commands
  // required because re-parsing commands via input->one() will wipe out args

  char **commands = NULL;
  RunCleanup cleanup = {update, &commands, &ncommands};
  if (nevery && ncommands > 0) {
    commands = new char*[ncommands];
    ncommands = 0;
    for (int i = first; i <= last; i++) {
      int n = strlen(arg[i]) + 1;
      commands[ncommands] = new char[n];
      strcpy(commands[ncommands],arg[i]);
      ncommands++;
    }
  }

  // perform a single run
  // use start/stop to set begin/end step
  // if pre or 1st run, do System init/setup,
  //   else just init timer and setup output
  // if post, do full Finish, else just print time

  update->runflag = 1;

  if (nevery == 0) {
    update->nsteps = nsteps;
    update->firststep = update->ntimestep;
    update->laststep = update->ntimestep + nsteps;
    if (update->laststep < 0 || update->laststep > MAXBIGINT)
      error->all(FLERR,"Too many timesteps");

    if (startflag) update->beginstep = start;
    else update->beginstep = update->firststep;
    if (stopflag) update->endstep = stop;
    else update->endstep = update->laststep;

    if (preflag || update->first_update == 0) {
      sparta->init();
      update->setup();
      if (collide) collide->setup();
    } else output->setup(0);

    timer->init();
    timer->barrier_start(TIME_LOOP);
    update->run(nsteps);
    timer->barrier_stop(TIME_LOOP);

    Finish finish(sparta);
    finish.end(postflag,0.0);

  // perform multiple runs optionally interleaved with invocation command(s)
  // use start/stop to set begin/end step
  // if pre or 1st iteration of multiple runs, do System init/setup,
  //   else just init timer and setup output
  // if post or last iteration, do full Finish, else just print time

  } else {
    int iter = 0;
    int nleft = nsteps;
    double time_multiple_runs = 0.0;

    while (nleft > 0 || iter == 0) {
      nsteps = MIN(nleft,nevery);

      update->nsteps = nsteps;
      update->firststep = update->ntimestep;
      update->laststep = update->ntimestep + nsteps;
      if (update->laststep < 0 || update->laststep > MAXBIGINT)
        error->all(FLERR,"Too many timesteps");

      if (startflag) update->beginstep = start;
      else update->beginstep = update->firststep;
      if (stopflag) update->endstep = stop;
      else update->endstep = update->laststep;

      if (preflag || iter == 0) {
        sparta->init();
        update->setup();
        if (collide) collide->setup();
      } else output->setup(0);

      timer->init();
      timer->barrier_start(TIME_LOOP);
      update->run(nsteps);
      timer->barrier_stop(TIME_LOOP);
      time_multiple_runs += timer->array[TIME_LOOP];

      Finish finish(sparta);
      if (postflag || nleft <= nsteps) {
        if (preflag) finish.end(1,0.0);
        else finish.end(1,time_multiple_runs);
      } else finish.end(0,0.0);

      // wrap command invocation with clearstep/addstep
      // since a command may invoke computes via variables

      if (ncommands) {
        modify->clearstep_compute();
        for (int i = 0; i < ncommands; i++) input->one(commands[i]);
        modify->addstep_compute(update->ntimestep + nevery);
      }

      nleft -= nsteps;
      iter++;
    }
  }

  // runflag, the step bounds and the copied commands are all reset by
  // ~RunCleanup, so that they are reset on the error paths as well
}
