#!/bin/bash
M=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T4
while pgrep -f "V3-T4/bisect.sh" >/dev/null; do sleep 15; done
$M/bisect.sh ambi_3body/in.ambi_3body emit/in.emit.face.region qk/in.qk shock_tube/in.shocktube implicit/in.implicit.3d.small emit/in.emit.surf.flow.region
echo BISECT2DONE >> $M/bisect.out
