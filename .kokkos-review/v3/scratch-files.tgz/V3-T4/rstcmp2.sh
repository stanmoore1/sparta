#!/bin/bash
R=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T4/rst2
st() { awk '/^ *Step /{h=1;print;next} /^Loop time/{h=0} h&&/^ *[0-9]/{$0=$0; out=""; for(i=1;i<=NF;i++) if(i!=2) out=out" "$i; print out}' $1; }
for w in in.custom.cube.read in.custom.cube.set in.custom.step.read in.custom.step.set in.free; do for m in kk cpu; do
  p=$R/$w.$m; [ -f $p.BB.R.log ] || continue
  md=$(cmp -s <(awk '{print $1}' $p.AA.md5) <(awk '{print $1}' $p.BB.md5) && echo same || echo DIFF)
  nf=$(wc -l < $p.AA.md5)
  # reader stats: AB vs BB (same reader), BA vs AA
  r1=$(cmp -s <(st $p.AB.R.log) <(st $p.BB.R.log) && echo IDENT || echo DIFF)
  r2=$(cmp -s <(st $p.BA.R.log) <(st $p.AA.R.log) && echo IDENT || echo DIFF)
  r3=$(cmp -s <(st $p.AA.R.log) <(st $p.BB.R.log) && echo IDENT || echo DIFF)
  n=$(st $p.BB.R.log | wc -l)
  echo "$w $m restartfiles($nf) A-vs-B:$md  readerB(A-file vs B-file):$r1 readerA(B-file vs A-file):$r2 AA-vs-BB:$r3 statsrows=$n"
done; done
