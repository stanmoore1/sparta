#!/bin/bash
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
R=$S/final/V3-T4/fmt; mkdir -p $R
A=$S/build_base/src/spa_kokkos_omp; B=$S/build/src/spa_kokkos_omp
EX=$S/final/V3-T1/ex
for pair in custom:in.custom.cube.read custom:in.custom.cube.set custom:in.custom.coarse.2d custom:in.custom.coarse.3d fft:in.fft.2d fft:in.fft.3d explicit2implicit:in.ablate.axi.spherecone; do
  ex=${pair%%:*}; inp=${pair#*:}
  for mode in kk cpu; do
    for b in A B; do
      tag=$inp.$mode.$b; d=$R/$tag
      [ -f $d/DONE ] && continue
      rm -rf $d; mkdir -p $d/w; cp -r $EX/$ex/. $d/w/
      [ $ex = explicit2implicit ] && { mkdir -p $d/ablation $d/axi; cp -r $EX/ablation/. $d/ablation/; cp -r $EX/axi/. $d/axi/; }
      k=""; [ $mode = kk ] && k="-k on t 1 -sf kk"
      eval bin=\$$b
      (cd $d/w && ls -1 > ../before.txt && timeout 900 $bin $k -in $inp -echo none -screen none -log ../log.txt >/dev/null 2>../err.txt; echo rc=$? >> ../err.txt)
      # keep only new files, truncated to first 200 lines each
      mkdir -p $d/out
      (cd $d/w && for f in $(ls -1 | grep -vxF -f ../before.txt); do [ -f $f ] && case $f in *.ppm|*.jpg|*.png|*restart*) ;; *) head -200 $f > ../out/$f;; esac; done)
      rm -rf $d/w $d/ablation $d/axi; touch $d/DONE
    done
  done
done
echo ALLDONE
