#!/bin/bash
# bis.sh <commit> <ex/in.deck>... : build CPU-only stub binary (-O3, KISS) at <commit> in worktree bis/,
# run given decks (capped copies from V3-T1/ex), store logs in bisruns/<hash>/. Idempotent.
M=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad/final/V3-T4
EX=$M/../V3-T1/ex
c=$(git -C /home/user/sparta rev-parse --short=8 $1); shift
mkdir -p $M/bins $M/bisruns/$c
if [ ! -x $M/bins/spa_$c ]; then
  git -C $M/bis checkout -q --detach $c || exit 1
  ninja -C $M/bbis -j2 > $M/bbis.log 2>&1 || { echo "BUILD FAIL $c"; exit 1; }
  cp $M/bbis/src/spa_ $M/bins/spa_$c
fi
for d in "$@"; do
  e=${d%%/*}; inp=${d#*/}; key=$e.$inp
  [ -s $M/bisruns/$c/$key.log ] && grep -q "^Total wall" $M/bisruns/$c/$key.log && continue
  w=$M/bisruns/$c/w; rm -rf "${w:?}"; mkdir -p $w; cp -r $EX/$e $w/$e
  for s in ablation axi; do [ -e $w/$s ] || ln -s $EX/$s $w/$s; done
  (cd $w/$e && timeout 1800 $M/bins/spa_$c -in $inp -echo none -screen none -log $M/bisruns/$c/$key.log >/dev/null 2>&1)
  rm -rf "${w:?}"
done
echo "done $c"
