#!/bin/bash
S=/tmp/claude-0/-home-user-sparta/890c9580-1a31-5f7e-91e6-8571cb0d6a4f/scratchpad
R=$S/final/V3-T4/rst2
A=$S/build/src/spa_kokkos_omp; B=$S/final/V3-T4/bmerged/src/spa_kokkos_omp  # A=B_opt, B=merged
EX=/home/user/sparta/examples
run() { # bin mode deck log
  local k=""; [ $2 = kk ] && k="-k on t 1 -sf kk"
  timeout 900 $1 $k -in $3 -echo none -screen none -log $4 > /dev/null 2>$4.err; echo "rc=$?" >> $4.err
}
for pair in custom:in.custom.cube.read custom:in.custom.cube.set custom:in.custom.step.read custom:in.custom.step.set free:in.free; do
  ex=${pair%%:*}; w=${pair#*:}
  for mode in kk cpu; do
   for wb in A B; do
    for rb in A B; do
      tag=$w.$mode.$wb$rb
      grep -q "^$tag " $R/summary.txt 2>/dev/null && continue
      d=$R/work/$tag; rm -rf $d; mkdir -p $d; cp -r $EX/$ex/. $d/
      cd $d
      if [ $ex = free ]; then
        awk '/^clear/{exit} {print}' in.free.restart > in.W; awk 'f{print} /^clear/{f=1}' in.free.restart > in.R
        wdeck=in.W; rdeck=in.R
      else wdeck=$w; rdeck=$w.restart; fi
      eval wbin=\$$wb; eval rbin=\$$rb
      run $wbin $mode $wdeck $R/$tag.W.log
      md5sum tmp.*restart* 2>/dev/null | sort -k2 > $R/$tag.md5
      run $rbin $mode $rdeck $R/$tag.R.log
      st=OK; grep -qE "^ERROR" $R/$tag.W.log $R/$tag.R.log && st=ERROR
      grep -q "rc=0" $R/$tag.W.log.err || st="$st,Wrc"; grep -q "rc=0" $R/$tag.R.log.err || st="$st,Rrc"
      echo "$tag $st" >> $R/summary.txt
      cd $R; rm -rf $d
    done
   done
  done
done
